/*M!999999\- enable the sandbox mode */ 
-- MariaDB dump 10.19  Distrib 10.11.14-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: library_management_system
-- ------------------------------------------------------
-- Server version	10.11.14-MariaDB-0ubuntu0.24.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `admin_sessions`
--

DROP TABLE IF EXISTS `admin_sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `admin_sessions` (
  `session_id` char(36) NOT NULL,
  `admin_id` int(11) NOT NULL,
  `token_hash` char(64) NOT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `expires_at` datetime NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`session_id`),
  KEY `idx_sessions_admin` (`admin_id`),
  KEY `idx_sessions_token` (`token_hash`),
  CONSTRAINT `fk_session_admin` FOREIGN KEY (`admin_id`) REFERENCES `admins` (`admin_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admin_sessions`
--

LOCK TABLES `admin_sessions` WRITE;
/*!40000 ALTER TABLE `admin_sessions` DISABLE KEYS */;
/*!40000 ALTER TABLE `admin_sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `admins`
--

DROP TABLE IF EXISTS `admins`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `admins` (
  `admin_id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `password_hash` varchar(255) NOT NULL,
  `full_name` varchar(100) NOT NULL,
  `email` varchar(120) NOT NULL,
  `role` enum('super_admin','librarian') NOT NULL DEFAULT 'librarian',
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `last_login` datetime DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`admin_id`),
  UNIQUE KEY `uk_admins_username` (`username`),
  UNIQUE KEY `uk_admins_email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admins`
--

LOCK TABLES `admins` WRITE;
/*!40000 ALTER TABLE `admins` DISABLE KEYS */;
INSERT INTO `admins` VALUES
(1,'admin','$2b$12$/uhh/4xtx6caKzMRhOCvreAyVU3c3RiLn9atJLvGaw5OcJslds8Te','System Administrator','admin@citylibrary.local','super_admin',1,NULL,'2026-07-25 01:10:17'),
(2,'librarian1','$2b$12$/uhh/4xtx6caKzMRhOCvreAyVU3c3RiLn9atJLvGaw5OcJslds8Te','Priya Sharma','priya.sharma@citylibrary.local','librarian',1,NULL,'2026-07-25 01:10:17');
/*!40000 ALTER TABLE `admins` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `audit_log`
--

DROP TABLE IF EXISTS `audit_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `audit_log` (
  `log_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `table_name` varchar(50) NOT NULL,
  `action` enum('INSERT','UPDATE','DELETE') NOT NULL,
  `record_id` int(11) NOT NULL,
  `changed_by` varchar(100) DEFAULT NULL,
  `details` varchar(500) DEFAULT NULL,
  `changed_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`log_id`),
  KEY `idx_audit_table_record` (`table_name`,`record_id`)
) ENGINE=InnoDB AUTO_INCREMENT=1075 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `audit_log`
--

LOCK TABLES `audit_log` WRITE;
/*!40000 ALTER TABLE `audit_log` DISABLE KEYS */;
INSERT INTO `audit_log` VALUES
(1,'books','UPDATE',17,NULL,'title=Higher Engineering Mathematics | total_copies:8->8 | available_copies:8->7','2026-07-25 01:10:17'),
(2,'books','UPDATE',17,NULL,'title=Higher Engineering Mathematics | total_copies:8->8 | available_copies:7->8','2026-07-25 01:10:17'),
(3,'books','UPDATE',39,NULL,'title=The Innovators | total_copies:3->3 | available_copies:3->2','2026-07-25 01:10:17'),
(4,'books','UPDATE',39,NULL,'title=The Innovators | total_copies:3->3 | available_copies:2->3','2026-07-25 01:10:17'),
(5,'books','UPDATE',60,NULL,'title=How to Win Friends and Influence People | total_copies:7->7 | available_copies:7->6','2026-07-25 01:10:17'),
(6,'books','UPDATE',60,NULL,'title=How to Win Friends and Influence People | total_copies:7->7 | available_copies:6->7','2026-07-25 01:10:17'),
(7,'books','UPDATE',60,NULL,'title=How to Win Friends and Influence People | total_copies:7->7 | available_copies:7->6','2026-07-25 01:10:17'),
(8,'books','UPDATE',60,NULL,'title=How to Win Friends and Influence People | total_copies:7->7 | available_copies:6->7','2026-07-25 01:10:17'),
(9,'books','UPDATE',57,NULL,'title=Atomic Habits | total_copies:10->10 | available_copies:10->9','2026-07-25 01:10:17'),
(10,'books','UPDATE',57,NULL,'title=Atomic Habits | total_copies:10->10 | available_copies:9->10','2026-07-25 01:10:17'),
(11,'books','UPDATE',31,NULL,'title=1984 | total_copies:10->10 | available_copies:10->9','2026-07-25 01:10:17'),
(12,'books','UPDATE',31,NULL,'title=1984 | total_copies:10->10 | available_copies:9->10','2026-07-25 01:10:17'),
(13,'books','UPDATE',5,NULL,'title=Java: The Complete Reference | total_copies:9->9 | available_copies:9->8','2026-07-25 01:10:17'),
(14,'books','UPDATE',5,NULL,'title=Java: The Complete Reference | total_copies:9->9 | available_copies:8->9','2026-07-25 01:10:17'),
(15,'books','UPDATE',57,NULL,'title=Atomic Habits | total_copies:10->10 | available_copies:10->9','2026-07-25 01:10:17'),
(16,'books','UPDATE',57,NULL,'title=Atomic Habits | total_copies:10->10 | available_copies:9->10','2026-07-25 01:10:17'),
(17,'books','UPDATE',42,NULL,'title=Sapiens: A Brief History of Humankind | total_copies:8->8 | available_copies:8->7','2026-07-25 01:10:17'),
(18,'books','UPDATE',42,NULL,'title=Sapiens: A Brief History of Humankind | total_copies:8->8 | available_copies:7->8','2026-07-25 01:10:17'),
(19,'books','UPDATE',64,NULL,'title=Digital Fundamentals | total_copies:5->5 | available_copies:5->4','2026-07-25 01:10:17'),
(20,'books','UPDATE',64,NULL,'title=Digital Fundamentals | total_copies:5->5 | available_copies:4->5','2026-07-25 01:10:17'),
(21,'books','UPDATE',31,NULL,'title=1984 | total_copies:10->10 | available_copies:10->9','2026-07-25 01:10:17'),
(22,'books','UPDATE',31,NULL,'title=1984 | total_copies:10->10 | available_copies:9->10','2026-07-25 01:10:17'),
(23,'books','UPDATE',43,NULL,'title=Homo Deus | total_copies:5->5 | available_copies:5->4','2026-07-25 01:10:17'),
(24,'books','UPDATE',43,NULL,'title=Homo Deus | total_copies:5->5 | available_copies:4->5','2026-07-25 01:10:17'),
(25,'books','UPDATE',31,NULL,'title=1984 | total_copies:10->10 | available_copies:10->9','2026-07-25 01:10:17'),
(26,'books','UPDATE',31,NULL,'title=1984 | total_copies:10->10 | available_copies:9->10','2026-07-25 01:10:17'),
(27,'books','UPDATE',28,NULL,'title=And Then There Were None | total_copies:9->9 | available_copies:9->8','2026-07-25 01:10:17'),
(28,'books','UPDATE',28,NULL,'title=And Then There Were None | total_copies:9->9 | available_copies:8->9','2026-07-25 01:10:17'),
(29,'books','UPDATE',54,NULL,'title=The Tipping Point | total_copies:5->5 | available_copies:5->4','2026-07-25 01:10:17'),
(30,'books','UPDATE',54,NULL,'title=The Tipping Point | total_copies:5->5 | available_copies:4->5','2026-07-25 01:10:17'),
(31,'books','UPDATE',56,NULL,'title=David and Goliath | total_copies:3->3 | available_copies:3->2','2026-07-25 01:10:17'),
(32,'books','UPDATE',56,NULL,'title=David and Goliath | total_copies:3->3 | available_copies:2->3','2026-07-25 01:10:17'),
(33,'books','UPDATE',55,NULL,'title=Blink | total_copies:4->4 | available_copies:4->3','2026-07-25 01:10:17'),
(34,'books','UPDATE',55,NULL,'title=Blink | total_copies:4->4 | available_copies:3->4','2026-07-25 01:10:17'),
(35,'books','UPDATE',9,NULL,'title=Let Us C++ | total_copies:7->7 | available_copies:7->6','2026-07-25 01:10:17'),
(36,'books','UPDATE',9,NULL,'title=Let Us C++ | total_copies:7->7 | available_copies:6->7','2026-07-25 01:10:17'),
(37,'books','UPDATE',53,NULL,'title=Outliers | total_copies:6->6 | available_copies:6->5','2026-07-25 01:10:17'),
(38,'books','UPDATE',53,NULL,'title=Outliers | total_copies:6->6 | available_copies:5->6','2026-07-25 01:10:17'),
(39,'books','UPDATE',31,NULL,'title=1984 | total_copies:10->10 | available_copies:10->9','2026-07-25 01:10:17'),
(40,'books','UPDATE',31,NULL,'title=1984 | total_copies:10->10 | available_copies:9->10','2026-07-25 01:10:17'),
(41,'books','UPDATE',49,NULL,'title=Think and Grow Rich | total_copies:8->8 | available_copies:8->7','2026-07-25 01:10:17'),
(42,'books','UPDATE',49,NULL,'title=Think and Grow Rich | total_copies:8->8 | available_copies:7->8','2026-07-25 01:10:17'),
(43,'books','UPDATE',40,NULL,'title=Wings of Fire | total_copies:8->8 | available_copies:8->7','2026-07-25 01:10:17'),
(44,'books','UPDATE',40,NULL,'title=Wings of Fire | total_copies:8->8 | available_copies:7->8','2026-07-25 01:10:17'),
(45,'books','UPDATE',33,NULL,'title=Malgudi Days | total_copies:7->7 | available_copies:7->6','2026-07-25 01:10:17'),
(46,'books','UPDATE',33,NULL,'title=Malgudi Days | total_copies:7->7 | available_copies:6->7','2026-07-25 01:10:17'),
(47,'books','UPDATE',31,NULL,'title=1984 | total_copies:10->10 | available_copies:10->9','2026-07-25 01:10:17'),
(48,'books','UPDATE',31,NULL,'title=1984 | total_copies:10->10 | available_copies:9->10','2026-07-25 01:10:17'),
(49,'books','UPDATE',30,NULL,'title=Death on the Nile | total_copies:6->6 | available_copies:6->5','2026-07-25 01:10:17'),
(50,'books','UPDATE',30,NULL,'title=Death on the Nile | total_copies:6->6 | available_copies:5->6','2026-07-25 01:10:17'),
(51,'books','UPDATE',57,NULL,'title=Atomic Habits | total_copies:10->10 | available_copies:10->9','2026-07-25 01:10:17'),
(52,'books','UPDATE',57,NULL,'title=Atomic Habits | total_copies:10->10 | available_copies:9->10','2026-07-25 01:10:17'),
(53,'books','UPDATE',44,NULL,'title=21 Lessons for the 21st Century | total_copies:4->4 | available_copies:4->3','2026-07-25 01:10:18'),
(54,'books','UPDATE',44,NULL,'title=21 Lessons for the 21st Century | total_copies:4->4 | available_copies:3->4','2026-07-25 01:10:18'),
(55,'books','UPDATE',27,NULL,'title=Murder on the Orient Express | total_copies:8->8 | available_copies:8->7','2026-07-25 01:10:18'),
(56,'books','UPDATE',27,NULL,'title=Murder on the Orient Express | total_copies:8->8 | available_copies:7->8','2026-07-25 01:10:18'),
(57,'books','UPDATE',6,NULL,'title=C++: The Complete Reference | total_copies:6->6 | available_copies:6->5','2026-07-25 01:10:18'),
(58,'books','UPDATE',6,NULL,'title=C++: The Complete Reference | total_copies:6->6 | available_copies:5->6','2026-07-25 01:10:18'),
(59,'books','UPDATE',2,NULL,'title=Clean Code | total_copies:8->8 | available_copies:8->7','2026-07-25 01:10:18'),
(60,'books','UPDATE',2,NULL,'title=Clean Code | total_copies:8->8 | available_copies:7->8','2026-07-25 01:10:18'),
(61,'books','UPDATE',4,NULL,'title=The C++ Programming Language | total_copies:5->5 | available_copies:5->4','2026-07-25 01:10:18'),
(62,'books','UPDATE',4,NULL,'title=The C++ Programming Language | total_copies:5->5 | available_copies:4->5','2026-07-25 01:10:18'),
(63,'books','UPDATE',31,NULL,'title=1984 | total_copies:10->10 | available_copies:10->9','2026-07-25 01:10:18'),
(64,'books','UPDATE',31,NULL,'title=1984 | total_copies:10->10 | available_copies:9->10','2026-07-25 01:10:18'),
(65,'books','UPDATE',8,NULL,'title=Let Us C | total_copies:10->10 | available_copies:10->9','2026-07-25 01:10:18'),
(66,'books','UPDATE',8,NULL,'title=Let Us C | total_copies:10->10 | available_copies:9->10','2026-07-25 01:10:18'),
(67,'books','UPDATE',39,NULL,'title=The Innovators | total_copies:3->3 | available_copies:3->2','2026-07-25 01:10:18'),
(68,'books','UPDATE',39,NULL,'title=The Innovators | total_copies:3->3 | available_copies:2->3','2026-07-25 01:10:18'),
(69,'books','UPDATE',45,NULL,'title=India After Gandhi | total_copies:5->5 | available_copies:5->4','2026-07-25 01:10:18'),
(70,'books','UPDATE',45,NULL,'title=India After Gandhi | total_copies:5->5 | available_copies:4->5','2026-07-25 01:10:18'),
(71,'books','UPDATE',11,NULL,'title=Pointers in C | total_copies:5->5 | available_copies:5->4','2026-07-25 01:10:18'),
(72,'books','UPDATE',11,NULL,'title=Pointers in C | total_copies:5->5 | available_copies:4->5','2026-07-25 01:10:18'),
(73,'books','UPDATE',51,NULL,'title=Cashflow Quadrant | total_copies:4->4 | available_copies:4->3','2026-07-25 01:10:18'),
(74,'books','UPDATE',51,NULL,'title=Cashflow Quadrant | total_copies:4->4 | available_copies:3->4','2026-07-25 01:10:18'),
(75,'books','UPDATE',28,NULL,'title=And Then There Were None | total_copies:9->9 | available_copies:9->8','2026-07-25 01:10:18'),
(76,'books','UPDATE',28,NULL,'title=And Then There Were None | total_copies:9->9 | available_copies:8->9','2026-07-25 01:10:18'),
(77,'books','UPDATE',49,NULL,'title=Think and Grow Rich | total_copies:8->8 | available_copies:8->7','2026-07-25 01:10:18'),
(78,'books','UPDATE',49,NULL,'title=Think and Grow Rich | total_copies:8->8 | available_copies:7->8','2026-07-25 01:10:18'),
(79,'books','UPDATE',5,NULL,'title=Java: The Complete Reference | total_copies:9->9 | available_copies:9->8','2026-07-25 01:10:18'),
(80,'books','UPDATE',5,NULL,'title=Java: The Complete Reference | total_copies:9->9 | available_copies:8->9','2026-07-25 01:10:18'),
(81,'books','UPDATE',51,NULL,'title=Cashflow Quadrant | total_copies:4->4 | available_copies:4->3','2026-07-25 01:10:18'),
(82,'books','UPDATE',51,NULL,'title=Cashflow Quadrant | total_copies:4->4 | available_copies:3->4','2026-07-25 01:10:18'),
(83,'books','UPDATE',27,NULL,'title=Murder on the Orient Express | total_copies:8->8 | available_copies:8->7','2026-07-25 01:10:18'),
(84,'books','UPDATE',27,NULL,'title=Murder on the Orient Express | total_copies:8->8 | available_copies:7->8','2026-07-25 01:10:18'),
(85,'books','UPDATE',9,NULL,'title=Let Us C++ | total_copies:7->7 | available_copies:7->6','2026-07-25 01:10:18'),
(86,'books','UPDATE',9,NULL,'title=Let Us C++ | total_copies:7->7 | available_copies:6->7','2026-07-25 01:10:18'),
(87,'books','UPDATE',51,NULL,'title=Cashflow Quadrant | total_copies:4->4 | available_copies:4->3','2026-07-25 01:10:18'),
(88,'books','UPDATE',51,NULL,'title=Cashflow Quadrant | total_copies:4->4 | available_copies:3->4','2026-07-25 01:10:18'),
(89,'books','UPDATE',8,NULL,'title=Let Us C | total_copies:10->10 | available_copies:10->9','2026-07-25 01:10:18'),
(90,'books','UPDATE',8,NULL,'title=Let Us C | total_copies:10->10 | available_copies:9->10','2026-07-25 01:10:18'),
(91,'books','UPDATE',33,NULL,'title=Malgudi Days | total_copies:7->7 | available_copies:7->6','2026-07-25 01:10:18'),
(92,'books','UPDATE',33,NULL,'title=Malgudi Days | total_copies:7->7 | available_copies:6->7','2026-07-25 01:10:18'),
(93,'books','UPDATE',40,NULL,'title=Wings of Fire | total_copies:8->8 | available_copies:8->7','2026-07-25 01:10:18'),
(94,'books','UPDATE',40,NULL,'title=Wings of Fire | total_copies:8->8 | available_copies:7->8','2026-07-25 01:10:18'),
(95,'books','UPDATE',23,NULL,'title=Concepts of Physics Part 1 | total_copies:7->7 | available_copies:7->6','2026-07-25 01:10:18'),
(96,'books','UPDATE',23,NULL,'title=Concepts of Physics Part 1 | total_copies:7->7 | available_copies:6->7','2026-07-25 01:10:18'),
(97,'books','UPDATE',2,NULL,'title=Clean Code | total_copies:8->8 | available_copies:8->7','2026-07-25 01:10:18'),
(98,'books','UPDATE',2,NULL,'title=Clean Code | total_copies:8->8 | available_copies:7->8','2026-07-25 01:10:18'),
(99,'books','UPDATE',61,NULL,'title=How to Stop Worrying and Start Living | total_copies:4->4 | available_copies:4->3','2026-07-25 01:10:18'),
(100,'books','UPDATE',61,NULL,'title=How to Stop Worrying and Start Living | total_copies:4->4 | available_copies:3->4','2026-07-25 01:10:18'),
(101,'books','UPDATE',23,NULL,'title=Concepts of Physics Part 1 | total_copies:7->7 | available_copies:7->6','2026-07-25 01:10:18'),
(102,'books','UPDATE',23,NULL,'title=Concepts of Physics Part 1 | total_copies:7->7 | available_copies:6->7','2026-07-25 01:10:18'),
(103,'books','UPDATE',5,NULL,'title=Java: The Complete Reference | total_copies:9->9 | available_copies:9->8','2026-07-25 01:10:18'),
(104,'books','UPDATE',5,NULL,'title=Java: The Complete Reference | total_copies:9->9 | available_copies:8->9','2026-07-25 01:10:18'),
(105,'books','UPDATE',38,NULL,'title=Einstein: His Life and Universe | total_copies:4->4 | available_copies:4->3','2026-07-25 01:10:18'),
(106,'books','UPDATE',38,NULL,'title=Einstein: His Life and Universe | total_copies:4->4 | available_copies:3->4','2026-07-25 01:10:18'),
(107,'books','UPDATE',42,NULL,'title=Sapiens: A Brief History of Humankind | total_copies:8->8 | available_copies:8->7','2026-07-25 01:10:18'),
(108,'books','UPDATE',42,NULL,'title=Sapiens: A Brief History of Humankind | total_copies:8->8 | available_copies:7->8','2026-07-25 01:10:18'),
(109,'books','UPDATE',10,NULL,'title=Data Structures Through C | total_copies:6->6 | available_copies:6->5','2026-07-25 01:10:18'),
(110,'books','UPDATE',10,NULL,'title=Data Structures Through C | total_copies:6->6 | available_copies:5->6','2026-07-25 01:10:18'),
(111,'books','UPDATE',58,NULL,'title=The Alchemist | total_copies:9->9 | available_copies:9->8','2026-07-25 01:10:18'),
(112,'books','UPDATE',58,NULL,'title=The Alchemist | total_copies:9->9 | available_copies:8->9','2026-07-25 01:10:18'),
(113,'books','UPDATE',3,NULL,'title=Clean Architecture | total_copies:6->6 | available_copies:6->5','2026-07-25 01:10:18'),
(114,'books','UPDATE',3,NULL,'title=Clean Architecture | total_copies:6->6 | available_copies:5->6','2026-07-25 01:10:18'),
(115,'books','UPDATE',35,NULL,'title=Five Point Someone | total_copies:9->9 | available_copies:9->8','2026-07-25 01:10:18'),
(116,'books','UPDATE',35,NULL,'title=Five Point Someone | total_copies:9->9 | available_copies:8->9','2026-07-25 01:10:18'),
(117,'books','UPDATE',31,NULL,'title=1984 | total_copies:10->10 | available_copies:10->9','2026-07-25 01:10:18'),
(118,'books','UPDATE',31,NULL,'title=1984 | total_copies:10->10 | available_copies:9->10','2026-07-25 01:10:18'),
(119,'books','UPDATE',58,NULL,'title=The Alchemist | total_copies:9->9 | available_copies:9->8','2026-07-25 01:10:18'),
(120,'books','UPDATE',58,NULL,'title=The Alchemist | total_copies:9->9 | available_copies:8->9','2026-07-25 01:10:18'),
(121,'books','UPDATE',5,NULL,'title=Java: The Complete Reference | total_copies:9->9 | available_copies:9->8','2026-07-25 01:10:18'),
(122,'books','UPDATE',5,NULL,'title=Java: The Complete Reference | total_copies:9->9 | available_copies:8->9','2026-07-25 01:10:18'),
(123,'books','UPDATE',57,NULL,'title=Atomic Habits | total_copies:10->10 | available_copies:10->9','2026-07-25 01:10:18'),
(124,'books','UPDATE',57,NULL,'title=Atomic Habits | total_copies:10->10 | available_copies:9->10','2026-07-25 01:10:18'),
(125,'books','UPDATE',28,NULL,'title=And Then There Were None | total_copies:9->9 | available_copies:9->8','2026-07-25 01:10:18'),
(126,'books','UPDATE',28,NULL,'title=And Then There Were None | total_copies:9->9 | available_copies:8->9','2026-07-25 01:10:18'),
(127,'books','UPDATE',8,NULL,'title=Let Us C | total_copies:10->10 | available_copies:10->9','2026-07-25 01:10:18'),
(128,'books','UPDATE',8,NULL,'title=Let Us C | total_copies:10->10 | available_copies:9->10','2026-07-25 01:10:18'),
(129,'books','UPDATE',60,NULL,'title=How to Win Friends and Influence People | total_copies:7->7 | available_copies:7->6','2026-07-25 01:10:18'),
(130,'books','UPDATE',60,NULL,'title=How to Win Friends and Influence People | total_copies:7->7 | available_copies:6->7','2026-07-25 01:10:18'),
(131,'books','UPDATE',53,NULL,'title=Outliers | total_copies:6->6 | available_copies:6->5','2026-07-25 01:10:18'),
(132,'books','UPDATE',53,NULL,'title=Outliers | total_copies:6->6 | available_copies:5->6','2026-07-25 01:10:18'),
(133,'books','UPDATE',6,NULL,'title=C++: The Complete Reference | total_copies:6->6 | available_copies:6->5','2026-07-25 01:10:18'),
(134,'books','UPDATE',6,NULL,'title=C++: The Complete Reference | total_copies:6->6 | available_copies:5->6','2026-07-25 01:10:18'),
(135,'books','UPDATE',18,NULL,'title=Numerical Methods in Engineering and Science | total_copies:4->4 | available_copies:4->3','2026-07-25 01:10:18'),
(136,'books','UPDATE',18,NULL,'title=Numerical Methods in Engineering and Science | total_copies:4->4 | available_copies:3->4','2026-07-25 01:10:18'),
(137,'books','UPDATE',4,NULL,'title=The C++ Programming Language | total_copies:5->5 | available_copies:5->4','2026-07-25 01:10:18'),
(138,'books','UPDATE',4,NULL,'title=The C++ Programming Language | total_copies:5->5 | available_copies:4->5','2026-07-25 01:10:18'),
(139,'books','UPDATE',41,NULL,'title=Ignited Minds | total_copies:5->5 | available_copies:5->4','2026-07-25 01:10:18'),
(140,'books','UPDATE',41,NULL,'title=Ignited Minds | total_copies:5->5 | available_copies:4->5','2026-07-25 01:10:18'),
(141,'books','UPDATE',50,NULL,'title=Rich Dad Poor Dad | total_copies:9->9 | available_copies:9->8','2026-07-25 01:10:18'),
(142,'books','UPDATE',50,NULL,'title=Rich Dad Poor Dad | total_copies:9->9 | available_copies:8->9','2026-07-25 01:10:18'),
(143,'books','UPDATE',57,NULL,'title=Atomic Habits | total_copies:10->10 | available_copies:10->9','2026-07-25 01:10:18'),
(144,'books','UPDATE',57,NULL,'title=Atomic Habits | total_copies:10->10 | available_copies:9->10','2026-07-25 01:10:18'),
(145,'books','UPDATE',2,NULL,'title=Clean Code | total_copies:8->8 | available_copies:8->7','2026-07-25 01:10:18'),
(146,'books','UPDATE',2,NULL,'title=Clean Code | total_copies:8->8 | available_copies:7->8','2026-07-25 01:10:18'),
(147,'books','UPDATE',14,NULL,'title=Introduction to Linear Algebra | total_copies:4->4 | available_copies:4->3','2026-07-25 01:10:18'),
(148,'books','UPDATE',14,NULL,'title=Introduction to Linear Algebra | total_copies:4->4 | available_copies:3->4','2026-07-25 01:10:18'),
(149,'books','UPDATE',7,NULL,'title=C: The Complete Reference | total_copies:7->7 | available_copies:7->6','2026-07-25 01:10:18'),
(150,'books','UPDATE',7,NULL,'title=C: The Complete Reference | total_copies:7->7 | available_copies:6->7','2026-07-25 01:10:18'),
(151,'books','UPDATE',33,NULL,'title=Malgudi Days | total_copies:7->7 | available_copies:7->6','2026-07-25 01:10:18'),
(152,'books','UPDATE',33,NULL,'title=Malgudi Days | total_copies:7->7 | available_copies:6->7','2026-07-25 01:10:18'),
(153,'books','UPDATE',30,NULL,'title=Death on the Nile | total_copies:6->6 | available_copies:6->5','2026-07-25 01:10:18'),
(154,'books','UPDATE',30,NULL,'title=Death on the Nile | total_copies:6->6 | available_copies:5->6','2026-07-25 01:10:18'),
(155,'books','UPDATE',20,NULL,'title=A Brief History of Time | total_copies:6->6 | available_copies:6->5','2026-07-25 01:10:18'),
(156,'books','UPDATE',20,NULL,'title=A Brief History of Time | total_copies:6->6 | available_copies:5->6','2026-07-25 01:10:18'),
(157,'books','UPDATE',17,NULL,'title=Higher Engineering Mathematics | total_copies:8->8 | available_copies:8->7','2026-07-25 01:10:18'),
(158,'books','UPDATE',17,NULL,'title=Higher Engineering Mathematics | total_copies:8->8 | available_copies:7->8','2026-07-25 01:10:18'),
(159,'books','UPDATE',65,NULL,'title=Principles of Electric Circuits | total_copies:3->3 | available_copies:3->2','2026-07-25 01:10:18'),
(160,'books','UPDATE',65,NULL,'title=Principles of Electric Circuits | total_copies:3->3 | available_copies:2->3','2026-07-25 01:10:18'),
(161,'books','UPDATE',27,NULL,'title=Murder on the Orient Express | total_copies:8->8 | available_copies:8->7','2026-07-25 01:10:18'),
(162,'books','UPDATE',27,NULL,'title=Murder on the Orient Express | total_copies:8->8 | available_copies:7->8','2026-07-25 01:10:18'),
(163,'books','UPDATE',52,NULL,'title=Rich Dad\'s Guide to Investing | total_copies:3->3 | available_copies:3->2','2026-07-25 01:10:18'),
(164,'books','UPDATE',52,NULL,'title=Rich Dad\'s Guide to Investing | total_copies:3->3 | available_copies:2->3','2026-07-25 01:10:18'),
(165,'books','UPDATE',2,NULL,'title=Clean Code | total_copies:8->8 | available_copies:8->7','2026-07-25 01:10:18'),
(166,'books','UPDATE',2,NULL,'title=Clean Code | total_copies:8->8 | available_copies:7->8','2026-07-25 01:10:18'),
(167,'books','UPDATE',74,NULL,'title=Crito | total_copies:2->2 | available_copies:2->1','2026-07-25 01:10:18'),
(168,'books','UPDATE',74,NULL,'title=Crito | total_copies:2->2 | available_copies:1->2','2026-07-25 01:10:18'),
(169,'books','UPDATE',9,NULL,'title=Let Us C++ | total_copies:7->7 | available_copies:7->6','2026-07-25 01:10:18'),
(170,'books','UPDATE',9,NULL,'title=Let Us C++ | total_copies:7->7 | available_copies:6->7','2026-07-25 01:10:18'),
(171,'books','UPDATE',58,NULL,'title=The Alchemist | total_copies:9->9 | available_copies:9->8','2026-07-25 01:10:18'),
(172,'books','UPDATE',58,NULL,'title=The Alchemist | total_copies:9->9 | available_copies:8->9','2026-07-25 01:10:18'),
(173,'books','UPDATE',70,NULL,'title=The Republic | total_copies:5->5 | available_copies:5->4','2026-07-25 01:10:18'),
(174,'books','UPDATE',70,NULL,'title=The Republic | total_copies:5->5 | available_copies:4->5','2026-07-25 01:10:18'),
(175,'books','UPDATE',55,NULL,'title=Blink | total_copies:4->4 | available_copies:4->3','2026-07-25 01:10:18'),
(176,'books','UPDATE',55,NULL,'title=Blink | total_copies:4->4 | available_copies:3->4','2026-07-25 01:10:18'),
(177,'books','UPDATE',53,NULL,'title=Outliers | total_copies:6->6 | available_copies:6->5','2026-07-25 01:10:18'),
(178,'books','UPDATE',53,NULL,'title=Outliers | total_copies:6->6 | available_copies:5->6','2026-07-25 01:10:18'),
(179,'books','UPDATE',7,NULL,'title=C: The Complete Reference | total_copies:7->7 | available_copies:7->6','2026-07-25 01:10:18'),
(180,'books','UPDATE',7,NULL,'title=C: The Complete Reference | total_copies:7->7 | available_copies:6->7','2026-07-25 01:10:18'),
(181,'books','UPDATE',57,NULL,'title=Atomic Habits | total_copies:10->10 | available_copies:10->9','2026-07-25 01:10:18'),
(182,'books','UPDATE',57,NULL,'title=Atomic Habits | total_copies:10->10 | available_copies:9->10','2026-07-25 01:10:18'),
(183,'books','UPDATE',64,NULL,'title=Digital Fundamentals | total_copies:5->5 | available_copies:5->4','2026-07-25 01:10:18'),
(184,'books','UPDATE',64,NULL,'title=Digital Fundamentals | total_copies:5->5 | available_copies:4->5','2026-07-25 01:10:18'),
(185,'books','UPDATE',40,NULL,'title=Wings of Fire | total_copies:8->8 | available_copies:8->7','2026-07-25 01:10:18'),
(186,'books','UPDATE',40,NULL,'title=Wings of Fire | total_copies:8->8 | available_copies:7->8','2026-07-25 01:10:18'),
(187,'books','UPDATE',43,NULL,'title=Homo Deus | total_copies:5->5 | available_copies:5->4','2026-07-25 01:10:18'),
(188,'books','UPDATE',43,NULL,'title=Homo Deus | total_copies:5->5 | available_copies:4->5','2026-07-25 01:10:18'),
(189,'books','UPDATE',64,NULL,'title=Digital Fundamentals | total_copies:5->5 | available_copies:5->4','2026-07-25 01:10:18'),
(190,'books','UPDATE',64,NULL,'title=Digital Fundamentals | total_copies:5->5 | available_copies:4->5','2026-07-25 01:10:18'),
(191,'books','UPDATE',59,NULL,'title=Veronika Decides to Die | total_copies:4->4 | available_copies:4->3','2026-07-25 01:10:18'),
(192,'books','UPDATE',59,NULL,'title=Veronika Decides to Die | total_copies:4->4 | available_copies:3->4','2026-07-25 01:10:18'),
(193,'books','UPDATE',31,NULL,'title=1984 | total_copies:10->10 | available_copies:10->9','2026-07-25 01:10:18'),
(194,'books','UPDATE',31,NULL,'title=1984 | total_copies:10->10 | available_copies:9->10','2026-07-25 01:10:18'),
(195,'books','UPDATE',21,NULL,'title=The Universe in a Nutshell | total_copies:4->4 | available_copies:4->3','2026-07-25 01:10:18'),
(196,'books','UPDATE',21,NULL,'title=The Universe in a Nutshell | total_copies:4->4 | available_copies:3->4','2026-07-25 01:10:18'),
(197,'books','UPDATE',22,NULL,'title=Concepts of Modern Physics | total_copies:5->5 | available_copies:5->4','2026-07-25 01:10:18'),
(198,'books','UPDATE',22,NULL,'title=Concepts of Modern Physics | total_copies:5->5 | available_copies:4->5','2026-07-25 01:10:18'),
(199,'books','UPDATE',58,NULL,'title=The Alchemist | total_copies:9->9 | available_copies:9->8','2026-07-25 01:10:18'),
(200,'books','UPDATE',58,NULL,'title=The Alchemist | total_copies:9->9 | available_copies:8->9','2026-07-25 01:10:18'),
(201,'books','UPDATE',52,NULL,'title=Rich Dad\'s Guide to Investing | total_copies:3->3 | available_copies:3->2','2026-07-25 01:10:18'),
(202,'books','UPDATE',52,NULL,'title=Rich Dad\'s Guide to Investing | total_copies:3->3 | available_copies:2->3','2026-07-25 01:10:18'),
(203,'books','UPDATE',64,NULL,'title=Digital Fundamentals | total_copies:5->5 | available_copies:5->4','2026-07-25 01:10:18'),
(204,'books','UPDATE',64,NULL,'title=Digital Fundamentals | total_copies:5->5 | available_copies:4->5','2026-07-25 01:10:18'),
(205,'books','UPDATE',32,NULL,'title=Animal Farm | total_copies:9->9 | available_copies:9->8','2026-07-25 01:10:18'),
(206,'books','UPDATE',32,NULL,'title=Animal Farm | total_copies:9->9 | available_copies:8->9','2026-07-25 01:10:18'),
(207,'books','UPDATE',7,NULL,'title=C: The Complete Reference | total_copies:7->7 | available_copies:7->6','2026-07-25 01:10:18'),
(208,'books','UPDATE',7,NULL,'title=C: The Complete Reference | total_copies:7->7 | available_copies:6->7','2026-07-25 01:10:18'),
(209,'books','UPDATE',27,NULL,'title=Murder on the Orient Express | total_copies:8->8 | available_copies:8->7','2026-07-25 01:10:18'),
(210,'books','UPDATE',27,NULL,'title=Murder on the Orient Express | total_copies:8->8 | available_copies:7->8','2026-07-25 01:10:18'),
(211,'books','UPDATE',68,NULL,'title=Computer System Architecture | total_copies:4->4 | available_copies:4->3','2026-07-25 01:10:18'),
(212,'books','UPDATE',68,NULL,'title=Computer System Architecture | total_copies:4->4 | available_copies:3->4','2026-07-25 01:10:18'),
(213,'books','UPDATE',39,NULL,'title=The Innovators | total_copies:3->3 | available_copies:3->2','2026-07-25 01:10:18'),
(214,'books','UPDATE',39,NULL,'title=The Innovators | total_copies:3->3 | available_copies:2->3','2026-07-25 01:10:18'),
(215,'books','UPDATE',8,NULL,'title=Let Us C | total_copies:10->10 | available_copies:10->9','2026-07-25 01:10:18'),
(216,'books','UPDATE',8,NULL,'title=Let Us C | total_copies:10->10 | available_copies:9->10','2026-07-25 01:10:18'),
(217,'books','UPDATE',33,NULL,'title=Malgudi Days | total_copies:7->7 | available_copies:7->6','2026-07-25 01:10:18'),
(218,'books','UPDATE',33,NULL,'title=Malgudi Days | total_copies:7->7 | available_copies:6->7','2026-07-25 01:10:18'),
(219,'books','UPDATE',45,NULL,'title=India After Gandhi | total_copies:5->5 | available_copies:5->4','2026-07-25 01:10:18'),
(220,'books','UPDATE',45,NULL,'title=India After Gandhi | total_copies:5->5 | available_copies:4->5','2026-07-25 01:10:18'),
(221,'books','UPDATE',37,NULL,'title=Steve Jobs | total_copies:6->6 | available_copies:6->5','2026-07-25 01:10:18'),
(222,'books','UPDATE',37,NULL,'title=Steve Jobs | total_copies:6->6 | available_copies:5->6','2026-07-25 01:10:18'),
(223,'books','UPDATE',2,NULL,'title=Clean Code | total_copies:8->8 | available_copies:8->7','2026-07-25 01:10:18'),
(224,'books','UPDATE',2,NULL,'title=Clean Code | total_copies:8->8 | available_copies:7->8','2026-07-25 01:10:18'),
(225,'books','UPDATE',47,NULL,'title=Makers of Modern India | total_copies:3->3 | available_copies:3->2','2026-07-25 01:10:18'),
(226,'books','UPDATE',47,NULL,'title=Makers of Modern India | total_copies:3->3 | available_copies:2->3','2026-07-25 01:10:18'),
(227,'books','UPDATE',36,NULL,'title=2 States | total_copies:8->8 | available_copies:8->7','2026-07-25 01:10:18'),
(228,'books','UPDATE',36,NULL,'title=2 States | total_copies:8->8 | available_copies:7->8','2026-07-25 01:10:18'),
(229,'books','UPDATE',35,NULL,'title=Five Point Someone | total_copies:9->9 | available_copies:9->8','2026-07-25 01:10:18'),
(230,'books','UPDATE',35,NULL,'title=Five Point Someone | total_copies:9->9 | available_copies:8->9','2026-07-25 01:10:18'),
(231,'books','UPDATE',36,NULL,'title=2 States | total_copies:8->8 | available_copies:8->7','2026-07-25 01:10:18'),
(232,'books','UPDATE',36,NULL,'title=2 States | total_copies:8->8 | available_copies:7->8','2026-07-25 01:10:18'),
(233,'books','UPDATE',32,NULL,'title=Animal Farm | total_copies:9->9 | available_copies:9->8','2026-07-25 01:10:18'),
(234,'books','UPDATE',32,NULL,'title=Animal Farm | total_copies:9->9 | available_copies:8->9','2026-07-25 01:10:18'),
(235,'books','UPDATE',57,NULL,'title=Atomic Habits | total_copies:10->10 | available_copies:10->9','2026-07-25 01:10:18'),
(236,'books','UPDATE',57,NULL,'title=Atomic Habits | total_copies:10->10 | available_copies:9->10','2026-07-25 01:10:18'),
(237,'books','UPDATE',61,NULL,'title=How to Stop Worrying and Start Living | total_copies:4->4 | available_copies:4->3','2026-07-25 01:10:18'),
(238,'books','UPDATE',61,NULL,'title=How to Stop Worrying and Start Living | total_copies:4->4 | available_copies:3->4','2026-07-25 01:10:18'),
(239,'books','UPDATE',8,NULL,'title=Let Us C | total_copies:10->10 | available_copies:10->9','2026-07-25 01:10:18'),
(240,'books','UPDATE',8,NULL,'title=Let Us C | total_copies:10->10 | available_copies:9->10','2026-07-25 01:10:18'),
(241,'books','UPDATE',3,NULL,'title=Clean Architecture | total_copies:6->6 | available_copies:6->5','2026-07-25 01:10:18'),
(242,'books','UPDATE',3,NULL,'title=Clean Architecture | total_copies:6->6 | available_copies:5->6','2026-07-25 01:10:18'),
(243,'books','UPDATE',29,NULL,'title=The Murder of Roger Ackroyd | total_copies:6->6 | available_copies:6->5','2026-07-25 01:10:18'),
(244,'books','UPDATE',29,NULL,'title=The Murder of Roger Ackroyd | total_copies:6->6 | available_copies:5->6','2026-07-25 01:10:18'),
(245,'books','UPDATE',42,NULL,'title=Sapiens: A Brief History of Humankind | total_copies:8->8 | available_copies:8->7','2026-07-25 01:10:18'),
(246,'books','UPDATE',42,NULL,'title=Sapiens: A Brief History of Humankind | total_copies:8->8 | available_copies:7->8','2026-07-25 01:10:18'),
(247,'books','UPDATE',29,NULL,'title=The Murder of Roger Ackroyd | total_copies:6->6 | available_copies:6->5','2026-07-25 01:10:18'),
(248,'books','UPDATE',29,NULL,'title=The Murder of Roger Ackroyd | total_copies:6->6 | available_copies:5->6','2026-07-25 01:10:18'),
(249,'books','UPDATE',63,NULL,'title=Electronic Devices and Circuit Theory | total_copies:5->5 | available_copies:5->4','2026-07-25 01:10:18'),
(250,'books','UPDATE',63,NULL,'title=Electronic Devices and Circuit Theory | total_copies:5->5 | available_copies:4->5','2026-07-25 01:10:18'),
(251,'books','UPDATE',17,NULL,'title=Higher Engineering Mathematics | total_copies:8->8 | available_copies:8->7','2026-07-25 01:10:18'),
(252,'books','UPDATE',17,NULL,'title=Higher Engineering Mathematics | total_copies:8->8 | available_copies:7->8','2026-07-25 01:10:18'),
(253,'books','UPDATE',10,NULL,'title=Data Structures Through C | total_copies:6->6 | available_copies:6->5','2026-07-25 01:10:18'),
(254,'books','UPDATE',10,NULL,'title=Data Structures Through C | total_copies:6->6 | available_copies:5->6','2026-07-25 01:10:18'),
(255,'books','UPDATE',50,NULL,'title=Rich Dad Poor Dad | total_copies:9->9 | available_copies:9->8','2026-07-25 01:10:18'),
(256,'books','UPDATE',50,NULL,'title=Rich Dad Poor Dad | total_copies:9->9 | available_copies:8->9','2026-07-25 01:10:18'),
(257,'books','UPDATE',33,NULL,'title=Malgudi Days | total_copies:7->7 | available_copies:7->6','2026-07-25 01:10:18'),
(258,'books','UPDATE',33,NULL,'title=Malgudi Days | total_copies:7->7 | available_copies:6->7','2026-07-25 01:10:18'),
(259,'books','UPDATE',1,NULL,'title=Introduction to Algorithms | total_copies:7->7 | available_copies:7->6','2026-07-25 01:10:18'),
(260,'books','UPDATE',1,NULL,'title=Introduction to Algorithms | total_copies:7->7 | available_copies:6->7','2026-07-25 01:10:18'),
(261,'books','UPDATE',43,NULL,'title=Homo Deus | total_copies:5->5 | available_copies:5->4','2026-07-25 01:10:18'),
(262,'books','UPDATE',43,NULL,'title=Homo Deus | total_copies:5->5 | available_copies:4->5','2026-07-25 01:10:18'),
(263,'books','UPDATE',47,NULL,'title=Makers of Modern India | total_copies:3->3 | available_copies:3->2','2026-07-25 01:10:18'),
(264,'books','UPDATE',47,NULL,'title=Makers of Modern India | total_copies:3->3 | available_copies:2->3','2026-07-25 01:10:18'),
(265,'books','UPDATE',8,NULL,'title=Let Us C | total_copies:10->10 | available_copies:10->9','2026-07-25 01:10:18'),
(266,'books','UPDATE',8,NULL,'title=Let Us C | total_copies:10->10 | available_copies:9->10','2026-07-25 01:10:18'),
(267,'books','UPDATE',46,NULL,'title=Gandhi Before India | total_copies:3->3 | available_copies:3->2','2026-07-25 01:10:18'),
(268,'books','UPDATE',46,NULL,'title=Gandhi Before India | total_copies:3->3 | available_copies:2->3','2026-07-25 01:10:18'),
(269,'books','UPDATE',61,NULL,'title=How to Stop Worrying and Start Living | total_copies:4->4 | available_copies:4->3','2026-07-25 01:10:18'),
(270,'books','UPDATE',61,NULL,'title=How to Stop Worrying and Start Living | total_copies:4->4 | available_copies:3->4','2026-07-25 01:10:18'),
(271,'books','UPDATE',23,NULL,'title=Concepts of Physics Part 1 | total_copies:7->7 | available_copies:7->6','2026-07-25 01:10:18'),
(272,'books','UPDATE',23,NULL,'title=Concepts of Physics Part 1 | total_copies:7->7 | available_copies:6->7','2026-07-25 01:10:18'),
(273,'books','UPDATE',56,NULL,'title=David and Goliath | total_copies:3->3 | available_copies:3->2','2026-07-25 01:10:18'),
(274,'books','UPDATE',56,NULL,'title=David and Goliath | total_copies:3->3 | available_copies:2->3','2026-07-25 01:10:18'),
(275,'books','UPDATE',50,NULL,'title=Rich Dad Poor Dad | total_copies:9->9 | available_copies:9->8','2026-07-25 01:10:18'),
(276,'books','UPDATE',50,NULL,'title=Rich Dad Poor Dad | total_copies:9->9 | available_copies:8->9','2026-07-25 01:10:18'),
(277,'books','UPDATE',49,NULL,'title=Think and Grow Rich | total_copies:8->8 | available_copies:8->7','2026-07-25 01:10:18'),
(278,'books','UPDATE',49,NULL,'title=Think and Grow Rich | total_copies:8->8 | available_copies:7->8','2026-07-25 01:10:18'),
(279,'books','UPDATE',29,NULL,'title=The Murder of Roger Ackroyd | total_copies:6->6 | available_copies:6->5','2026-07-25 01:10:18'),
(280,'books','UPDATE',29,NULL,'title=The Murder of Roger Ackroyd | total_copies:6->6 | available_copies:5->6','2026-07-25 01:10:18'),
(281,'books','UPDATE',28,NULL,'title=And Then There Were None | total_copies:9->9 | available_copies:9->8','2026-07-25 01:10:18'),
(282,'books','UPDATE',28,NULL,'title=And Then There Were None | total_copies:9->9 | available_copies:8->9','2026-07-25 01:10:18'),
(283,'books','UPDATE',72,NULL,'title=Apology | total_copies:3->3 | available_copies:3->2','2026-07-25 01:10:18'),
(284,'books','UPDATE',72,NULL,'title=Apology | total_copies:3->3 | available_copies:2->3','2026-07-25 01:10:18'),
(285,'books','UPDATE',45,NULL,'title=India After Gandhi | total_copies:5->5 | available_copies:5->4','2026-07-25 01:10:18'),
(286,'books','UPDATE',45,NULL,'title=India After Gandhi | total_copies:5->5 | available_copies:4->5','2026-07-25 01:10:18'),
(287,'books','UPDATE',10,NULL,'title=Data Structures Through C | total_copies:6->6 | available_copies:6->5','2026-07-25 01:10:18'),
(288,'books','UPDATE',10,NULL,'title=Data Structures Through C | total_copies:6->6 | available_copies:5->6','2026-07-25 01:10:18'),
(289,'books','UPDATE',11,NULL,'title=Pointers in C | total_copies:5->5 | available_copies:5->4','2026-07-25 01:10:18'),
(290,'books','UPDATE',11,NULL,'title=Pointers in C | total_copies:5->5 | available_copies:4->5','2026-07-25 01:10:18'),
(291,'books','UPDATE',29,NULL,'title=The Murder of Roger Ackroyd | total_copies:6->6 | available_copies:6->5','2026-07-25 01:10:18'),
(292,'books','UPDATE',29,NULL,'title=The Murder of Roger Ackroyd | total_copies:6->6 | available_copies:5->6','2026-07-25 01:10:18'),
(293,'books','UPDATE',36,NULL,'title=2 States | total_copies:8->8 | available_copies:8->7','2026-07-25 01:10:18'),
(294,'books','UPDATE',36,NULL,'title=2 States | total_copies:8->8 | available_copies:7->8','2026-07-25 01:10:18'),
(295,'books','UPDATE',20,NULL,'title=A Brief History of Time | total_copies:6->6 | available_copies:6->5','2026-07-25 01:10:18'),
(296,'books','UPDATE',20,NULL,'title=A Brief History of Time | total_copies:6->6 | available_copies:5->6','2026-07-25 01:10:18'),
(297,'books','UPDATE',68,NULL,'title=Computer System Architecture | total_copies:4->4 | available_copies:4->3','2026-07-25 01:10:18'),
(298,'books','UPDATE',68,NULL,'title=Computer System Architecture | total_copies:4->4 | available_copies:3->4','2026-07-25 01:10:18'),
(299,'books','UPDATE',20,NULL,'title=A Brief History of Time | total_copies:6->6 | available_copies:6->5','2026-07-25 01:10:18'),
(300,'books','UPDATE',20,NULL,'title=A Brief History of Time | total_copies:6->6 | available_copies:5->6','2026-07-25 01:10:18'),
(301,'books','UPDATE',61,NULL,'title=How to Stop Worrying and Start Living | total_copies:4->4 | available_copies:4->3','2026-07-25 01:10:18'),
(302,'books','UPDATE',61,NULL,'title=How to Stop Worrying and Start Living | total_copies:4->4 | available_copies:3->4','2026-07-25 01:10:18'),
(303,'books','UPDATE',11,NULL,'title=Pointers in C | total_copies:5->5 | available_copies:5->4','2026-07-25 01:10:18'),
(304,'books','UPDATE',11,NULL,'title=Pointers in C | total_copies:5->5 | available_copies:4->5','2026-07-25 01:10:18'),
(305,'books','UPDATE',16,NULL,'title=Differential Equations and Linear Algebra | total_copies:4->4 | available_copies:4->3','2026-07-25 01:10:18'),
(306,'books','UPDATE',16,NULL,'title=Differential Equations and Linear Algebra | total_copies:4->4 | available_copies:3->4','2026-07-25 01:10:18'),
(307,'books','UPDATE',11,NULL,'title=Pointers in C | total_copies:5->5 | available_copies:5->4','2026-07-25 01:10:18'),
(308,'books','UPDATE',11,NULL,'title=Pointers in C | total_copies:5->5 | available_copies:4->5','2026-07-25 01:10:18'),
(309,'books','UPDATE',61,NULL,'title=How to Stop Worrying and Start Living | total_copies:4->4 | available_copies:4->3','2026-07-25 01:10:18'),
(310,'books','UPDATE',61,NULL,'title=How to Stop Worrying and Start Living | total_copies:4->4 | available_copies:3->4','2026-07-25 01:10:18'),
(311,'books','UPDATE',28,NULL,'title=And Then There Were None | total_copies:9->9 | available_copies:9->8','2026-07-25 01:10:18'),
(312,'books','UPDATE',28,NULL,'title=And Then There Were None | total_copies:9->9 | available_copies:8->9','2026-07-25 01:10:18'),
(313,'books','UPDATE',55,NULL,'title=Blink | total_copies:4->4 | available_copies:4->3','2026-07-25 01:10:18'),
(314,'books','UPDATE',55,NULL,'title=Blink | total_copies:4->4 | available_copies:3->4','2026-07-25 01:10:18'),
(315,'books','UPDATE',3,NULL,'title=Clean Architecture | total_copies:6->6 | available_copies:6->5','2026-07-25 01:10:18'),
(316,'books','UPDATE',3,NULL,'title=Clean Architecture | total_copies:6->6 | available_copies:5->6','2026-07-25 01:10:18'),
(317,'books','UPDATE',8,NULL,'title=Let Us C | total_copies:10->10 | available_copies:10->9','2026-07-25 01:10:18'),
(318,'books','UPDATE',8,NULL,'title=Let Us C | total_copies:10->10 | available_copies:9->10','2026-07-25 01:10:18'),
(319,'books','UPDATE',52,NULL,'title=Rich Dad\'s Guide to Investing | total_copies:3->3 | available_copies:3->2','2026-07-25 01:10:18'),
(320,'books','UPDATE',52,NULL,'title=Rich Dad\'s Guide to Investing | total_copies:3->3 | available_copies:2->3','2026-07-25 01:10:18'),
(321,'books','UPDATE',8,NULL,'title=Let Us C | total_copies:10->10 | available_copies:10->9','2026-07-25 01:10:18'),
(322,'books','UPDATE',8,NULL,'title=Let Us C | total_copies:10->10 | available_copies:9->10','2026-07-25 01:10:18'),
(323,'books','UPDATE',64,NULL,'title=Digital Fundamentals | total_copies:5->5 | available_copies:5->4','2026-07-25 01:10:18'),
(324,'books','UPDATE',64,NULL,'title=Digital Fundamentals | total_copies:5->5 | available_copies:4->5','2026-07-25 01:10:18'),
(325,'books','UPDATE',49,NULL,'title=Think and Grow Rich | total_copies:8->8 | available_copies:8->7','2026-07-25 01:10:18'),
(326,'books','UPDATE',49,NULL,'title=Think and Grow Rich | total_copies:8->8 | available_copies:7->8','2026-07-25 01:10:18'),
(327,'books','UPDATE',1,NULL,'title=Introduction to Algorithms | total_copies:7->7 | available_copies:7->6','2026-07-25 01:10:18'),
(328,'books','UPDATE',1,NULL,'title=Introduction to Algorithms | total_copies:7->7 | available_copies:6->7','2026-07-25 01:10:18'),
(329,'books','UPDATE',33,NULL,'title=Malgudi Days | total_copies:7->7 | available_copies:7->6','2026-07-25 01:10:18'),
(330,'books','UPDATE',33,NULL,'title=Malgudi Days | total_copies:7->7 | available_copies:6->7','2026-07-25 01:10:18'),
(331,'books','UPDATE',10,NULL,'title=Data Structures Through C | total_copies:6->6 | available_copies:6->5','2026-07-25 01:10:18'),
(332,'books','UPDATE',10,NULL,'title=Data Structures Through C | total_copies:6->6 | available_copies:5->6','2026-07-25 01:10:18'),
(333,'books','UPDATE',31,NULL,'title=1984 | total_copies:10->10 | available_copies:10->9','2026-07-25 01:10:18'),
(334,'books','UPDATE',31,NULL,'title=1984 | total_copies:10->10 | available_copies:9->10','2026-07-25 01:10:18'),
(335,'books','UPDATE',29,NULL,'title=The Murder of Roger Ackroyd | total_copies:6->6 | available_copies:6->5','2026-07-25 01:10:18'),
(336,'books','UPDATE',29,NULL,'title=The Murder of Roger Ackroyd | total_copies:6->6 | available_copies:5->6','2026-07-25 01:10:18'),
(337,'books','UPDATE',42,NULL,'title=Sapiens: A Brief History of Humankind | total_copies:8->8 | available_copies:8->7','2026-07-25 01:10:18'),
(338,'books','UPDATE',42,NULL,'title=Sapiens: A Brief History of Humankind | total_copies:8->8 | available_copies:7->8','2026-07-25 01:10:18'),
(339,'books','UPDATE',60,NULL,'title=How to Win Friends and Influence People | total_copies:7->7 | available_copies:7->6','2026-07-25 01:10:18'),
(340,'books','UPDATE',60,NULL,'title=How to Win Friends and Influence People | total_copies:7->7 | available_copies:6->7','2026-07-25 01:10:18'),
(341,'books','UPDATE',9,NULL,'title=Let Us C++ | total_copies:7->7 | available_copies:7->6','2026-07-25 01:10:18'),
(342,'books','UPDATE',9,NULL,'title=Let Us C++ | total_copies:7->7 | available_copies:6->7','2026-07-25 01:10:18'),
(343,'books','UPDATE',20,NULL,'title=A Brief History of Time | total_copies:6->6 | available_copies:6->5','2026-07-25 01:10:18'),
(344,'books','UPDATE',20,NULL,'title=A Brief History of Time | total_copies:6->6 | available_copies:5->6','2026-07-25 01:10:18'),
(345,'books','UPDATE',51,NULL,'title=Cashflow Quadrant | total_copies:4->4 | available_copies:4->3','2026-07-25 01:10:18'),
(346,'books','UPDATE',51,NULL,'title=Cashflow Quadrant | total_copies:4->4 | available_copies:3->4','2026-07-25 01:10:18'),
(347,'books','UPDATE',30,NULL,'title=Death on the Nile | total_copies:6->6 | available_copies:6->5','2026-07-25 01:10:18'),
(348,'books','UPDATE',30,NULL,'title=Death on the Nile | total_copies:6->6 | available_copies:5->6','2026-07-25 01:10:18'),
(349,'books','UPDATE',41,NULL,'title=Ignited Minds | total_copies:5->5 | available_copies:5->4','2026-07-25 01:10:18'),
(350,'books','UPDATE',41,NULL,'title=Ignited Minds | total_copies:5->5 | available_copies:4->5','2026-07-25 01:10:18'),
(351,'books','UPDATE',45,NULL,'title=India After Gandhi | total_copies:5->5 | available_copies:5->4','2026-07-25 01:10:18'),
(352,'books','UPDATE',45,NULL,'title=India After Gandhi | total_copies:5->5 | available_copies:4->5','2026-07-25 01:10:18'),
(353,'books','UPDATE',16,NULL,'title=Differential Equations and Linear Algebra | total_copies:4->4 | available_copies:4->3','2026-07-25 01:10:18'),
(354,'books','UPDATE',16,NULL,'title=Differential Equations and Linear Algebra | total_copies:4->4 | available_copies:3->4','2026-07-25 01:10:18'),
(355,'books','UPDATE',5,NULL,'title=Java: The Complete Reference | total_copies:9->9 | available_copies:9->8','2026-07-25 01:10:18'),
(356,'books','UPDATE',5,NULL,'title=Java: The Complete Reference | total_copies:9->9 | available_copies:8->9','2026-07-25 01:10:18'),
(357,'books','UPDATE',31,NULL,'title=1984 | total_copies:10->10 | available_copies:10->9','2026-07-25 01:10:18'),
(358,'books','UPDATE',31,NULL,'title=1984 | total_copies:10->10 | available_copies:9->10','2026-07-25 01:10:18'),
(359,'books','UPDATE',58,NULL,'title=The Alchemist | total_copies:9->9 | available_copies:9->8','2026-07-25 01:10:18'),
(360,'books','UPDATE',58,NULL,'title=The Alchemist | total_copies:9->9 | available_copies:8->9','2026-07-25 01:10:18'),
(361,'books','UPDATE',46,NULL,'title=Gandhi Before India | total_copies:3->3 | available_copies:3->2','2026-07-25 01:10:18'),
(362,'books','UPDATE',46,NULL,'title=Gandhi Before India | total_copies:3->3 | available_copies:2->3','2026-07-25 01:10:18'),
(363,'books','UPDATE',17,NULL,'title=Higher Engineering Mathematics | total_copies:8->8 | available_copies:8->7','2026-07-25 01:10:18'),
(364,'books','UPDATE',17,NULL,'title=Higher Engineering Mathematics | total_copies:8->8 | available_copies:7->8','2026-07-25 01:10:18'),
(365,'books','UPDATE',31,NULL,'title=1984 | total_copies:10->10 | available_copies:10->9','2026-07-25 01:10:18'),
(366,'books','UPDATE',31,NULL,'title=1984 | total_copies:10->10 | available_copies:9->10','2026-07-25 01:10:18'),
(367,'books','UPDATE',31,NULL,'title=1984 | total_copies:10->10 | available_copies:10->9','2026-07-25 01:10:18'),
(368,'books','UPDATE',31,NULL,'title=1984 | total_copies:10->10 | available_copies:9->10','2026-07-25 01:10:18'),
(369,'books','UPDATE',22,NULL,'title=Concepts of Modern Physics | total_copies:5->5 | available_copies:5->4','2026-07-25 01:10:18'),
(370,'books','UPDATE',22,NULL,'title=Concepts of Modern Physics | total_copies:5->5 | available_copies:4->5','2026-07-25 01:10:18'),
(371,'books','UPDATE',23,NULL,'title=Concepts of Physics Part 1 | total_copies:7->7 | available_copies:7->6','2026-07-25 01:10:18'),
(372,'books','UPDATE',23,NULL,'title=Concepts of Physics Part 1 | total_copies:7->7 | available_copies:6->7','2026-07-25 01:10:18'),
(373,'books','UPDATE',46,NULL,'title=Gandhi Before India | total_copies:3->3 | available_copies:3->2','2026-07-25 01:10:18'),
(374,'books','UPDATE',46,NULL,'title=Gandhi Before India | total_copies:3->3 | available_copies:2->3','2026-07-25 01:10:18'),
(375,'books','UPDATE',57,NULL,'title=Atomic Habits | total_copies:10->10 | available_copies:10->9','2026-07-25 01:10:18'),
(376,'books','UPDATE',57,NULL,'title=Atomic Habits | total_copies:10->10 | available_copies:9->10','2026-07-25 01:10:18'),
(377,'books','UPDATE',14,NULL,'title=Introduction to Linear Algebra | total_copies:4->4 | available_copies:4->3','2026-07-25 01:10:18'),
(378,'books','UPDATE',14,NULL,'title=Introduction to Linear Algebra | total_copies:4->4 | available_copies:3->4','2026-07-25 01:10:18'),
(379,'books','UPDATE',35,NULL,'title=Five Point Someone | total_copies:9->9 | available_copies:9->8','2026-07-25 01:10:18'),
(380,'books','UPDATE',35,NULL,'title=Five Point Someone | total_copies:9->9 | available_copies:8->9','2026-07-25 01:10:18'),
(381,'books','UPDATE',53,NULL,'title=Outliers | total_copies:6->6 | available_copies:6->5','2026-07-25 01:10:18'),
(382,'books','UPDATE',53,NULL,'title=Outliers | total_copies:6->6 | available_copies:5->6','2026-07-25 01:10:18'),
(383,'books','UPDATE',67,NULL,'title=Digital Logic and Computer Design | total_copies:6->6 | available_copies:6->5','2026-07-25 01:10:18'),
(384,'books','UPDATE',67,NULL,'title=Digital Logic and Computer Design | total_copies:6->6 | available_copies:5->6','2026-07-25 01:10:18'),
(385,'books','UPDATE',27,NULL,'title=Murder on the Orient Express | total_copies:8->8 | available_copies:8->7','2026-07-25 01:10:18'),
(386,'books','UPDATE',27,NULL,'title=Murder on the Orient Express | total_copies:8->8 | available_copies:7->8','2026-07-25 01:10:18'),
(387,'books','UPDATE',19,NULL,'title=A First Course in Probability | total_copies:4->4 | available_copies:4->3','2026-07-25 01:10:18'),
(388,'books','UPDATE',19,NULL,'title=A First Course in Probability | total_copies:4->4 | available_copies:3->4','2026-07-25 01:10:18'),
(389,'books','UPDATE',34,NULL,'title=Swami and Friends | total_copies:4->4 | available_copies:4->3','2026-07-25 01:10:18'),
(390,'books','UPDATE',34,NULL,'title=Swami and Friends | total_copies:4->4 | available_copies:3->4','2026-07-25 01:10:18'),
(391,'books','UPDATE',2,NULL,'title=Clean Code | total_copies:8->8 | available_copies:8->7','2026-07-25 01:10:18'),
(392,'books','UPDATE',2,NULL,'title=Clean Code | total_copies:8->8 | available_copies:7->8','2026-07-25 01:10:18'),
(393,'books','UPDATE',23,NULL,'title=Concepts of Physics Part 1 | total_copies:7->7 | available_copies:7->6','2026-07-25 01:10:18'),
(394,'books','UPDATE',23,NULL,'title=Concepts of Physics Part 1 | total_copies:7->7 | available_copies:6->7','2026-07-25 01:10:18'),
(395,'books','UPDATE',2,NULL,'title=Clean Code | total_copies:8->8 | available_copies:8->7','2026-07-25 01:10:18'),
(396,'books','UPDATE',2,NULL,'title=Clean Code | total_copies:8->8 | available_copies:7->8','2026-07-25 01:10:18'),
(397,'books','UPDATE',17,NULL,'title=Higher Engineering Mathematics | total_copies:8->8 | available_copies:8->7','2026-07-25 01:10:18'),
(398,'books','UPDATE',17,NULL,'title=Higher Engineering Mathematics | total_copies:8->8 | available_copies:7->8','2026-07-25 01:10:18'),
(399,'books','UPDATE',23,NULL,'title=Concepts of Physics Part 1 | total_copies:7->7 | available_copies:7->6','2026-07-25 01:10:18'),
(400,'books','UPDATE',23,NULL,'title=Concepts of Physics Part 1 | total_copies:7->7 | available_copies:6->7','2026-07-25 01:10:18'),
(401,'books','UPDATE',40,NULL,'title=Wings of Fire | total_copies:8->8 | available_copies:8->7','2026-07-25 01:10:18'),
(402,'books','UPDATE',40,NULL,'title=Wings of Fire | total_copies:8->8 | available_copies:7->8','2026-07-25 01:10:18'),
(403,'books','UPDATE',45,NULL,'title=India After Gandhi | total_copies:5->5 | available_copies:5->4','2026-07-25 01:10:18'),
(404,'books','UPDATE',45,NULL,'title=India After Gandhi | total_copies:5->5 | available_copies:4->5','2026-07-25 01:10:18'),
(405,'books','UPDATE',29,NULL,'title=The Murder of Roger Ackroyd | total_copies:6->6 | available_copies:6->5','2026-07-25 01:10:18'),
(406,'books','UPDATE',29,NULL,'title=The Murder of Roger Ackroyd | total_copies:6->6 | available_copies:5->6','2026-07-25 01:10:18'),
(407,'books','UPDATE',32,NULL,'title=Animal Farm | total_copies:9->9 | available_copies:9->8','2026-07-25 01:10:18'),
(408,'books','UPDATE',32,NULL,'title=Animal Farm | total_copies:9->9 | available_copies:8->9','2026-07-25 01:10:18'),
(409,'books','UPDATE',8,NULL,'title=Let Us C | total_copies:10->10 | available_copies:10->9','2026-07-25 01:10:18'),
(410,'books','UPDATE',8,NULL,'title=Let Us C | total_copies:10->10 | available_copies:9->10','2026-07-25 01:10:18'),
(411,'books','UPDATE',49,NULL,'title=Think and Grow Rich | total_copies:8->8 | available_copies:8->7','2026-07-25 01:10:18'),
(412,'books','UPDATE',49,NULL,'title=Think and Grow Rich | total_copies:8->8 | available_copies:7->8','2026-07-25 01:10:18'),
(413,'books','UPDATE',17,NULL,'title=Higher Engineering Mathematics | total_copies:8->8 | available_copies:8->7','2026-07-25 01:10:18'),
(414,'books','UPDATE',17,NULL,'title=Higher Engineering Mathematics | total_copies:8->8 | available_copies:7->8','2026-07-25 01:10:18'),
(415,'books','UPDATE',16,NULL,'title=Differential Equations and Linear Algebra | total_copies:4->4 | available_copies:4->3','2026-07-25 01:10:18'),
(416,'books','UPDATE',16,NULL,'title=Differential Equations and Linear Algebra | total_copies:4->4 | available_copies:3->4','2026-07-25 01:10:18'),
(417,'books','UPDATE',71,NULL,'title=Symposium | total_copies:3->3 | available_copies:3->2','2026-07-25 01:10:18'),
(418,'books','UPDATE',71,NULL,'title=Symposium | total_copies:3->3 | available_copies:2->3','2026-07-25 01:10:18'),
(419,'books','UPDATE',26,NULL,'title=Quantum Mechanics: Concepts and Applications | total_copies:3->3 | available_copies:3->2','2026-07-25 01:10:18'),
(420,'books','UPDATE',26,NULL,'title=Quantum Mechanics: Concepts and Applications | total_copies:3->3 | available_copies:2->3','2026-07-25 01:10:18'),
(421,'books','UPDATE',58,NULL,'title=The Alchemist | total_copies:9->9 | available_copies:9->8','2026-07-25 01:10:18'),
(422,'books','UPDATE',58,NULL,'title=The Alchemist | total_copies:9->9 | available_copies:8->9','2026-07-25 01:10:18'),
(423,'books','UPDATE',36,NULL,'title=2 States | total_copies:8->8 | available_copies:8->7','2026-07-25 01:10:18'),
(424,'books','UPDATE',36,NULL,'title=2 States | total_copies:8->8 | available_copies:7->8','2026-07-25 01:10:18'),
(425,'books','UPDATE',36,NULL,'title=2 States | total_copies:8->8 | available_copies:8->7','2026-07-25 01:10:18'),
(426,'books','UPDATE',36,NULL,'title=2 States | total_copies:8->8 | available_copies:7->8','2026-07-25 01:10:18'),
(427,'books','UPDATE',58,NULL,'title=The Alchemist | total_copies:9->9 | available_copies:9->8','2026-07-25 01:10:18'),
(428,'books','UPDATE',58,NULL,'title=The Alchemist | total_copies:9->9 | available_copies:8->9','2026-07-25 01:10:18'),
(429,'books','UPDATE',32,NULL,'title=Animal Farm | total_copies:9->9 | available_copies:9->8','2026-07-25 01:10:18'),
(430,'books','UPDATE',32,NULL,'title=Animal Farm | total_copies:9->9 | available_copies:8->9','2026-07-25 01:10:18'),
(431,'books','UPDATE',33,NULL,'title=Malgudi Days | total_copies:7->7 | available_copies:7->6','2026-07-25 01:10:18'),
(432,'books','UPDATE',33,NULL,'title=Malgudi Days | total_copies:7->7 | available_copies:6->7','2026-07-25 01:10:18'),
(433,'books','UPDATE',58,NULL,'title=The Alchemist | total_copies:9->9 | available_copies:9->8','2026-07-25 01:10:18'),
(434,'books','UPDATE',58,NULL,'title=The Alchemist | total_copies:9->9 | available_copies:8->9','2026-07-25 01:10:18'),
(435,'books','UPDATE',54,NULL,'title=The Tipping Point | total_copies:5->5 | available_copies:5->4','2026-07-25 01:10:18'),
(436,'books','UPDATE',54,NULL,'title=The Tipping Point | total_copies:5->5 | available_copies:4->5','2026-07-25 01:10:18'),
(437,'books','UPDATE',35,NULL,'title=Five Point Someone | total_copies:9->9 | available_copies:9->8','2026-07-25 01:10:18'),
(438,'books','UPDATE',35,NULL,'title=Five Point Someone | total_copies:9->9 | available_copies:8->9','2026-07-25 01:10:18'),
(439,'books','UPDATE',41,NULL,'title=Ignited Minds | total_copies:5->5 | available_copies:5->4','2026-07-25 01:10:18'),
(440,'books','UPDATE',41,NULL,'title=Ignited Minds | total_copies:5->5 | available_copies:4->5','2026-07-25 01:10:18'),
(441,'books','UPDATE',74,NULL,'title=Crito | total_copies:2->2 | available_copies:2->1','2026-07-25 01:10:18'),
(442,'books','UPDATE',74,NULL,'title=Crito | total_copies:2->2 | available_copies:1->2','2026-07-25 01:10:18'),
(443,'books','UPDATE',14,NULL,'title=Introduction to Linear Algebra | total_copies:4->4 | available_copies:4->3','2026-07-25 01:10:18'),
(444,'books','UPDATE',14,NULL,'title=Introduction to Linear Algebra | total_copies:4->4 | available_copies:3->4','2026-07-25 01:10:18'),
(445,'books','UPDATE',30,NULL,'title=Death on the Nile | total_copies:6->6 | available_copies:6->5','2026-07-25 01:10:18'),
(446,'books','UPDATE',30,NULL,'title=Death on the Nile | total_copies:6->6 | available_copies:5->6','2026-07-25 01:10:18'),
(447,'books','UPDATE',1,NULL,'title=Introduction to Algorithms | total_copies:7->7 | available_copies:7->6','2026-07-25 01:10:18'),
(448,'books','UPDATE',1,NULL,'title=Introduction to Algorithms | total_copies:7->7 | available_copies:6->7','2026-07-25 01:10:18'),
(449,'books','UPDATE',28,NULL,'title=And Then There Were None | total_copies:9->9 | available_copies:9->8','2026-07-25 01:10:18'),
(450,'books','UPDATE',28,NULL,'title=And Then There Were None | total_copies:9->9 | available_copies:8->9','2026-07-25 01:10:18'),
(451,'books','UPDATE',53,NULL,'title=Outliers | total_copies:6->6 | available_copies:6->5','2026-07-25 01:10:18'),
(452,'books','UPDATE',53,NULL,'title=Outliers | total_copies:6->6 | available_copies:5->6','2026-07-25 01:10:18'),
(453,'books','UPDATE',31,NULL,'title=1984 | total_copies:10->10 | available_copies:10->9','2026-07-25 01:10:18'),
(454,'books','UPDATE',31,NULL,'title=1984 | total_copies:10->10 | available_copies:9->10','2026-07-25 01:10:18'),
(455,'books','UPDATE',5,NULL,'title=Java: The Complete Reference | total_copies:9->9 | available_copies:9->8','2026-07-25 01:10:18'),
(456,'books','UPDATE',5,NULL,'title=Java: The Complete Reference | total_copies:9->9 | available_copies:8->9','2026-07-25 01:10:18'),
(457,'books','UPDATE',54,NULL,'title=The Tipping Point | total_copies:5->5 | available_copies:5->4','2026-07-25 01:10:18'),
(458,'books','UPDATE',54,NULL,'title=The Tipping Point | total_copies:5->5 | available_copies:4->5','2026-07-25 01:10:18'),
(459,'books','UPDATE',57,NULL,'title=Atomic Habits | total_copies:10->10 | available_copies:10->9','2026-07-25 01:10:18'),
(460,'books','UPDATE',57,NULL,'title=Atomic Habits | total_copies:10->10 | available_copies:9->10','2026-07-25 01:10:18'),
(461,'books','UPDATE',42,NULL,'title=Sapiens: A Brief History of Humankind | total_copies:8->8 | available_copies:8->7','2026-07-25 01:10:18'),
(462,'books','UPDATE',42,NULL,'title=Sapiens: A Brief History of Humankind | total_copies:8->8 | available_copies:7->8','2026-07-25 01:10:18'),
(463,'books','UPDATE',42,NULL,'title=Sapiens: A Brief History of Humankind | total_copies:8->8 | available_copies:8->7','2026-07-25 01:10:18'),
(464,'books','UPDATE',42,NULL,'title=Sapiens: A Brief History of Humankind | total_copies:8->8 | available_copies:7->8','2026-07-25 01:10:18'),
(465,'books','UPDATE',58,NULL,'title=The Alchemist | total_copies:9->9 | available_copies:9->8','2026-07-25 01:10:18'),
(466,'books','UPDATE',58,NULL,'title=The Alchemist | total_copies:9->9 | available_copies:8->9','2026-07-25 01:10:18'),
(467,'books','UPDATE',1,NULL,'title=Introduction to Algorithms | total_copies:7->7 | available_copies:7->6','2026-07-25 01:10:18'),
(468,'books','UPDATE',1,NULL,'title=Introduction to Algorithms | total_copies:7->7 | available_copies:6->7','2026-07-25 01:10:18'),
(469,'books','UPDATE',49,NULL,'title=Think and Grow Rich | total_copies:8->8 | available_copies:8->7','2026-07-25 01:10:18'),
(470,'books','UPDATE',49,NULL,'title=Think and Grow Rich | total_copies:8->8 | available_copies:7->8','2026-07-25 01:10:18'),
(471,'books','UPDATE',33,NULL,'title=Malgudi Days | total_copies:7->7 | available_copies:7->6','2026-07-25 01:10:18'),
(472,'books','UPDATE',33,NULL,'title=Malgudi Days | total_copies:7->7 | available_copies:6->7','2026-07-25 01:10:18'),
(473,'books','UPDATE',49,NULL,'title=Think and Grow Rich | total_copies:8->8 | available_copies:8->7','2026-07-25 01:10:18'),
(474,'books','UPDATE',49,NULL,'title=Think and Grow Rich | total_copies:8->8 | available_copies:7->8','2026-07-25 01:10:18'),
(475,'books','UPDATE',40,NULL,'title=Wings of Fire | total_copies:8->8 | available_copies:8->7','2026-07-25 01:10:18'),
(476,'books','UPDATE',40,NULL,'title=Wings of Fire | total_copies:8->8 | available_copies:7->8','2026-07-25 01:10:18'),
(477,'books','UPDATE',9,NULL,'title=Let Us C++ | total_copies:7->7 | available_copies:7->6','2026-07-25 01:10:18'),
(478,'books','UPDATE',9,NULL,'title=Let Us C++ | total_copies:7->7 | available_copies:6->7','2026-07-25 01:10:18'),
(479,'books','UPDATE',53,NULL,'title=Outliers | total_copies:6->6 | available_copies:6->5','2026-07-25 01:10:18'),
(480,'books','UPDATE',53,NULL,'title=Outliers | total_copies:6->6 | available_copies:5->6','2026-07-25 01:10:18'),
(481,'books','UPDATE',31,NULL,'title=1984 | total_copies:10->10 | available_copies:10->9','2026-07-25 01:10:18'),
(482,'books','UPDATE',31,NULL,'title=1984 | total_copies:10->10 | available_copies:9->10','2026-07-25 01:10:18'),
(483,'books','UPDATE',60,NULL,'title=How to Win Friends and Influence People | total_copies:7->7 | available_copies:7->6','2026-07-25 01:10:18'),
(484,'books','UPDATE',60,NULL,'title=How to Win Friends and Influence People | total_copies:7->7 | available_copies:6->7','2026-07-25 01:10:18'),
(485,'books','UPDATE',32,NULL,'title=Animal Farm | total_copies:9->9 | available_copies:9->8','2026-07-25 01:10:18'),
(486,'books','UPDATE',32,NULL,'title=Animal Farm | total_copies:9->9 | available_copies:8->9','2026-07-25 01:10:18'),
(487,'books','UPDATE',23,NULL,'title=Concepts of Physics Part 1 | total_copies:7->7 | available_copies:7->6','2026-07-25 01:10:18'),
(488,'books','UPDATE',23,NULL,'title=Concepts of Physics Part 1 | total_copies:7->7 | available_copies:6->7','2026-07-25 01:10:18'),
(489,'books','UPDATE',33,NULL,'title=Malgudi Days | total_copies:7->7 | available_copies:7->6','2026-07-25 01:10:18'),
(490,'books','UPDATE',33,NULL,'title=Malgudi Days | total_copies:7->7 | available_copies:6->7','2026-07-25 01:10:18'),
(491,'books','UPDATE',58,NULL,'title=The Alchemist | total_copies:9->9 | available_copies:9->8','2026-07-25 01:10:18'),
(492,'books','UPDATE',58,NULL,'title=The Alchemist | total_copies:9->9 | available_copies:8->9','2026-07-25 01:10:18'),
(493,'books','UPDATE',19,NULL,'title=A First Course in Probability | total_copies:4->4 | available_copies:4->3','2026-07-25 01:10:18'),
(494,'books','UPDATE',19,NULL,'title=A First Course in Probability | total_copies:4->4 | available_copies:3->4','2026-07-25 01:10:18'),
(495,'books','UPDATE',50,NULL,'title=Rich Dad Poor Dad | total_copies:9->9 | available_copies:9->8','2026-07-25 01:10:18'),
(496,'books','UPDATE',50,NULL,'title=Rich Dad Poor Dad | total_copies:9->9 | available_copies:8->9','2026-07-25 01:10:18'),
(497,'books','UPDATE',35,NULL,'title=Five Point Someone | total_copies:9->9 | available_copies:9->8','2026-07-25 01:10:18'),
(498,'books','UPDATE',35,NULL,'title=Five Point Someone | total_copies:9->9 | available_copies:8->9','2026-07-25 01:10:18'),
(499,'books','UPDATE',6,NULL,'title=C++: The Complete Reference | total_copies:6->6 | available_copies:6->5','2026-07-25 01:10:18'),
(500,'books','UPDATE',6,NULL,'title=C++: The Complete Reference | total_copies:6->6 | available_copies:5->6','2026-07-25 01:10:18'),
(501,'books','UPDATE',3,NULL,'title=Clean Architecture | total_copies:6->6 | available_copies:6->5','2026-07-25 01:10:18'),
(502,'books','UPDATE',3,NULL,'title=Clean Architecture | total_copies:6->6 | available_copies:5->6','2026-07-25 01:10:18'),
(503,'books','UPDATE',37,NULL,'title=Steve Jobs | total_copies:6->6 | available_copies:6->5','2026-07-25 01:10:18'),
(504,'books','UPDATE',37,NULL,'title=Steve Jobs | total_copies:6->6 | available_copies:5->6','2026-07-25 01:10:18'),
(505,'books','UPDATE',44,NULL,'title=21 Lessons for the 21st Century | total_copies:4->4 | available_copies:4->3','2026-07-25 01:10:18'),
(506,'books','UPDATE',44,NULL,'title=21 Lessons for the 21st Century | total_copies:4->4 | available_copies:3->4','2026-07-25 01:10:18'),
(507,'books','UPDATE',31,NULL,'title=1984 | total_copies:10->10 | available_copies:10->9','2026-07-25 01:10:18'),
(508,'books','UPDATE',31,NULL,'title=1984 | total_copies:10->10 | available_copies:9->10','2026-07-25 01:10:18'),
(509,'books','UPDATE',6,NULL,'title=C++: The Complete Reference | total_copies:6->6 | available_copies:6->5','2026-07-25 01:10:18'),
(510,'books','UPDATE',6,NULL,'title=C++: The Complete Reference | total_copies:6->6 | available_copies:5->6','2026-07-25 01:10:18'),
(511,'books','UPDATE',31,NULL,'title=1984 | total_copies:10->10 | available_copies:10->9','2026-07-25 01:10:18'),
(512,'books','UPDATE',31,NULL,'title=1984 | total_copies:10->10 | available_copies:9->10','2026-07-25 01:10:18'),
(513,'books','UPDATE',57,NULL,'title=Atomic Habits | total_copies:10->10 | available_copies:10->9','2026-07-25 01:10:18'),
(514,'books','UPDATE',57,NULL,'title=Atomic Habits | total_copies:10->10 | available_copies:9->10','2026-07-25 01:10:18'),
(515,'books','UPDATE',15,NULL,'title=Calculus | total_copies:5->5 | available_copies:5->4','2026-07-25 01:10:18'),
(516,'books','UPDATE',15,NULL,'title=Calculus | total_copies:5->5 | available_copies:4->5','2026-07-25 01:10:18'),
(517,'books','UPDATE',31,NULL,'title=1984 | total_copies:10->10 | available_copies:10->9','2026-07-25 01:10:18'),
(518,'books','UPDATE',31,NULL,'title=1984 | total_copies:10->10 | available_copies:9->10','2026-07-25 01:10:18'),
(519,'books','UPDATE',57,NULL,'title=Atomic Habits | total_copies:10->10 | available_copies:10->9','2026-07-25 01:10:18'),
(520,'books','UPDATE',57,NULL,'title=Atomic Habits | total_copies:10->10 | available_copies:9->10','2026-07-25 01:10:18'),
(521,'books','UPDATE',74,NULL,'title=Crito | total_copies:2->2 | available_copies:2->1','2026-07-25 01:10:18'),
(522,'books','UPDATE',74,NULL,'title=Crito | total_copies:2->2 | available_copies:1->2','2026-07-25 01:10:18'),
(523,'books','UPDATE',63,NULL,'title=Electronic Devices and Circuit Theory | total_copies:5->5 | available_copies:5->4','2026-07-25 01:10:18'),
(524,'books','UPDATE',63,NULL,'title=Electronic Devices and Circuit Theory | total_copies:5->5 | available_copies:4->5','2026-07-25 01:10:18'),
(525,'books','UPDATE',28,NULL,'title=And Then There Were None | total_copies:9->9 | available_copies:9->8','2026-07-25 01:10:18'),
(526,'books','UPDATE',28,NULL,'title=And Then There Were None | total_copies:9->9 | available_copies:8->9','2026-07-25 01:10:18'),
(527,'books','UPDATE',40,NULL,'title=Wings of Fire | total_copies:8->8 | available_copies:8->7','2026-07-25 01:10:18'),
(528,'books','UPDATE',40,NULL,'title=Wings of Fire | total_copies:8->8 | available_copies:7->8','2026-07-25 01:10:18'),
(529,'books','UPDATE',5,NULL,'title=Java: The Complete Reference | total_copies:9->9 | available_copies:9->8','2026-07-25 01:10:18'),
(530,'books','UPDATE',5,NULL,'title=Java: The Complete Reference | total_copies:9->9 | available_copies:8->9','2026-07-25 01:10:18'),
(531,'books','UPDATE',53,NULL,'title=Outliers | total_copies:6->6 | available_copies:6->5','2026-07-25 01:10:18'),
(532,'books','UPDATE',53,NULL,'title=Outliers | total_copies:6->6 | available_copies:5->6','2026-07-25 01:10:18'),
(533,'books','UPDATE',16,NULL,'title=Differential Equations and Linear Algebra | total_copies:4->4 | available_copies:4->3','2026-07-25 01:10:18'),
(534,'books','UPDATE',16,NULL,'title=Differential Equations and Linear Algebra | total_copies:4->4 | available_copies:3->4','2026-07-25 01:10:18'),
(535,'books','UPDATE',35,NULL,'title=Five Point Someone | total_copies:9->9 | available_copies:9->8','2026-07-25 01:10:18'),
(536,'books','UPDATE',35,NULL,'title=Five Point Someone | total_copies:9->9 | available_copies:8->9','2026-07-25 01:10:18'),
(537,'books','UPDATE',35,NULL,'title=Five Point Someone | total_copies:9->9 | available_copies:9->8','2026-07-25 01:10:18'),
(538,'books','UPDATE',35,NULL,'title=Five Point Someone | total_copies:9->9 | available_copies:8->9','2026-07-25 01:10:18'),
(539,'books','UPDATE',9,NULL,'title=Let Us C++ | total_copies:7->7 | available_copies:7->6','2026-07-25 01:10:18'),
(540,'books','UPDATE',9,NULL,'title=Let Us C++ | total_copies:7->7 | available_copies:6->7','2026-07-25 01:10:18'),
(541,'books','UPDATE',36,NULL,'title=2 States | total_copies:8->8 | available_copies:8->7','2026-07-25 01:10:18'),
(542,'books','UPDATE',36,NULL,'title=2 States | total_copies:8->8 | available_copies:7->8','2026-07-25 01:10:18'),
(543,'books','UPDATE',5,NULL,'title=Java: The Complete Reference | total_copies:9->9 | available_copies:9->8','2026-07-25 01:10:18'),
(544,'books','UPDATE',5,NULL,'title=Java: The Complete Reference | total_copies:9->9 | available_copies:8->9','2026-07-25 01:10:18'),
(545,'books','UPDATE',24,NULL,'title=Concepts of Physics Part 2 | total_copies:6->6 | available_copies:6->5','2026-07-25 01:10:18'),
(546,'books','UPDATE',24,NULL,'title=Concepts of Physics Part 2 | total_copies:6->6 | available_copies:5->6','2026-07-25 01:10:18'),
(547,'books','UPDATE',57,NULL,'title=Atomic Habits | total_copies:10->10 | available_copies:10->9','2026-07-25 01:10:18'),
(548,'books','UPDATE',57,NULL,'title=Atomic Habits | total_copies:10->10 | available_copies:9->10','2026-07-25 01:10:18'),
(549,'books','UPDATE',24,NULL,'title=Concepts of Physics Part 2 | total_copies:6->6 | available_copies:6->5','2026-07-25 01:10:18'),
(550,'books','UPDATE',24,NULL,'title=Concepts of Physics Part 2 | total_copies:6->6 | available_copies:5->6','2026-07-25 01:10:18'),
(551,'books','UPDATE',49,NULL,'title=Think and Grow Rich | total_copies:8->8 | available_copies:8->7','2026-07-25 01:10:18'),
(552,'books','UPDATE',49,NULL,'title=Think and Grow Rich | total_copies:8->8 | available_copies:7->8','2026-07-25 01:10:18'),
(553,'books','UPDATE',20,NULL,'title=A Brief History of Time | total_copies:6->6 | available_copies:6->5','2026-07-25 01:10:18'),
(554,'books','UPDATE',20,NULL,'title=A Brief History of Time | total_copies:6->6 | available_copies:5->6','2026-07-25 01:10:18'),
(555,'books','UPDATE',9,NULL,'title=Let Us C++ | total_copies:7->7 | available_copies:7->6','2026-07-25 01:10:18'),
(556,'books','UPDATE',9,NULL,'title=Let Us C++ | total_copies:7->7 | available_copies:6->7','2026-07-25 01:10:18'),
(557,'books','UPDATE',8,NULL,'title=Let Us C | total_copies:10->10 | available_copies:10->9','2026-07-25 01:10:18'),
(558,'books','UPDATE',8,NULL,'title=Let Us C | total_copies:10->10 | available_copies:9->10','2026-07-25 01:10:18'),
(559,'books','UPDATE',1,NULL,'title=Introduction to Algorithms | total_copies:7->7 | available_copies:7->6','2026-07-25 01:10:18'),
(560,'books','UPDATE',1,NULL,'title=Introduction to Algorithms | total_copies:7->7 | available_copies:6->7','2026-07-25 01:10:18'),
(561,'books','UPDATE',28,NULL,'title=And Then There Were None | total_copies:9->9 | available_copies:9->8','2026-07-25 01:10:18'),
(562,'books','UPDATE',28,NULL,'title=And Then There Were None | total_copies:9->9 | available_copies:8->9','2026-07-25 01:10:18'),
(563,'books','UPDATE',6,NULL,'title=C++: The Complete Reference | total_copies:6->6 | available_copies:6->5','2026-07-25 01:10:18'),
(564,'books','UPDATE',6,NULL,'title=C++: The Complete Reference | total_copies:6->6 | available_copies:5->6','2026-07-25 01:10:18'),
(565,'books','UPDATE',2,NULL,'title=Clean Code | total_copies:8->8 | available_copies:8->7','2026-07-25 01:10:18'),
(566,'books','UPDATE',2,NULL,'title=Clean Code | total_copies:8->8 | available_copies:7->8','2026-07-25 01:10:18'),
(567,'books','UPDATE',35,NULL,'title=Five Point Someone | total_copies:9->9 | available_copies:9->8','2026-07-25 01:10:18'),
(568,'books','UPDATE',35,NULL,'title=Five Point Someone | total_copies:9->9 | available_copies:8->9','2026-07-25 01:10:18'),
(569,'books','UPDATE',63,NULL,'title=Electronic Devices and Circuit Theory | total_copies:5->5 | available_copies:5->4','2026-07-25 01:10:18'),
(570,'books','UPDATE',63,NULL,'title=Electronic Devices and Circuit Theory | total_copies:5->5 | available_copies:4->5','2026-07-25 01:10:18'),
(571,'books','UPDATE',29,NULL,'title=The Murder of Roger Ackroyd | total_copies:6->6 | available_copies:6->5','2026-07-25 01:10:18'),
(572,'books','UPDATE',29,NULL,'title=The Murder of Roger Ackroyd | total_copies:6->6 | available_copies:5->6','2026-07-25 01:10:18'),
(573,'books','UPDATE',5,NULL,'title=Java: The Complete Reference | total_copies:9->9 | available_copies:9->8','2026-07-25 01:10:18'),
(574,'books','UPDATE',5,NULL,'title=Java: The Complete Reference | total_copies:9->9 | available_copies:8->9','2026-07-25 01:10:18'),
(575,'books','UPDATE',5,NULL,'title=Java: The Complete Reference | total_copies:9->9 | available_copies:9->8','2026-07-25 01:10:18'),
(576,'books','UPDATE',5,NULL,'title=Java: The Complete Reference | total_copies:9->9 | available_copies:8->9','2026-07-25 01:10:18'),
(577,'books','UPDATE',42,NULL,'title=Sapiens: A Brief History of Humankind | total_copies:8->8 | available_copies:8->7','2026-07-25 01:10:18'),
(578,'books','UPDATE',42,NULL,'title=Sapiens: A Brief History of Humankind | total_copies:8->8 | available_copies:7->8','2026-07-25 01:10:18'),
(579,'books','UPDATE',60,NULL,'title=How to Win Friends and Influence People | total_copies:7->7 | available_copies:7->6','2026-07-25 01:10:18'),
(580,'books','UPDATE',60,NULL,'title=How to Win Friends and Influence People | total_copies:7->7 | available_copies:6->7','2026-07-25 01:10:18'),
(581,'books','UPDATE',31,NULL,'title=1984 | total_copies:10->10 | available_copies:10->9','2026-07-25 01:10:18'),
(582,'books','UPDATE',31,NULL,'title=1984 | total_copies:10->10 | available_copies:9->10','2026-07-25 01:10:18'),
(583,'books','UPDATE',51,NULL,'title=Cashflow Quadrant | total_copies:4->4 | available_copies:4->3','2026-07-25 01:10:18'),
(584,'books','UPDATE',51,NULL,'title=Cashflow Quadrant | total_copies:4->4 | available_copies:3->4','2026-07-25 01:10:18'),
(585,'books','UPDATE',57,NULL,'title=Atomic Habits | total_copies:10->10 | available_copies:10->9','2026-07-25 01:10:18'),
(586,'books','UPDATE',57,NULL,'title=Atomic Habits | total_copies:10->10 | available_copies:9->10','2026-07-25 01:10:18'),
(587,'books','UPDATE',20,NULL,'title=A Brief History of Time | total_copies:6->6 | available_copies:6->5','2026-07-25 01:10:18'),
(588,'books','UPDATE',20,NULL,'title=A Brief History of Time | total_copies:6->6 | available_copies:5->6','2026-07-25 01:10:18'),
(589,'books','UPDATE',64,NULL,'title=Digital Fundamentals | total_copies:5->5 | available_copies:5->4','2026-07-25 01:10:18'),
(590,'books','UPDATE',64,NULL,'title=Digital Fundamentals | total_copies:5->5 | available_copies:4->5','2026-07-25 01:10:18'),
(591,'books','UPDATE',30,NULL,'title=Death on the Nile | total_copies:6->6 | available_copies:6->5','2026-07-25 01:10:18'),
(592,'books','UPDATE',30,NULL,'title=Death on the Nile | total_copies:6->6 | available_copies:5->6','2026-07-25 01:10:18'),
(593,'books','UPDATE',5,NULL,'title=Java: The Complete Reference | total_copies:9->9 | available_copies:9->8','2026-07-25 01:10:18'),
(594,'books','UPDATE',5,NULL,'title=Java: The Complete Reference | total_copies:9->9 | available_copies:8->9','2026-07-25 01:10:18'),
(595,'books','UPDATE',29,NULL,'title=The Murder of Roger Ackroyd | total_copies:6->6 | available_copies:6->5','2026-07-25 01:10:18'),
(596,'books','UPDATE',29,NULL,'title=The Murder of Roger Ackroyd | total_copies:6->6 | available_copies:5->6','2026-07-25 01:10:18'),
(597,'books','UPDATE',58,NULL,'title=The Alchemist | total_copies:9->9 | available_copies:9->8','2026-07-25 01:10:18'),
(598,'books','UPDATE',58,NULL,'title=The Alchemist | total_copies:9->9 | available_copies:8->9','2026-07-25 01:10:18'),
(599,'books','UPDATE',9,NULL,'title=Let Us C++ | total_copies:7->7 | available_copies:7->6','2026-07-25 01:10:18'),
(600,'books','UPDATE',9,NULL,'title=Let Us C++ | total_copies:7->7 | available_copies:6->7','2026-07-25 01:10:18'),
(601,'books','UPDATE',51,NULL,'title=Cashflow Quadrant | total_copies:4->4 | available_copies:4->3','2026-07-25 01:10:18'),
(602,'books','UPDATE',51,NULL,'title=Cashflow Quadrant | total_copies:4->4 | available_copies:3->4','2026-07-25 01:10:18'),
(603,'books','UPDATE',57,NULL,'title=Atomic Habits | total_copies:10->10 | available_copies:10->9','2026-07-25 01:10:18'),
(604,'books','UPDATE',57,NULL,'title=Atomic Habits | total_copies:10->10 | available_copies:9->10','2026-07-25 01:10:18'),
(605,'books','UPDATE',16,NULL,'title=Differential Equations and Linear Algebra | total_copies:4->4 | available_copies:4->3','2026-07-25 01:10:18'),
(606,'books','UPDATE',16,NULL,'title=Differential Equations and Linear Algebra | total_copies:4->4 | available_copies:3->4','2026-07-25 01:10:18'),
(607,'books','UPDATE',57,NULL,'title=Atomic Habits | total_copies:10->10 | available_copies:10->9','2026-07-25 01:10:18'),
(608,'books','UPDATE',57,NULL,'title=Atomic Habits | total_copies:10->10 | available_copies:9->10','2026-07-25 01:10:18'),
(609,'books','UPDATE',9,NULL,'title=Let Us C++ | total_copies:7->7 | available_copies:7->6','2026-07-25 01:10:18'),
(610,'books','UPDATE',9,NULL,'title=Let Us C++ | total_copies:7->7 | available_copies:6->7','2026-07-25 01:10:18'),
(611,'books','UPDATE',49,NULL,'title=Think and Grow Rich | total_copies:8->8 | available_copies:8->7','2026-07-25 01:10:18'),
(612,'books','UPDATE',49,NULL,'title=Think and Grow Rich | total_copies:8->8 | available_copies:7->8','2026-07-25 01:10:18'),
(613,'books','UPDATE',27,NULL,'title=Murder on the Orient Express | total_copies:8->8 | available_copies:8->7','2026-07-25 01:10:18'),
(614,'books','UPDATE',27,NULL,'title=Murder on the Orient Express | total_copies:8->8 | available_copies:7->8','2026-07-25 01:10:18'),
(615,'books','UPDATE',57,NULL,'title=Atomic Habits | total_copies:10->10 | available_copies:10->9','2026-07-25 01:10:18'),
(616,'books','UPDATE',57,NULL,'title=Atomic Habits | total_copies:10->10 | available_copies:9->10','2026-07-25 01:10:18'),
(617,'books','UPDATE',58,NULL,'title=The Alchemist | total_copies:9->9 | available_copies:9->8','2026-07-25 01:10:18'),
(618,'books','UPDATE',58,NULL,'title=The Alchemist | total_copies:9->9 | available_copies:8->9','2026-07-25 01:10:18'),
(619,'books','UPDATE',42,NULL,'title=Sapiens: A Brief History of Humankind | total_copies:8->8 | available_copies:8->7','2026-07-25 01:10:18'),
(620,'books','UPDATE',42,NULL,'title=Sapiens: A Brief History of Humankind | total_copies:8->8 | available_copies:7->8','2026-07-25 01:10:18'),
(621,'books','UPDATE',12,NULL,'title=Python Crash Course | total_copies:9->9 | available_copies:9->8','2026-07-25 01:10:18'),
(622,'books','UPDATE',12,NULL,'title=Python Crash Course | total_copies:9->9 | available_copies:8->9','2026-07-25 01:10:18'),
(623,'books','UPDATE',14,NULL,'title=Introduction to Linear Algebra | total_copies:4->4 | available_copies:4->3','2026-07-25 01:10:18'),
(624,'books','UPDATE',14,NULL,'title=Introduction to Linear Algebra | total_copies:4->4 | available_copies:3->4','2026-07-25 01:10:18'),
(625,'books','UPDATE',36,NULL,'title=2 States | total_copies:8->8 | available_copies:8->7','2026-07-25 01:10:18'),
(626,'books','UPDATE',36,NULL,'title=2 States | total_copies:8->8 | available_copies:7->8','2026-07-25 01:10:18'),
(627,'books','UPDATE',58,NULL,'title=The Alchemist | total_copies:9->9 | available_copies:9->8','2026-07-25 01:10:18'),
(628,'books','UPDATE',58,NULL,'title=The Alchemist | total_copies:9->9 | available_copies:8->9','2026-07-25 01:10:18'),
(629,'books','UPDATE',55,NULL,'title=Blink | total_copies:4->4 | available_copies:4->3','2026-07-25 01:10:18'),
(630,'books','UPDATE',55,NULL,'title=Blink | total_copies:4->4 | available_copies:3->4','2026-07-25 01:10:18'),
(631,'books','UPDATE',15,NULL,'title=Calculus | total_copies:5->5 | available_copies:5->4','2026-07-25 01:10:18'),
(632,'books','UPDATE',15,NULL,'title=Calculus | total_copies:5->5 | available_copies:4->5','2026-07-25 01:10:18'),
(633,'books','UPDATE',50,NULL,'title=Rich Dad Poor Dad | total_copies:9->9 | available_copies:9->8','2026-07-25 01:10:18'),
(634,'books','UPDATE',50,NULL,'title=Rich Dad Poor Dad | total_copies:9->9 | available_copies:8->9','2026-07-25 01:10:18'),
(635,'books','UPDATE',57,NULL,'title=Atomic Habits | total_copies:10->10 | available_copies:10->9','2026-07-25 01:10:18'),
(636,'books','UPDATE',57,NULL,'title=Atomic Habits | total_copies:10->10 | available_copies:9->10','2026-07-25 01:10:18'),
(637,'books','UPDATE',50,NULL,'title=Rich Dad Poor Dad | total_copies:9->9 | available_copies:9->8','2026-07-25 01:10:18'),
(638,'books','UPDATE',50,NULL,'title=Rich Dad Poor Dad | total_copies:9->9 | available_copies:8->9','2026-07-25 01:10:18'),
(639,'books','UPDATE',50,NULL,'title=Rich Dad Poor Dad | total_copies:9->9 | available_copies:9->8','2026-07-25 01:10:18'),
(640,'books','UPDATE',50,NULL,'title=Rich Dad Poor Dad | total_copies:9->9 | available_copies:8->9','2026-07-25 01:10:18'),
(641,'books','UPDATE',58,NULL,'title=The Alchemist | total_copies:9->9 | available_copies:9->8','2026-07-25 01:10:18'),
(642,'books','UPDATE',58,NULL,'title=The Alchemist | total_copies:9->9 | available_copies:8->9','2026-07-25 01:10:18'),
(643,'books','UPDATE',59,NULL,'title=Veronika Decides to Die | total_copies:4->4 | available_copies:4->3','2026-07-25 01:10:18'),
(644,'books','UPDATE',59,NULL,'title=Veronika Decides to Die | total_copies:4->4 | available_copies:3->4','2026-07-25 01:10:18'),
(645,'books','UPDATE',8,NULL,'title=Let Us C | total_copies:10->10 | available_copies:10->9','2026-07-25 01:10:18'),
(646,'books','UPDATE',8,NULL,'title=Let Us C | total_copies:10->10 | available_copies:9->10','2026-07-25 01:10:18'),
(647,'books','UPDATE',58,NULL,'title=The Alchemist | total_copies:9->9 | available_copies:9->8','2026-07-25 01:10:18'),
(648,'books','UPDATE',58,NULL,'title=The Alchemist | total_copies:9->9 | available_copies:8->9','2026-07-25 01:10:18'),
(649,'books','UPDATE',1,NULL,'title=Introduction to Algorithms | total_copies:7->7 | available_copies:7->6','2026-07-25 01:10:18'),
(650,'books','UPDATE',1,NULL,'title=Introduction to Algorithms | total_copies:7->7 | available_copies:6->7','2026-07-25 01:10:18'),
(651,'books','UPDATE',7,NULL,'title=C: The Complete Reference | total_copies:7->7 | available_copies:7->6','2026-07-25 01:10:18'),
(652,'books','UPDATE',7,NULL,'title=C: The Complete Reference | total_copies:7->7 | available_copies:6->7','2026-07-25 01:10:18'),
(653,'books','UPDATE',35,NULL,'title=Five Point Someone | total_copies:9->9 | available_copies:9->8','2026-07-25 01:10:18'),
(654,'books','UPDATE',35,NULL,'title=Five Point Someone | total_copies:9->9 | available_copies:8->9','2026-07-25 01:10:18'),
(655,'books','UPDATE',45,NULL,'title=India After Gandhi | total_copies:5->5 | available_copies:5->4','2026-07-25 01:10:18'),
(656,'books','UPDATE',45,NULL,'title=India After Gandhi | total_copies:5->5 | available_copies:4->5','2026-07-25 01:10:18'),
(657,'books','UPDATE',9,NULL,'title=Let Us C++ | total_copies:7->7 | available_copies:7->6','2026-07-25 01:10:18'),
(658,'books','UPDATE',9,NULL,'title=Let Us C++ | total_copies:7->7 | available_copies:6->7','2026-07-25 01:10:18'),
(659,'books','UPDATE',59,NULL,'title=Veronika Decides to Die | total_copies:4->4 | available_copies:4->3','2026-07-25 01:10:18'),
(660,'books','UPDATE',59,NULL,'title=Veronika Decides to Die | total_copies:4->4 | available_copies:3->4','2026-07-25 01:10:18'),
(661,'books','UPDATE',1,NULL,'title=Introduction to Algorithms | total_copies:7->7 | available_copies:7->6','2026-07-25 01:10:18'),
(662,'books','UPDATE',1,NULL,'title=Introduction to Algorithms | total_copies:7->7 | available_copies:6->7','2026-07-25 01:10:18'),
(663,'books','UPDATE',27,NULL,'title=Murder on the Orient Express | total_copies:8->8 | available_copies:8->7','2026-07-25 01:10:18'),
(664,'books','UPDATE',27,NULL,'title=Murder on the Orient Express | total_copies:8->8 | available_copies:7->8','2026-07-25 01:10:18'),
(665,'books','UPDATE',43,NULL,'title=Homo Deus | total_copies:5->5 | available_copies:5->4','2026-07-25 01:10:18'),
(666,'books','UPDATE',43,NULL,'title=Homo Deus | total_copies:5->5 | available_copies:4->5','2026-07-25 01:10:18'),
(667,'books','UPDATE',32,NULL,'title=Animal Farm | total_copies:9->9 | available_copies:9->8','2026-07-25 01:10:18'),
(668,'books','UPDATE',32,NULL,'title=Animal Farm | total_copies:9->9 | available_copies:8->9','2026-07-25 01:10:18'),
(669,'books','UPDATE',40,NULL,'title=Wings of Fire | total_copies:8->8 | available_copies:8->7','2026-07-25 01:10:18'),
(670,'books','UPDATE',40,NULL,'title=Wings of Fire | total_copies:8->8 | available_copies:7->8','2026-07-25 01:10:18'),
(671,'books','UPDATE',6,NULL,'title=C++: The Complete Reference | total_copies:6->6 | available_copies:6->5','2026-07-25 01:10:18'),
(672,'books','UPDATE',6,NULL,'title=C++: The Complete Reference | total_copies:6->6 | available_copies:5->6','2026-07-25 01:10:18'),
(673,'books','UPDATE',49,NULL,'title=Think and Grow Rich | total_copies:8->8 | available_copies:8->7','2026-07-25 01:10:18'),
(674,'books','UPDATE',49,NULL,'title=Think and Grow Rich | total_copies:8->8 | available_copies:7->8','2026-07-25 01:10:18'),
(675,'books','UPDATE',12,NULL,'title=Python Crash Course | total_copies:9->9 | available_copies:9->8','2026-07-25 01:10:18'),
(676,'books','UPDATE',12,NULL,'title=Python Crash Course | total_copies:9->9 | available_copies:8->9','2026-07-25 01:10:18'),
(677,'books','UPDATE',64,NULL,'title=Digital Fundamentals | total_copies:5->5 | available_copies:5->4','2026-07-25 01:10:18'),
(678,'books','UPDATE',64,NULL,'title=Digital Fundamentals | total_copies:5->5 | available_copies:4->5','2026-07-25 01:10:18'),
(679,'books','UPDATE',71,NULL,'title=Symposium | total_copies:3->3 | available_copies:3->2','2026-07-25 01:10:18'),
(680,'books','UPDATE',71,NULL,'title=Symposium | total_copies:3->3 | available_copies:2->3','2026-07-25 01:10:18'),
(681,'books','UPDATE',55,NULL,'title=Blink | total_copies:4->4 | available_copies:4->3','2026-07-25 01:10:18'),
(682,'books','UPDATE',55,NULL,'title=Blink | total_copies:4->4 | available_copies:3->4','2026-07-25 01:10:18'),
(683,'books','UPDATE',44,NULL,'title=21 Lessons for the 21st Century | total_copies:4->4 | available_copies:4->3','2026-07-25 01:10:18'),
(684,'books','UPDATE',44,NULL,'title=21 Lessons for the 21st Century | total_copies:4->4 | available_copies:3->4','2026-07-25 01:10:18'),
(685,'books','UPDATE',56,NULL,'title=David and Goliath | total_copies:3->3 | available_copies:3->2','2026-07-25 01:10:18'),
(686,'books','UPDATE',56,NULL,'title=David and Goliath | total_copies:3->3 | available_copies:2->3','2026-07-25 01:10:18'),
(687,'books','UPDATE',42,NULL,'title=Sapiens: A Brief History of Humankind | total_copies:8->8 | available_copies:8->7','2026-07-25 01:10:18'),
(688,'books','UPDATE',42,NULL,'title=Sapiens: A Brief History of Humankind | total_copies:8->8 | available_copies:7->8','2026-07-25 01:10:18'),
(689,'books','UPDATE',60,NULL,'title=How to Win Friends and Influence People | total_copies:7->7 | available_copies:7->6','2026-07-25 01:10:18'),
(690,'books','UPDATE',60,NULL,'title=How to Win Friends and Influence People | total_copies:7->7 | available_copies:6->7','2026-07-25 01:10:18'),
(691,'books','UPDATE',58,NULL,'title=The Alchemist | total_copies:9->9 | available_copies:9->8','2026-07-25 01:10:18'),
(692,'books','UPDATE',58,NULL,'title=The Alchemist | total_copies:9->9 | available_copies:8->9','2026-07-25 01:10:18'),
(693,'books','UPDATE',31,NULL,'title=1984 | total_copies:10->10 | available_copies:10->9','2026-07-25 01:10:18'),
(694,'books','UPDATE',31,NULL,'title=1984 | total_copies:10->10 | available_copies:9->10','2026-07-25 01:10:18'),
(695,'books','UPDATE',34,NULL,'title=Swami and Friends | total_copies:4->4 | available_copies:4->3','2026-07-25 01:10:18'),
(696,'books','UPDATE',34,NULL,'title=Swami and Friends | total_copies:4->4 | available_copies:3->4','2026-07-25 01:10:18'),
(697,'books','UPDATE',44,NULL,'title=21 Lessons for the 21st Century | total_copies:4->4 | available_copies:4->3','2026-07-25 01:10:18'),
(698,'books','UPDATE',44,NULL,'title=21 Lessons for the 21st Century | total_copies:4->4 | available_copies:3->4','2026-07-25 01:10:18'),
(699,'books','UPDATE',42,NULL,'title=Sapiens: A Brief History of Humankind | total_copies:8->8 | available_copies:8->7','2026-07-25 01:10:18'),
(700,'books','UPDATE',42,NULL,'title=Sapiens: A Brief History of Humankind | total_copies:8->8 | available_copies:7->8','2026-07-25 01:10:18'),
(701,'books','UPDATE',13,NULL,'title=Linear Algebra and Its Applications | total_copies:5->5 | available_copies:5->4','2026-07-25 01:10:18'),
(702,'books','UPDATE',13,NULL,'title=Linear Algebra and Its Applications | total_copies:5->5 | available_copies:4->5','2026-07-25 01:10:18'),
(703,'books','UPDATE',5,NULL,'title=Java: The Complete Reference | total_copies:9->9 | available_copies:9->8','2026-07-25 01:10:18'),
(704,'books','UPDATE',5,NULL,'title=Java: The Complete Reference | total_copies:9->9 | available_copies:8->9','2026-07-25 01:10:18'),
(705,'books','UPDATE',69,NULL,'title=Digital Design | total_copies:4->4 | available_copies:4->3','2026-07-25 01:10:18'),
(706,'books','UPDATE',69,NULL,'title=Digital Design | total_copies:4->4 | available_copies:3->4','2026-07-25 01:10:18'),
(707,'books','UPDATE',54,NULL,'title=The Tipping Point | total_copies:5->5 | available_copies:5->4','2026-07-25 01:10:18'),
(708,'books','UPDATE',54,NULL,'title=The Tipping Point | total_copies:5->5 | available_copies:4->5','2026-07-25 01:10:18'),
(709,'books','UPDATE',27,NULL,'title=Murder on the Orient Express | total_copies:8->8 | available_copies:8->7','2026-07-25 01:10:18'),
(710,'books','UPDATE',27,NULL,'title=Murder on the Orient Express | total_copies:8->8 | available_copies:7->8','2026-07-25 01:10:18'),
(711,'books','UPDATE',49,NULL,'title=Think and Grow Rich | total_copies:8->8 | available_copies:8->7','2026-07-25 01:10:18'),
(712,'books','UPDATE',49,NULL,'title=Think and Grow Rich | total_copies:8->8 | available_copies:7->8','2026-07-25 01:10:18'),
(713,'books','UPDATE',49,NULL,'title=Think and Grow Rich | total_copies:8->8 | available_copies:8->7','2026-07-25 01:10:18'),
(714,'books','UPDATE',49,NULL,'title=Think and Grow Rich | total_copies:8->8 | available_copies:7->8','2026-07-25 01:10:18'),
(715,'books','UPDATE',40,NULL,'title=Wings of Fire | total_copies:8->8 | available_copies:8->7','2026-07-25 01:10:18'),
(716,'books','UPDATE',40,NULL,'title=Wings of Fire | total_copies:8->8 | available_copies:7->8','2026-07-25 01:10:18'),
(717,'books','UPDATE',52,NULL,'title=Rich Dad\'s Guide to Investing | total_copies:3->3 | available_copies:3->2','2026-07-25 01:10:18'),
(718,'books','UPDATE',52,NULL,'title=Rich Dad\'s Guide to Investing | total_copies:3->3 | available_copies:2->3','2026-07-25 01:10:18'),
(719,'books','UPDATE',67,NULL,'title=Digital Logic and Computer Design | total_copies:6->6 | available_copies:6->5','2026-07-25 01:10:18'),
(720,'books','UPDATE',67,NULL,'title=Digital Logic and Computer Design | total_copies:6->6 | available_copies:5->6','2026-07-25 01:10:18'),
(721,'books','UPDATE',48,NULL,'title=Patriots and Partisans | total_copies:3->3 | available_copies:3->2','2026-07-25 01:10:18'),
(722,'books','UPDATE',48,NULL,'title=Patriots and Partisans | total_copies:3->3 | available_copies:2->3','2026-07-25 01:10:18'),
(723,'books','UPDATE',29,NULL,'title=The Murder of Roger Ackroyd | total_copies:6->6 | available_copies:6->5','2026-07-25 01:10:18'),
(724,'books','UPDATE',29,NULL,'title=The Murder of Roger Ackroyd | total_copies:6->6 | available_copies:5->6','2026-07-25 01:10:18'),
(725,'books','UPDATE',55,NULL,'title=Blink | total_copies:4->4 | available_copies:4->3','2026-07-25 01:10:18'),
(726,'books','UPDATE',55,NULL,'title=Blink | total_copies:4->4 | available_copies:3->4','2026-07-25 01:10:18'),
(727,'books','UPDATE',11,NULL,'title=Pointers in C | total_copies:5->5 | available_copies:5->4','2026-07-25 01:10:18'),
(728,'books','UPDATE',11,NULL,'title=Pointers in C | total_copies:5->5 | available_copies:4->5','2026-07-25 01:10:18'),
(729,'books','UPDATE',49,NULL,'title=Think and Grow Rich | total_copies:8->8 | available_copies:8->7','2026-07-25 01:10:18'),
(730,'books','UPDATE',49,NULL,'title=Think and Grow Rich | total_copies:8->8 | available_copies:7->8','2026-07-25 01:10:18'),
(731,'books','UPDATE',58,NULL,'title=The Alchemist | total_copies:9->9 | available_copies:9->8','2026-07-25 01:10:18'),
(732,'books','UPDATE',58,NULL,'title=The Alchemist | total_copies:9->9 | available_copies:8->9','2026-07-25 01:10:18'),
(733,'books','UPDATE',10,NULL,'title=Data Structures Through C | total_copies:6->6 | available_copies:6->5','2026-07-25 01:10:18'),
(734,'books','UPDATE',10,NULL,'title=Data Structures Through C | total_copies:6->6 | available_copies:5->6','2026-07-25 01:10:18'),
(735,'books','UPDATE',11,NULL,'title=Pointers in C | total_copies:5->5 | available_copies:5->4','2026-07-25 01:10:18'),
(736,'books','UPDATE',11,NULL,'title=Pointers in C | total_copies:5->5 | available_copies:4->5','2026-07-25 01:10:18'),
(737,'books','UPDATE',12,NULL,'title=Python Crash Course | total_copies:9->9 | available_copies:9->8','2026-07-25 01:10:18'),
(738,'books','UPDATE',12,NULL,'title=Python Crash Course | total_copies:9->9 | available_copies:8->9','2026-07-25 01:10:18'),
(739,'books','UPDATE',29,NULL,'title=The Murder of Roger Ackroyd | total_copies:6->6 | available_copies:6->5','2026-07-25 01:10:18'),
(740,'books','UPDATE',29,NULL,'title=The Murder of Roger Ackroyd | total_copies:6->6 | available_copies:5->6','2026-07-25 01:10:18'),
(741,'books','UPDATE',40,NULL,'title=Wings of Fire | total_copies:8->8 | available_copies:8->7','2026-07-25 01:10:18'),
(742,'books','UPDATE',40,NULL,'title=Wings of Fire | total_copies:8->8 | available_copies:7->8','2026-07-25 01:10:18'),
(743,'books','UPDATE',53,NULL,'title=Outliers | total_copies:6->6 | available_copies:6->5','2026-07-25 01:10:18'),
(744,'books','UPDATE',53,NULL,'title=Outliers | total_copies:6->6 | available_copies:5->6','2026-07-25 01:10:18'),
(745,'books','UPDATE',50,NULL,'title=Rich Dad Poor Dad | total_copies:9->9 | available_copies:9->8','2026-07-25 01:10:18'),
(746,'books','UPDATE',50,NULL,'title=Rich Dad Poor Dad | total_copies:9->9 | available_copies:8->9','2026-07-25 01:10:18'),
(747,'books','UPDATE',1,NULL,'title=Introduction to Algorithms | total_copies:7->7 | available_copies:7->6','2026-07-25 01:10:18'),
(748,'books','UPDATE',1,NULL,'title=Introduction to Algorithms | total_copies:7->7 | available_copies:6->7','2026-07-25 01:10:18'),
(749,'books','UPDATE',32,NULL,'title=Animal Farm | total_copies:9->9 | available_copies:9->8','2026-07-25 01:10:18'),
(750,'books','UPDATE',32,NULL,'title=Animal Farm | total_copies:9->9 | available_copies:8->9','2026-07-25 01:10:19'),
(751,'books','UPDATE',29,NULL,'title=The Murder of Roger Ackroyd | total_copies:6->6 | available_copies:6->5','2026-07-25 01:10:19'),
(752,'books','UPDATE',29,NULL,'title=The Murder of Roger Ackroyd | total_copies:6->6 | available_copies:5->6','2026-07-25 01:10:19'),
(753,'books','UPDATE',27,NULL,'title=Murder on the Orient Express | total_copies:8->8 | available_copies:8->7','2026-07-25 01:10:19'),
(754,'books','UPDATE',27,NULL,'title=Murder on the Orient Express | total_copies:8->8 | available_copies:7->8','2026-07-25 01:10:19'),
(755,'books','UPDATE',44,NULL,'title=21 Lessons for the 21st Century | total_copies:4->4 | available_copies:4->3','2026-07-25 01:10:19'),
(756,'books','UPDATE',44,NULL,'title=21 Lessons for the 21st Century | total_copies:4->4 | available_copies:3->4','2026-07-25 01:10:19'),
(757,'books','UPDATE',28,NULL,'title=And Then There Were None | total_copies:9->9 | available_copies:9->8','2026-07-25 01:10:19'),
(758,'books','UPDATE',28,NULL,'title=And Then There Were None | total_copies:9->9 | available_copies:8->9','2026-07-25 01:10:19'),
(759,'books','UPDATE',33,NULL,'title=Malgudi Days | total_copies:7->7 | available_copies:7->6','2026-07-25 01:10:19'),
(760,'books','UPDATE',33,NULL,'title=Malgudi Days | total_copies:7->7 | available_copies:6->7','2026-07-25 01:10:19'),
(761,'books','UPDATE',64,NULL,'title=Digital Fundamentals | total_copies:5->5 | available_copies:5->4','2026-07-25 01:10:19'),
(762,'books','UPDATE',64,NULL,'title=Digital Fundamentals | total_copies:5->5 | available_copies:4->5','2026-07-25 01:10:19'),
(763,'books','UPDATE',45,NULL,'title=India After Gandhi | total_copies:5->5 | available_copies:5->4','2026-07-25 01:10:19'),
(764,'books','UPDATE',45,NULL,'title=India After Gandhi | total_copies:5->5 | available_copies:4->5','2026-07-25 01:10:19'),
(765,'books','UPDATE',51,NULL,'title=Cashflow Quadrant | total_copies:4->4 | available_copies:4->3','2026-07-25 01:10:19'),
(766,'books','UPDATE',51,NULL,'title=Cashflow Quadrant | total_copies:4->4 | available_copies:3->4','2026-07-25 01:10:19'),
(767,'books','UPDATE',54,NULL,'title=The Tipping Point | total_copies:5->5 | available_copies:5->4','2026-07-25 01:10:19'),
(768,'books','UPDATE',54,NULL,'title=The Tipping Point | total_copies:5->5 | available_copies:4->5','2026-07-25 01:10:19'),
(769,'books','UPDATE',41,NULL,'title=Ignited Minds | total_copies:5->5 | available_copies:5->4','2026-07-25 01:10:19'),
(770,'books','UPDATE',41,NULL,'title=Ignited Minds | total_copies:5->5 | available_copies:4->5','2026-07-25 01:10:19'),
(771,'books','UPDATE',49,NULL,'title=Think and Grow Rich | total_copies:8->8 | available_copies:8->7','2026-07-25 01:10:19'),
(772,'books','UPDATE',49,NULL,'title=Think and Grow Rich | total_copies:8->8 | available_copies:7->8','2026-07-25 01:10:19'),
(773,'books','UPDATE',17,NULL,'title=Higher Engineering Mathematics | total_copies:8->8 | available_copies:8->7','2026-07-25 01:10:19'),
(774,'books','UPDATE',17,NULL,'title=Higher Engineering Mathematics | total_copies:8->8 | available_copies:7->8','2026-07-25 01:10:19'),
(775,'books','UPDATE',51,NULL,'title=Cashflow Quadrant | total_copies:4->4 | available_copies:4->3','2026-07-25 01:10:19'),
(776,'books','UPDATE',51,NULL,'title=Cashflow Quadrant | total_copies:4->4 | available_copies:3->4','2026-07-25 01:10:19'),
(777,'books','UPDATE',66,NULL,'title=Electric Circuits Fundamentals | total_copies:3->3 | available_copies:3->2','2026-07-25 01:10:19'),
(778,'books','UPDATE',66,NULL,'title=Electric Circuits Fundamentals | total_copies:3->3 | available_copies:2->3','2026-07-25 01:10:19'),
(779,'books','UPDATE',20,NULL,'title=A Brief History of Time | total_copies:6->6 | available_copies:6->5','2026-07-25 01:10:19'),
(780,'books','UPDATE',20,NULL,'title=A Brief History of Time | total_copies:6->6 | available_copies:5->6','2026-07-25 01:10:19'),
(781,'books','UPDATE',10,NULL,'title=Data Structures Through C | total_copies:6->6 | available_copies:6->5','2026-07-25 01:10:19'),
(782,'books','UPDATE',10,NULL,'title=Data Structures Through C | total_copies:6->6 | available_copies:5->6','2026-07-25 01:10:19'),
(783,'books','UPDATE',42,NULL,'title=Sapiens: A Brief History of Humankind | total_copies:8->8 | available_copies:8->7','2026-07-25 01:10:19'),
(784,'books','UPDATE',42,NULL,'title=Sapiens: A Brief History of Humankind | total_copies:8->8 | available_copies:7->8','2026-07-25 01:10:19'),
(785,'books','UPDATE',27,NULL,'title=Murder on the Orient Express | total_copies:8->8 | available_copies:8->7','2026-07-25 01:10:19'),
(786,'books','UPDATE',27,NULL,'title=Murder on the Orient Express | total_copies:8->8 | available_copies:7->8','2026-07-25 01:10:19'),
(787,'books','UPDATE',31,NULL,'title=1984 | total_copies:10->10 | available_copies:10->9','2026-07-25 01:10:19'),
(788,'books','UPDATE',31,NULL,'title=1984 | total_copies:10->10 | available_copies:9->10','2026-07-25 01:10:19'),
(789,'books','UPDATE',66,NULL,'title=Electric Circuits Fundamentals | total_copies:3->3 | available_copies:3->2','2026-07-25 01:10:19'),
(790,'books','UPDATE',66,NULL,'title=Electric Circuits Fundamentals | total_copies:3->3 | available_copies:2->3','2026-07-25 01:10:19'),
(791,'books','UPDATE',57,NULL,'title=Atomic Habits | total_copies:10->10 | available_copies:10->9','2026-07-25 01:10:19'),
(792,'books','UPDATE',57,NULL,'title=Atomic Habits | total_copies:10->10 | available_copies:9->10','2026-07-25 01:10:19'),
(793,'books','UPDATE',35,NULL,'title=Five Point Someone | total_copies:9->9 | available_copies:9->8','2026-07-25 01:10:19'),
(794,'books','UPDATE',35,NULL,'title=Five Point Someone | total_copies:9->9 | available_copies:8->9','2026-07-25 01:10:19'),
(795,'books','UPDATE',50,NULL,'title=Rich Dad Poor Dad | total_copies:9->9 | available_copies:9->8','2026-07-25 01:10:19'),
(796,'books','UPDATE',50,NULL,'title=Rich Dad Poor Dad | total_copies:9->9 | available_copies:8->9','2026-07-25 01:10:19'),
(797,'books','UPDATE',53,NULL,'title=Outliers | total_copies:6->6 | available_copies:6->5','2026-07-25 01:10:19'),
(798,'books','UPDATE',53,NULL,'title=Outliers | total_copies:6->6 | available_copies:5->6','2026-07-25 01:10:19'),
(799,'books','UPDATE',27,NULL,'title=Murder on the Orient Express | total_copies:8->8 | available_copies:8->7','2026-07-25 01:10:19'),
(800,'books','UPDATE',27,NULL,'title=Murder on the Orient Express | total_copies:8->8 | available_copies:7->8','2026-07-25 01:10:19'),
(801,'books','UPDATE',27,NULL,'title=Murder on the Orient Express | total_copies:8->8 | available_copies:8->7','2026-07-25 01:10:19'),
(802,'books','UPDATE',27,NULL,'title=Murder on the Orient Express | total_copies:8->8 | available_copies:7->8','2026-07-25 01:10:19'),
(803,'books','UPDATE',8,NULL,'title=Let Us C | total_copies:10->10 | available_copies:10->9','2026-07-25 01:10:19'),
(804,'books','UPDATE',8,NULL,'title=Let Us C | total_copies:10->10 | available_copies:9->10','2026-07-25 01:10:19'),
(805,'books','UPDATE',12,NULL,'title=Python Crash Course | total_copies:9->9 | available_copies:9->8','2026-07-25 01:10:19'),
(806,'books','UPDATE',12,NULL,'title=Python Crash Course | total_copies:9->9 | available_copies:8->9','2026-07-25 01:10:19'),
(807,'books','UPDATE',28,NULL,'title=And Then There Were None | total_copies:9->9 | available_copies:9->8','2026-07-25 01:10:19'),
(808,'books','UPDATE',28,NULL,'title=And Then There Were None | total_copies:9->9 | available_copies:8->9','2026-07-25 01:10:19'),
(809,'books','UPDATE',57,NULL,'title=Atomic Habits | total_copies:10->10 | available_copies:10->9','2026-07-25 01:10:19'),
(810,'books','UPDATE',57,NULL,'title=Atomic Habits | total_copies:10->10 | available_copies:9->10','2026-07-25 01:10:19'),
(811,'books','UPDATE',33,NULL,'title=Malgudi Days | total_copies:7->7 | available_copies:7->6','2026-07-25 01:10:19'),
(812,'books','UPDATE',33,NULL,'title=Malgudi Days | total_copies:7->7 | available_copies:6->7','2026-07-25 01:10:19'),
(813,'books','UPDATE',59,NULL,'title=Veronika Decides to Die | total_copies:4->4 | available_copies:4->3','2026-07-25 01:10:19'),
(814,'books','UPDATE',59,NULL,'title=Veronika Decides to Die | total_copies:4->4 | available_copies:3->4','2026-07-25 01:10:19'),
(815,'books','UPDATE',8,NULL,'title=Let Us C | total_copies:10->10 | available_copies:10->9','2026-07-25 01:10:19'),
(816,'books','UPDATE',8,NULL,'title=Let Us C | total_copies:10->10 | available_copies:9->10','2026-07-25 01:10:19'),
(817,'books','UPDATE',32,NULL,'title=Animal Farm | total_copies:9->9 | available_copies:9->8','2026-07-25 01:10:19'),
(818,'books','UPDATE',32,NULL,'title=Animal Farm | total_copies:9->9 | available_copies:8->9','2026-07-25 01:10:19'),
(819,'books','UPDATE',3,NULL,'title=Clean Architecture | total_copies:6->6 | available_copies:6->5','2026-07-25 01:10:19'),
(820,'books','UPDATE',3,NULL,'title=Clean Architecture | total_copies:6->6 | available_copies:5->6','2026-07-25 01:10:19'),
(821,'books','UPDATE',9,NULL,'title=Let Us C++ | total_copies:7->7 | available_copies:7->6','2026-07-25 01:10:19'),
(822,'books','UPDATE',9,NULL,'title=Let Us C++ | total_copies:7->7 | available_copies:6->7','2026-07-25 01:10:19'),
(823,'books','UPDATE',64,NULL,'title=Digital Fundamentals | total_copies:5->5 | available_copies:5->4','2026-07-25 01:10:19'),
(824,'books','UPDATE',64,NULL,'title=Digital Fundamentals | total_copies:5->5 | available_copies:4->5','2026-07-25 01:10:19'),
(825,'books','UPDATE',38,NULL,'title=Einstein: His Life and Universe | total_copies:4->4 | available_copies:4->3','2026-07-25 01:10:19'),
(826,'books','UPDATE',38,NULL,'title=Einstein: His Life and Universe | total_copies:4->4 | available_copies:3->4','2026-07-25 01:10:19'),
(827,'books','UPDATE',50,NULL,'title=Rich Dad Poor Dad | total_copies:9->9 | available_copies:9->8','2026-07-25 01:10:19'),
(828,'books','UPDATE',50,NULL,'title=Rich Dad Poor Dad | total_copies:9->9 | available_copies:8->9','2026-07-25 01:10:19'),
(829,'books','UPDATE',6,NULL,'title=C++: The Complete Reference | total_copies:6->6 | available_copies:6->5','2026-07-25 01:10:19'),
(830,'books','UPDATE',6,NULL,'title=C++: The Complete Reference | total_copies:6->6 | available_copies:5->6','2026-07-25 01:10:19'),
(831,'books','UPDATE',32,NULL,'title=Animal Farm | total_copies:9->9 | available_copies:9->8','2026-07-25 01:10:19'),
(832,'books','UPDATE',32,NULL,'title=Animal Farm | total_copies:9->9 | available_copies:8->9','2026-07-25 01:10:19'),
(833,'books','UPDATE',43,NULL,'title=Homo Deus | total_copies:5->5 | available_copies:5->4','2026-07-25 01:10:19'),
(834,'books','UPDATE',43,NULL,'title=Homo Deus | total_copies:5->5 | available_copies:4->5','2026-07-25 01:10:19'),
(835,'books','UPDATE',27,NULL,'title=Murder on the Orient Express | total_copies:8->8 | available_copies:8->7','2026-07-25 01:10:19'),
(836,'books','UPDATE',27,NULL,'title=Murder on the Orient Express | total_copies:8->8 | available_copies:7->8','2026-07-25 01:10:19'),
(837,'books','UPDATE',37,NULL,'title=Steve Jobs | total_copies:6->6 | available_copies:6->5','2026-07-25 01:10:19'),
(838,'books','UPDATE',37,NULL,'title=Steve Jobs | total_copies:6->6 | available_copies:5->6','2026-07-25 01:10:19'),
(839,'books','UPDATE',53,NULL,'title=Outliers | total_copies:6->6 | available_copies:6->5','2026-07-25 01:10:19'),
(840,'books','UPDATE',53,NULL,'title=Outliers | total_copies:6->6 | available_copies:5->6','2026-07-25 01:10:19'),
(841,'books','UPDATE',1,NULL,'title=Introduction to Algorithms | total_copies:7->7 | available_copies:7->6','2026-07-25 01:10:19'),
(842,'books','UPDATE',1,NULL,'title=Introduction to Algorithms | total_copies:7->7 | available_copies:6->7','2026-07-25 01:10:19'),
(843,'books','UPDATE',47,NULL,'title=Makers of Modern India | total_copies:3->3 | available_copies:3->2','2026-07-25 01:10:19'),
(844,'books','UPDATE',47,NULL,'title=Makers of Modern India | total_copies:3->3 | available_copies:2->3','2026-07-25 01:10:19'),
(845,'books','UPDATE',58,NULL,'title=The Alchemist | total_copies:9->9 | available_copies:9->8','2026-07-25 01:10:19'),
(846,'books','UPDATE',58,NULL,'title=The Alchemist | total_copies:9->9 | available_copies:8->9','2026-07-25 01:10:19'),
(847,'books','UPDATE',35,NULL,'title=Five Point Someone | total_copies:9->9 | available_copies:9->8','2026-07-25 01:10:19'),
(848,'books','UPDATE',35,NULL,'title=Five Point Someone | total_copies:9->9 | available_copies:8->9','2026-07-25 01:10:19'),
(849,'books','UPDATE',53,NULL,'title=Outliers | total_copies:6->6 | available_copies:6->5','2026-07-25 01:10:19'),
(850,'books','UPDATE',53,NULL,'title=Outliers | total_copies:6->6 | available_copies:5->6','2026-07-25 01:10:19'),
(851,'books','UPDATE',12,NULL,'title=Python Crash Course | total_copies:9->9 | available_copies:9->8','2026-07-25 01:10:19'),
(852,'books','UPDATE',12,NULL,'title=Python Crash Course | total_copies:9->9 | available_copies:8->9','2026-07-25 01:10:19'),
(853,'books','UPDATE',28,NULL,'title=And Then There Were None | total_copies:9->9 | available_copies:9->8','2026-07-25 01:10:19'),
(854,'books','UPDATE',28,NULL,'title=And Then There Were None | total_copies:9->9 | available_copies:8->9','2026-07-25 01:10:19'),
(855,'books','UPDATE',4,NULL,'title=The C++ Programming Language | total_copies:5->5 | available_copies:5->4','2026-07-25 01:10:19'),
(856,'books','UPDATE',4,NULL,'title=The C++ Programming Language | total_copies:5->5 | available_copies:4->5','2026-07-25 01:10:19'),
(857,'books','UPDATE',64,NULL,'title=Digital Fundamentals | total_copies:5->5 | available_copies:5->4','2026-07-25 01:10:19'),
(858,'books','UPDATE',64,NULL,'title=Digital Fundamentals | total_copies:5->5 | available_copies:4->5','2026-07-25 01:10:19'),
(859,'books','UPDATE',2,NULL,'title=Clean Code | total_copies:8->8 | available_copies:8->7','2026-07-25 01:10:19'),
(860,'books','UPDATE',2,NULL,'title=Clean Code | total_copies:8->8 | available_copies:7->8','2026-07-25 01:10:19'),
(861,'books','UPDATE',12,NULL,'title=Python Crash Course | total_copies:9->9 | available_copies:9->8','2026-07-25 01:10:19'),
(862,'books','UPDATE',12,NULL,'title=Python Crash Course | total_copies:9->9 | available_copies:8->9','2026-07-25 01:10:19'),
(863,'books','UPDATE',37,NULL,'title=Steve Jobs | total_copies:6->6 | available_copies:6->5','2026-07-25 01:10:19'),
(864,'books','UPDATE',37,NULL,'title=Steve Jobs | total_copies:6->6 | available_copies:5->6','2026-07-25 01:10:19'),
(865,'books','UPDATE',26,NULL,'title=Quantum Mechanics: Concepts and Applications | total_copies:3->3 | available_copies:3->2','2026-07-25 01:10:19'),
(866,'books','UPDATE',26,NULL,'title=Quantum Mechanics: Concepts and Applications | total_copies:3->3 | available_copies:2->3','2026-07-25 01:10:19'),
(867,'books','UPDATE',9,NULL,'title=Let Us C++ | total_copies:7->7 | available_copies:7->6','2026-07-25 01:10:19'),
(868,'books','UPDATE',9,NULL,'title=Let Us C++ | total_copies:7->7 | available_copies:6->7','2026-07-25 01:10:19'),
(869,'books','UPDATE',48,NULL,'title=Patriots and Partisans | total_copies:3->3 | available_copies:3->2','2026-07-25 01:10:19'),
(870,'books','UPDATE',48,NULL,'title=Patriots and Partisans | total_copies:3->3 | available_copies:2->3','2026-07-25 01:10:19'),
(871,'books','UPDATE',32,NULL,'title=Animal Farm | total_copies:9->9 | available_copies:9->8','2026-07-25 01:10:19'),
(872,'books','UPDATE',32,NULL,'title=Animal Farm | total_copies:9->9 | available_copies:8->9','2026-07-25 01:10:19'),
(873,'books','UPDATE',65,NULL,'title=Principles of Electric Circuits | total_copies:3->3 | available_copies:3->2','2026-07-25 01:10:19'),
(874,'books','UPDATE',65,NULL,'title=Principles of Electric Circuits | total_copies:3->3 | available_copies:2->3','2026-07-25 01:10:19'),
(875,'books','UPDATE',5,NULL,'title=Java: The Complete Reference | total_copies:9->9 | available_copies:9->8','2026-07-25 01:10:19'),
(876,'books','UPDATE',5,NULL,'title=Java: The Complete Reference | total_copies:9->9 | available_copies:8->9','2026-07-25 01:10:19'),
(877,'books','UPDATE',64,NULL,'title=Digital Fundamentals | total_copies:5->5 | available_copies:5->4','2026-07-25 01:10:19'),
(878,'books','UPDATE',64,NULL,'title=Digital Fundamentals | total_copies:5->5 | available_copies:4->5','2026-07-25 01:10:19'),
(879,'books','UPDATE',11,NULL,'title=Pointers in C | total_copies:5->5 | available_copies:5->4','2026-07-25 01:10:19'),
(880,'books','UPDATE',11,NULL,'title=Pointers in C | total_copies:5->5 | available_copies:4->5','2026-07-25 01:10:19'),
(881,'books','UPDATE',45,NULL,'title=India After Gandhi | total_copies:5->5 | available_copies:5->4','2026-07-25 01:10:19'),
(882,'books','UPDATE',45,NULL,'title=India After Gandhi | total_copies:5->5 | available_copies:4->5','2026-07-25 01:10:19'),
(883,'books','UPDATE',32,NULL,'title=Animal Farm | total_copies:9->9 | available_copies:9->8','2026-07-25 01:10:19'),
(884,'books','UPDATE',32,NULL,'title=Animal Farm | total_copies:9->9 | available_copies:8->9','2026-07-25 01:10:19'),
(885,'books','UPDATE',12,NULL,'title=Python Crash Course | total_copies:9->9 | available_copies:9->8','2026-07-25 01:10:19'),
(886,'books','UPDATE',12,NULL,'title=Python Crash Course | total_copies:9->9 | available_copies:8->9','2026-07-25 01:10:19'),
(887,'books','UPDATE',28,NULL,'title=And Then There Were None | total_copies:9->9 | available_copies:9->8','2026-07-25 01:10:19'),
(888,'books','UPDATE',28,NULL,'title=And Then There Were None | total_copies:9->9 | available_copies:8->9','2026-07-25 01:10:19'),
(889,'books','UPDATE',1,NULL,'title=Introduction to Algorithms | total_copies:7->7 | available_copies:7->6','2026-07-25 01:10:19'),
(890,'books','UPDATE',1,NULL,'title=Introduction to Algorithms | total_copies:7->7 | available_copies:6->7','2026-07-25 01:10:19'),
(891,'books','UPDATE',12,NULL,'title=Python Crash Course | total_copies:9->9 | available_copies:9->8','2026-07-25 01:10:19'),
(892,'books','UPDATE',12,NULL,'title=Python Crash Course | total_copies:9->9 | available_copies:8->9','2026-07-25 01:10:19'),
(893,'books','UPDATE',49,NULL,'title=Think and Grow Rich | total_copies:8->8 | available_copies:8->7','2026-07-25 01:10:19'),
(894,'books','UPDATE',49,NULL,'title=Think and Grow Rich | total_copies:8->8 | available_copies:7->8','2026-07-25 01:10:19'),
(895,'books','UPDATE',56,NULL,'title=David and Goliath | total_copies:3->3 | available_copies:3->2','2026-07-25 01:10:19'),
(896,'books','UPDATE',56,NULL,'title=David and Goliath | total_copies:3->3 | available_copies:2->3','2026-07-25 01:10:19'),
(897,'books','UPDATE',55,NULL,'title=Blink | total_copies:4->4 | available_copies:4->3','2026-07-25 01:10:19'),
(898,'books','UPDATE',55,NULL,'title=Blink | total_copies:4->4 | available_copies:3->4','2026-07-25 01:10:19'),
(899,'books','UPDATE',54,NULL,'title=The Tipping Point | total_copies:5->5 | available_copies:5->4','2026-07-25 01:10:19'),
(900,'books','UPDATE',54,NULL,'title=The Tipping Point | total_copies:5->5 | available_copies:4->5','2026-07-25 01:10:19'),
(901,'books','UPDATE',12,NULL,'title=Python Crash Course | total_copies:9->9 | available_copies:9->8','2026-07-25 01:10:19'),
(902,'books','UPDATE',15,NULL,'title=Calculus | total_copies:5->5 | available_copies:5->4','2026-07-25 01:10:19'),
(903,'books','UPDATE',2,NULL,'title=Clean Code | total_copies:8->8 | available_copies:8->7','2026-07-25 01:10:19'),
(904,'books','UPDATE',69,NULL,'title=Digital Design | total_copies:4->4 | available_copies:4->3','2026-07-25 01:10:19'),
(905,'books','UPDATE',59,NULL,'title=Veronika Decides to Die | total_copies:4->4 | available_copies:4->3','2026-07-25 01:10:19'),
(906,'books','UPDATE',58,NULL,'title=The Alchemist | total_copies:9->9 | available_copies:9->8','2026-07-25 01:10:19'),
(907,'books','UPDATE',58,NULL,'title=The Alchemist | total_copies:9->9 | available_copies:8->7','2026-07-25 01:10:19'),
(908,'books','UPDATE',21,NULL,'title=The Universe in a Nutshell | total_copies:4->4 | available_copies:4->3','2026-07-25 01:10:19'),
(909,'books','UPDATE',59,NULL,'title=Veronika Decides to Die | total_copies:4->4 | available_copies:3->2','2026-07-25 01:10:19'),
(910,'books','UPDATE',9,NULL,'title=Let Us C++ | total_copies:7->7 | available_copies:7->6','2026-07-25 01:10:19'),
(911,'books','UPDATE',63,NULL,'title=Electronic Devices and Circuit Theory | total_copies:5->5 | available_copies:5->4','2026-07-25 01:10:19'),
(912,'books','UPDATE',28,NULL,'title=And Then There Were None | total_copies:9->9 | available_copies:9->8','2026-07-25 01:10:19'),
(913,'books','UPDATE',34,NULL,'title=Swami and Friends | total_copies:4->4 | available_copies:4->3','2026-07-25 01:10:19'),
(914,'books','UPDATE',5,NULL,'title=Java: The Complete Reference | total_copies:9->9 | available_copies:9->8','2026-07-25 01:10:19'),
(915,'books','UPDATE',13,NULL,'title=Linear Algebra and Its Applications | total_copies:5->5 | available_copies:5->4','2026-07-25 01:10:19'),
(916,'books','UPDATE',2,NULL,'title=Clean Code | total_copies:8->8 | available_copies:7->6','2026-07-25 01:10:19'),
(917,'books','UPDATE',68,NULL,'title=Computer System Architecture | total_copies:4->4 | available_copies:4->3','2026-07-25 01:10:19'),
(918,'books','UPDATE',68,NULL,'title=Computer System Architecture | total_copies:4->4 | available_copies:3->2','2026-07-25 01:10:19'),
(919,'books','UPDATE',34,NULL,'title=Swami and Friends | total_copies:4->4 | available_copies:3->2','2026-07-25 01:10:19'),
(920,'books','UPDATE',35,NULL,'title=Five Point Someone | total_copies:9->9 | available_copies:9->8','2026-07-25 01:10:19'),
(921,'books','UPDATE',29,NULL,'title=The Murder of Roger Ackroyd | total_copies:6->6 | available_copies:6->5','2026-07-25 01:10:19'),
(922,'books','UPDATE',25,NULL,'title=Quantum Physics for Beginners | total_copies:3->3 | available_copies:3->2','2026-07-25 01:10:19'),
(923,'books','UPDATE',20,NULL,'title=A Brief History of Time | total_copies:6->6 | available_copies:6->5','2026-07-25 01:10:19'),
(924,'books','UPDATE',35,NULL,'title=Five Point Someone | total_copies:9->9 | available_copies:8->7','2026-07-25 01:10:19'),
(925,'books','UPDATE',14,NULL,'title=Introduction to Linear Algebra | total_copies:4->4 | available_copies:4->3','2026-07-25 01:10:19'),
(926,'books','UPDATE',15,NULL,'title=Calculus | total_copies:5->5 | available_copies:4->3','2026-07-25 01:10:19'),
(927,'books','UPDATE',42,NULL,'title=Sapiens: A Brief History of Humankind | total_copies:8->8 | available_copies:8->7','2026-07-25 01:10:19'),
(928,'books','UPDATE',58,NULL,'title=The Alchemist | total_copies:9->9 | available_copies:7->6','2026-07-25 01:10:19'),
(929,'books','UPDATE',40,NULL,'title=Wings of Fire | total_copies:8->8 | available_copies:8->7','2026-07-25 01:10:19'),
(930,'books','UPDATE',22,NULL,'title=Concepts of Modern Physics | total_copies:5->5 | available_copies:5->4','2026-07-25 01:10:19'),
(931,'books','UPDATE',17,NULL,'title=Higher Engineering Mathematics | total_copies:8->8 | available_copies:8->7','2026-07-25 01:10:19'),
(932,'books','UPDATE',8,NULL,'title=Let Us C | total_copies:10->10 | available_copies:10->9','2026-07-25 01:10:19'),
(933,'books','UPDATE',54,NULL,'title=The Tipping Point | total_copies:5->5 | available_copies:5->4','2026-07-25 01:10:19'),
(934,'books','UPDATE',23,NULL,'title=Concepts of Physics Part 1 | total_copies:7->7 | available_copies:7->6','2026-07-25 01:10:19'),
(935,'books','UPDATE',53,NULL,'title=Outliers | total_copies:6->6 | available_copies:6->5','2026-07-25 01:10:19'),
(936,'books','UPDATE',60,NULL,'title=How to Win Friends and Influence People | total_copies:7->7 | available_copies:7->6','2026-07-25 01:10:19'),
(937,'books','UPDATE',68,NULL,'title=Computer System Architecture | total_copies:4->4 | available_copies:2->1','2026-07-25 01:10:19'),
(938,'books','UPDATE',50,NULL,'title=Rich Dad Poor Dad | total_copies:9->9 | available_copies:9->8','2026-07-25 01:10:19'),
(939,'books','UPDATE',34,NULL,'title=Swami and Friends | total_copies:4->4 | available_copies:2->1','2026-07-25 01:10:19'),
(940,'books','UPDATE',63,NULL,'title=Electronic Devices and Circuit Theory | total_copies:5->5 | available_copies:4->3','2026-07-25 01:10:19'),
(941,'books','UPDATE',14,NULL,'title=Introduction to Linear Algebra | total_copies:4->4 | available_copies:3->2','2026-07-25 01:10:19'),
(942,'books','UPDATE',58,NULL,'title=The Alchemist | total_copies:9->9 | available_copies:6->5','2026-07-25 01:10:19'),
(943,'books','UPDATE',23,NULL,'title=Concepts of Physics Part 1 | total_copies:7->7 | available_copies:6->5','2026-07-25 01:10:19'),
(944,'books','UPDATE',28,NULL,'title=And Then There Were None | total_copies:9->9 | available_copies:8->7','2026-07-25 01:10:19'),
(945,'books','UPDATE',47,NULL,'title=Makers of Modern India | total_copies:3->3 | available_copies:3->2','2026-07-25 01:10:19'),
(946,'books','UPDATE',5,NULL,'title=Java: The Complete Reference | total_copies:9->9 | available_copies:8->7','2026-07-25 01:10:19'),
(947,'books','UPDATE',4,NULL,'title=The C++ Programming Language | total_copies:5->5 | available_copies:5->4','2026-07-25 01:10:19'),
(948,'books','UPDATE',7,NULL,'title=C: The Complete Reference | total_copies:7->7 | available_copies:7->6','2026-07-25 01:10:19'),
(949,'books','UPDATE',55,NULL,'title=Blink | total_copies:4->4 | available_copies:4->3','2026-07-25 01:10:19'),
(950,'books','UPDATE',27,NULL,'title=Murder on the Orient Express | total_copies:8->8 | available_copies:8->7','2026-07-25 01:10:19'),
(951,'fine_payments','INSERT',1,NULL,'issue_id=1 | amount=160.00','2026-07-25 01:10:19'),
(952,'fine_payments','INSERT',2,NULL,'issue_id=5 | amount=95.00','2026-07-25 01:10:19'),
(953,'fine_payments','INSERT',3,NULL,'issue_id=20 | amount=140.00','2026-07-25 01:10:19'),
(954,'fine_payments','INSERT',4,NULL,'issue_id=22 | amount=170.00','2026-07-25 01:10:19'),
(955,'fine_payments','INSERT',5,NULL,'issue_id=23 | amount=210.00','2026-07-25 01:10:19'),
(956,'fine_payments','INSERT',6,NULL,'issue_id=25 | amount=155.00','2026-07-25 01:10:19'),
(957,'fine_payments','INSERT',7,NULL,'issue_id=31 | amount=70.00','2026-07-25 01:10:19'),
(958,'fine_payments','INSERT',8,NULL,'issue_id=32 | amount=185.00','2026-07-25 01:10:19'),
(959,'fine_payments','INSERT',9,NULL,'issue_id=45 | amount=190.00','2026-07-25 01:10:19'),
(960,'fine_payments','INSERT',10,NULL,'issue_id=51 | amount=215.00','2026-07-25 01:10:19'),
(961,'fine_payments','INSERT',11,NULL,'issue_id=52 | amount=225.00','2026-07-25 01:10:19'),
(962,'fine_payments','INSERT',12,NULL,'issue_id=55 | amount=35.00','2026-07-25 01:10:19'),
(963,'fine_payments','INSERT',13,NULL,'issue_id=63 | amount=210.00','2026-07-25 01:10:19'),
(964,'fine_payments','INSERT',14,NULL,'issue_id=64 | amount=155.00','2026-07-25 01:10:19'),
(965,'fine_payments','INSERT',15,NULL,'issue_id=74 | amount=20.00','2026-07-25 01:10:19'),
(966,'fine_payments','INSERT',16,NULL,'issue_id=75 | amount=125.00','2026-07-25 01:10:19'),
(967,'fine_payments','INSERT',17,NULL,'issue_id=81 | amount=120.00','2026-07-25 01:10:19'),
(968,'fine_payments','INSERT',18,NULL,'issue_id=85 | amount=25.00','2026-07-25 01:10:19'),
(969,'fine_payments','INSERT',19,NULL,'issue_id=95 | amount=135.00','2026-07-25 01:10:19'),
(970,'fine_payments','INSERT',20,NULL,'issue_id=100 | amount=185.00','2026-07-25 01:10:19'),
(971,'fine_payments','INSERT',21,NULL,'issue_id=101 | amount=160.00','2026-07-25 01:10:19'),
(972,'fine_payments','INSERT',22,NULL,'issue_id=105 | amount=90.00','2026-07-25 01:10:19'),
(973,'fine_payments','INSERT',23,NULL,'issue_id=111 | amount=125.00','2026-07-25 01:10:19'),
(974,'fine_payments','INSERT',24,NULL,'issue_id=113 | amount=20.00','2026-07-25 01:10:19'),
(975,'fine_payments','INSERT',25,NULL,'issue_id=121 | amount=45.00','2026-07-25 01:10:19'),
(976,'fine_payments','INSERT',26,NULL,'issue_id=122 | amount=95.00','2026-07-25 01:10:19'),
(977,'fine_payments','INSERT',27,NULL,'issue_id=124 | amount=130.00','2026-07-25 01:10:19'),
(978,'fine_payments','INSERT',28,NULL,'issue_id=130 | amount=100.00','2026-07-25 01:10:19'),
(979,'fine_payments','INSERT',29,NULL,'issue_id=133 | amount=155.00','2026-07-25 01:10:19'),
(980,'fine_payments','INSERT',30,NULL,'issue_id=142 | amount=10.00','2026-07-25 01:10:19'),
(981,'fine_payments','INSERT',31,NULL,'issue_id=144 | amount=135.00','2026-07-25 01:10:19'),
(982,'fine_payments','INSERT',32,NULL,'issue_id=145 | amount=20.00','2026-07-25 01:10:19'),
(983,'fine_payments','INSERT',33,NULL,'issue_id=150 | amount=100.00','2026-07-25 01:10:19'),
(984,'fine_payments','INSERT',34,NULL,'issue_id=155 | amount=180.00','2026-07-25 01:10:19'),
(985,'fine_payments','INSERT',35,NULL,'issue_id=161 | amount=20.00','2026-07-25 01:10:19'),
(986,'fine_payments','INSERT',36,NULL,'issue_id=172 | amount=175.00','2026-07-25 01:10:19'),
(987,'fine_payments','INSERT',37,NULL,'issue_id=174 | amount=130.00','2026-07-25 01:10:19'),
(988,'fine_payments','INSERT',38,NULL,'issue_id=180 | amount=180.00','2026-07-25 01:10:19'),
(989,'fine_payments','INSERT',39,NULL,'issue_id=185 | amount=205.00','2026-07-25 01:10:19'),
(990,'fine_payments','INSERT',40,NULL,'issue_id=205 | amount=135.00','2026-07-25 01:10:19'),
(991,'fine_payments','INSERT',41,NULL,'issue_id=210 | amount=80.00','2026-07-25 01:10:19'),
(992,'fine_payments','INSERT',42,NULL,'issue_id=224 | amount=155.00','2026-07-25 01:10:19'),
(993,'fine_payments','INSERT',43,NULL,'issue_id=232 | amount=105.00','2026-07-25 01:10:19'),
(994,'fine_payments','INSERT',44,NULL,'issue_id=233 | amount=25.00','2026-07-25 01:10:19'),
(995,'fine_payments','INSERT',45,NULL,'issue_id=244 | amount=185.00','2026-07-25 01:10:19'),
(996,'fine_payments','INSERT',46,NULL,'issue_id=245 | amount=130.00','2026-07-25 01:10:19'),
(997,'fine_payments','INSERT',47,NULL,'issue_id=250 | amount=50.00','2026-07-25 01:10:19'),
(998,'fine_payments','INSERT',48,NULL,'issue_id=251 | amount=120.00','2026-07-25 01:10:19'),
(999,'fine_payments','INSERT',49,NULL,'issue_id=253 | amount=130.00','2026-07-25 01:10:19'),
(1000,'fine_payments','INSERT',50,NULL,'issue_id=254 | amount=190.00','2026-07-25 01:10:19'),
(1001,'fine_payments','INSERT',51,NULL,'issue_id=262 | amount=130.00','2026-07-25 01:10:19'),
(1002,'fine_payments','INSERT',52,NULL,'issue_id=270 | amount=10.00','2026-07-25 01:10:19'),
(1003,'fine_payments','INSERT',53,NULL,'issue_id=274 | amount=215.00','2026-07-25 01:10:19'),
(1004,'fine_payments','INSERT',54,NULL,'issue_id=275 | amount=160.00','2026-07-25 01:10:19'),
(1005,'fine_payments','INSERT',55,NULL,'issue_id=284 | amount=155.00','2026-07-25 01:10:19'),
(1006,'fine_payments','INSERT',56,NULL,'issue_id=291 | amount=185.00','2026-07-25 01:10:19'),
(1007,'fine_payments','INSERT',57,NULL,'issue_id=292 | amount=135.00','2026-07-25 01:10:19'),
(1008,'fine_payments','INSERT',58,NULL,'issue_id=293 | amount=155.00','2026-07-25 01:10:19'),
(1009,'fine_payments','INSERT',59,NULL,'issue_id=295 | amount=65.00','2026-07-25 01:10:19'),
(1010,'fine_payments','INSERT',60,NULL,'issue_id=304 | amount=130.00','2026-07-25 01:10:19'),
(1011,'fine_payments','INSERT',61,NULL,'issue_id=315 | amount=10.00','2026-07-25 01:10:19'),
(1012,'fine_payments','INSERT',62,NULL,'issue_id=323 | amount=150.00','2026-07-25 01:10:19'),
(1013,'fine_payments','INSERT',63,NULL,'issue_id=331 | amount=190.00','2026-07-25 01:10:19'),
(1014,'fine_payments','INSERT',64,NULL,'issue_id=332 | amount=200.00','2026-07-25 01:10:19'),
(1015,'fine_payments','INSERT',65,NULL,'issue_id=340 | amount=15.00','2026-07-25 01:10:19'),
(1016,'fine_payments','INSERT',66,NULL,'issue_id=341 | amount=15.00','2026-07-25 01:10:19'),
(1017,'fine_payments','INSERT',67,NULL,'issue_id=342 | amount=90.00','2026-07-25 01:10:19'),
(1018,'fine_payments','INSERT',68,NULL,'issue_id=344 | amount=55.00','2026-07-25 01:10:19'),
(1019,'fine_payments','INSERT',69,NULL,'issue_id=350 | amount=25.00','2026-07-25 01:10:19'),
(1020,'fine_payments','INSERT',70,NULL,'issue_id=352 | amount=145.00','2026-07-25 01:10:19'),
(1021,'fine_payments','INSERT',71,NULL,'issue_id=360 | amount=190.00','2026-07-25 01:10:19'),
(1022,'fine_payments','INSERT',72,NULL,'issue_id=364 | amount=45.00','2026-07-25 01:10:19'),
(1023,'fine_payments','INSERT',73,NULL,'issue_id=371 | amount=210.00','2026-07-25 01:10:19'),
(1024,'fine_payments','INSERT',74,NULL,'issue_id=372 | amount=25.00','2026-07-25 01:10:19'),
(1025,'fine_payments','INSERT',75,NULL,'issue_id=380 | amount=65.00','2026-07-25 01:10:19'),
(1026,'fine_payments','INSERT',76,NULL,'issue_id=382 | amount=70.00','2026-07-25 01:10:19'),
(1027,'fine_payments','INSERT',77,NULL,'issue_id=384 | amount=135.00','2026-07-25 01:10:19'),
(1028,'fine_payments','INSERT',78,NULL,'issue_id=395 | amount=210.00','2026-07-25 01:10:19'),
(1029,'fine_payments','INSERT',79,NULL,'issue_id=401 | amount=165.00','2026-07-25 01:10:19'),
(1030,'fine_payments','INSERT',80,NULL,'issue_id=402 | amount=155.00','2026-07-25 01:10:19'),
(1031,'fine_payments','INSERT',81,NULL,'issue_id=404 | amount=105.00','2026-07-25 01:10:19'),
(1032,'fine_payments','INSERT',82,NULL,'issue_id=412 | amount=55.00','2026-07-25 01:10:19'),
(1033,'fine_payments','INSERT',83,NULL,'issue_id=415 | amount=50.00','2026-07-25 01:10:19'),
(1034,'fine_payments','INSERT',84,NULL,'issue_id=420 | amount=135.00','2026-07-25 01:10:19'),
(1035,'fine_payments','INSERT',85,NULL,'issue_id=423 | amount=130.00','2026-07-25 01:10:19'),
(1036,'fine_payments','INSERT',86,NULL,'issue_id=425 | amount=145.00','2026-07-25 01:10:19'),
(1037,'fine_payments','INSERT',87,NULL,'issue_id=431 | amount=115.00','2026-07-25 01:10:19'),
(1038,'fine_payments','INSERT',88,NULL,'issue_id=432 | amount=180.00','2026-07-25 01:10:19'),
(1039,'fine_payments','INSERT',89,NULL,'issue_id=435 | amount=150.00','2026-07-25 01:10:19'),
(1040,'fine_payments','INSERT',90,NULL,'issue_id=441 | amount=155.00','2026-07-25 01:10:19'),
(1041,'fine_payments','INSERT',91,NULL,'issue_id=444 | amount=150.00','2026-07-25 01:10:19'),
(1042,'fine_payments','INSERT',128,NULL,'issue_id=6 | amount=88.00','2026-07-25 01:10:19'),
(1043,'fine_payments','INSERT',129,NULL,'issue_id=26 | amount=72.00','2026-07-25 01:10:19'),
(1044,'fine_payments','INSERT',130,NULL,'issue_id=27 | amount=8.00','2026-07-25 01:10:19'),
(1045,'fine_payments','INSERT',131,NULL,'issue_id=47 | amount=6.00','2026-07-25 01:10:19'),
(1046,'fine_payments','INSERT',132,NULL,'issue_id=86 | amount=66.00','2026-07-25 01:10:19'),
(1047,'fine_payments','INSERT',133,NULL,'issue_id=116 | amount=28.00','2026-07-25 01:10:19'),
(1048,'fine_payments','INSERT',134,NULL,'issue_id=126 | amount=18.00','2026-07-25 01:10:19'),
(1049,'fine_payments','INSERT',135,NULL,'issue_id=136 | amount=64.00','2026-07-25 01:10:19'),
(1050,'fine_payments','INSERT',136,NULL,'issue_id=157 | amount=48.00','2026-07-25 01:10:19'),
(1051,'fine_payments','INSERT',137,NULL,'issue_id=166 | amount=12.00','2026-07-25 01:10:19'),
(1052,'fine_payments','INSERT',138,NULL,'issue_id=167 | amount=12.00','2026-07-25 01:10:19'),
(1053,'fine_payments','INSERT',139,NULL,'issue_id=177 | amount=42.00','2026-07-25 01:10:19'),
(1054,'fine_payments','INSERT',140,NULL,'issue_id=187 | amount=28.00','2026-07-25 01:10:19'),
(1055,'fine_payments','INSERT',141,NULL,'issue_id=196 | amount=32.00','2026-07-25 01:10:19'),
(1056,'fine_payments','INSERT',142,NULL,'issue_id=227 | amount=80.00','2026-07-25 01:10:19'),
(1057,'fine_payments','INSERT',143,NULL,'issue_id=256 | amount=90.00','2026-07-25 01:10:19'),
(1058,'fine_payments','INSERT',144,NULL,'issue_id=257 | amount=52.00','2026-07-25 01:10:19'),
(1059,'fine_payments','INSERT',145,NULL,'issue_id=267 | amount=36.00','2026-07-25 01:10:19'),
(1060,'fine_payments','INSERT',146,NULL,'issue_id=276 | amount=30.00','2026-07-25 01:10:19'),
(1061,'fine_payments','INSERT',147,NULL,'issue_id=277 | amount=74.00','2026-07-25 01:10:19'),
(1062,'fine_payments','INSERT',148,NULL,'issue_id=296 | amount=34.00','2026-07-25 01:10:19'),
(1063,'fine_payments','INSERT',149,NULL,'issue_id=317 | amount=86.00','2026-07-25 01:10:19'),
(1064,'fine_payments','INSERT',150,NULL,'issue_id=326 | amount=50.00','2026-07-25 01:10:19'),
(1065,'fine_payments','INSERT',151,NULL,'issue_id=327 | amount=68.00','2026-07-25 01:10:19'),
(1066,'fine_payments','INSERT',152,NULL,'issue_id=336 | amount=68.00','2026-07-25 01:10:19'),
(1067,'fine_payments','INSERT',153,NULL,'issue_id=337 | amount=90.00','2026-07-25 01:10:19'),
(1068,'fine_payments','INSERT',154,NULL,'issue_id=347 | amount=88.00','2026-07-25 01:10:19'),
(1069,'fine_payments','INSERT',155,NULL,'issue_id=357 | amount=54.00','2026-07-25 01:10:19'),
(1070,'fine_payments','INSERT',156,NULL,'issue_id=367 | amount=20.00','2026-07-25 01:10:19'),
(1071,'fine_payments','INSERT',157,NULL,'issue_id=376 | amount=86.00','2026-07-25 01:10:19'),
(1072,'fine_payments','INSERT',158,NULL,'issue_id=397 | amount=18.00','2026-07-25 01:10:19'),
(1073,'fine_payments','INSERT',159,NULL,'issue_id=417 | amount=88.00','2026-07-25 01:10:19'),
(1074,'fine_payments','INSERT',160,NULL,'issue_id=436 | amount=30.00','2026-07-25 01:10:19');
/*!40000 ALTER TABLE `audit_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `authors`
--

DROP TABLE IF EXISTS `authors`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `authors` (
  `author_id` int(11) NOT NULL AUTO_INCREMENT,
  `author_name` varchar(120) NOT NULL,
  `nationality` varchar(60) DEFAULT NULL,
  PRIMARY KEY (`author_id`),
  UNIQUE KEY `uk_author_name` (`author_name`)
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `authors`
--

LOCK TABLES `authors` WRITE;
/*!40000 ALTER TABLE `authors` DISABLE KEYS */;
INSERT INTO `authors` VALUES
(1,'Thomas H. Cormen','American'),
(2,'Charles E. Leiserson','American'),
(3,'Robert C. Martin','American'),
(4,'Bjarne Stroustrup','Danish'),
(5,'Herbert Schildt','American'),
(6,'Yashavant Kanetkar','Indian'),
(7,'Eric Matthes','American'),
(8,'Gilbert Strang','American'),
(9,'B.S. Grewal','Indian'),
(10,'Sheldon Ross','American'),
(11,'Stephen Hawking','British'),
(12,'Arthur Beiser','American'),
(13,'H.C. Verma','Indian'),
(14,'Agatha Christie','British'),
(15,'George Orwell','British'),
(16,'R.K. Narayan','Indian'),
(17,'Chetan Bhagat','Indian'),
(18,'Walter Isaacson','American'),
(19,'APJ Abdul Kalam','Indian'),
(20,'Yuval Noah Harari','Israeli'),
(21,'Ramchandra Guha','Indian'),
(22,'Napoleon Hill','American'),
(23,'Robert Kiyosaki','American'),
(24,'Malcolm Gladwell','Canadian'),
(25,'James Clear','American'),
(26,'Paulo Coelho','Brazilian'),
(27,'Dale Carnegie','American'),
(28,'Thomas L. Floyd','American'),
(29,'Morris Mano','American'),
(30,'Plato','Ancient Greek');
/*!40000 ALTER TABLE `authors` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `book_authors`
--

DROP TABLE IF EXISTS `book_authors`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `book_authors` (
  `book_id` int(11) NOT NULL,
  `author_id` int(11) NOT NULL,
  PRIMARY KEY (`book_id`,`author_id`),
  KEY `fk_ba_author` (`author_id`),
  CONSTRAINT `fk_ba_author` FOREIGN KEY (`author_id`) REFERENCES `authors` (`author_id`) ON DELETE CASCADE,
  CONSTRAINT `fk_ba_book` FOREIGN KEY (`book_id`) REFERENCES `books` (`book_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `book_authors`
--

LOCK TABLES `book_authors` WRITE;
/*!40000 ALTER TABLE `book_authors` DISABLE KEYS */;
INSERT INTO `book_authors` VALUES
(1,1),
(1,2),
(2,3),
(3,3),
(4,4),
(5,5),
(6,5),
(7,5),
(8,6),
(9,6),
(10,6),
(11,6),
(12,7),
(13,8),
(14,8),
(15,8),
(16,8),
(17,9),
(18,9),
(19,10),
(20,11),
(21,11),
(22,12),
(23,13),
(24,13),
(25,13),
(26,13),
(27,14),
(28,14),
(29,14),
(30,14),
(31,15),
(32,15),
(33,16),
(34,16),
(35,17),
(36,17),
(37,18),
(38,18),
(39,18),
(40,19),
(41,19),
(42,20),
(43,20),
(44,20),
(45,21),
(46,21),
(47,21),
(48,21),
(49,22),
(50,23),
(51,23),
(52,23),
(53,24),
(54,24),
(55,24),
(56,24),
(57,25),
(58,26),
(59,26),
(60,27),
(61,27),
(62,27),
(63,28),
(64,28),
(65,28),
(66,28),
(67,29),
(68,29),
(69,29),
(70,30),
(71,30),
(72,30),
(73,30),
(74,30),
(75,30);
/*!40000 ALTER TABLE `book_authors` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `book_issues`
--

DROP TABLE IF EXISTS `book_issues`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `book_issues` (
  `issue_id` int(11) NOT NULL AUTO_INCREMENT,
  `book_id` int(11) NOT NULL,
  `student_id` int(11) NOT NULL,
  `issue_date` date NOT NULL DEFAULT curdate(),
  `due_date` date NOT NULL,
  `return_date` date DEFAULT NULL,
  `fine_amount` decimal(8,2) NOT NULL DEFAULT 0.00,
  `fine_paid` tinyint(1) NOT NULL DEFAULT 0,
  `status` enum('issued','returned','overdue','lost') NOT NULL DEFAULT 'issued',
  `issued_by` int(11) DEFAULT NULL,
  `returned_to` int(11) DEFAULT NULL,
  `remarks` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`issue_id`),
  KEY `fk_issue_admin` (`issued_by`),
  KEY `fk_return_admin` (`returned_to`),
  KEY `idx_issues_book` (`book_id`),
  KEY `idx_issues_student` (`student_id`),
  KEY `idx_issues_status` (`status`),
  KEY `idx_issues_due_status` (`due_date`,`status`),
  KEY `idx_issues_issue_date` (`issue_date`),
  CONSTRAINT `fk_issue_admin` FOREIGN KEY (`issued_by`) REFERENCES `admins` (`admin_id`) ON DELETE SET NULL,
  CONSTRAINT `fk_issue_book` FOREIGN KEY (`book_id`) REFERENCES `books` (`book_id`),
  CONSTRAINT `fk_issue_student` FOREIGN KEY (`student_id`) REFERENCES `students` (`student_id`),
  CONSTRAINT `fk_return_admin` FOREIGN KEY (`returned_to`) REFERENCES `admins` (`admin_id`) ON DELETE SET NULL,
  CONSTRAINT `chk_issue_dates` CHECK (`due_date` >= `issue_date`),
  CONSTRAINT `chk_fine_amount` CHECK (`fine_amount` >= 0)
) ENGINE=InnoDB AUTO_INCREMENT=501 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `book_issues`
--

LOCK TABLES `book_issues` WRITE;
/*!40000 ALTER TABLE `book_issues` DISABLE KEYS */;
INSERT INTO `book_issues` VALUES
(1,17,77,'2025-09-29','2025-10-06','2025-11-07',160.00,1,'returned',2,1,NULL),
(2,39,47,'2025-10-22','2025-11-12','2025-11-12',0.00,0,'returned',1,1,NULL),
(3,60,93,'2026-02-26','2026-03-12','2026-03-09',0.00,0,'returned',1,1,NULL),
(4,60,44,'2026-01-20','2026-02-03','2026-02-02',0.00,0,'returned',2,2,NULL),
(5,57,35,'2025-07-12','2025-07-26','2025-08-14',95.00,1,'returned',2,1,NULL),
(6,31,9,'2025-08-24','2025-09-07','2025-10-21',220.00,0,'returned',2,2,NULL),
(7,5,53,'2026-03-13','2026-03-20','2026-03-20',0.00,0,'returned',2,2,NULL),
(8,57,141,'2026-04-30','2026-05-14','2026-05-13',0.00,0,'returned',2,1,NULL),
(9,42,91,'2026-01-02','2026-01-16','2026-01-11',0.00,0,'returned',1,1,NULL),
(10,64,42,'2025-12-22','2025-12-29','2025-12-28',0.00,0,'returned',1,2,NULL),
(11,31,96,'2025-08-30','2025-09-20','2025-09-20',0.00,0,'returned',1,2,NULL),
(12,43,124,'2025-11-01','2025-11-15','2025-11-12',0.00,0,'returned',1,2,NULL),
(13,31,31,'2026-02-08','2026-02-22','2026-02-22',0.00,0,'returned',2,1,NULL),
(14,28,25,'2026-04-25','2026-05-09','2026-05-05',0.00,0,'returned',1,1,NULL),
(15,54,32,'2026-04-24','2026-05-15','2026-05-14',0.00,0,'returned',1,1,NULL),
(16,56,31,'2025-08-13','2025-09-03','2025-08-30',0.00,0,'returned',1,2,NULL),
(17,55,13,'2025-06-13','2025-06-27','2025-06-23',0.00,0,'returned',2,1,NULL),
(18,9,7,'2025-08-31','2025-09-21','2025-09-16',0.00,0,'returned',2,2,NULL),
(19,53,70,'2026-04-29','2026-05-20','2026-05-19',0.00,0,'returned',1,2,NULL),
(20,31,146,'2026-05-16','2026-05-30','2026-06-27',140.00,1,'returned',1,2,NULL),
(21,49,57,'2025-05-17','2025-05-31','2025-05-26',0.00,0,'returned',1,2,NULL),
(22,40,81,'2025-09-16','2025-09-30','2025-11-03',170.00,1,'returned',2,2,NULL),
(23,33,56,'2025-08-01','2025-08-08','2025-09-19',210.00,1,'returned',1,2,NULL),
(24,31,31,'2026-02-16','2026-03-02','2026-03-02',0.00,0,'returned',1,2,NULL),
(25,30,94,'2026-02-04','2026-02-18','2026-03-21',155.00,1,'returned',1,1,NULL),
(26,57,11,'2026-05-03','2026-05-17','2026-06-22',180.00,0,'returned',1,2,NULL),
(27,44,54,'2025-06-07','2025-06-21','2025-06-25',20.00,0,'returned',2,2,NULL),
(28,27,79,'2026-03-29','2026-04-12','2026-04-07',0.00,0,'returned',2,2,NULL),
(29,6,38,'2026-03-25','2026-04-08','2026-05-18',200.00,0,'returned',1,2,NULL),
(30,2,36,'2025-08-19','2025-09-02','2025-08-29',0.00,0,'returned',1,2,NULL),
(31,4,108,'2025-02-23','2025-03-02','2025-03-16',70.00,1,'returned',2,2,NULL),
(32,31,21,'2026-02-25','2026-03-11','2026-04-17',185.00,1,'returned',1,1,NULL),
(33,8,110,'2026-05-21','2026-05-28','2026-05-28',0.00,0,'returned',2,2,NULL),
(34,39,54,'2026-03-28','2026-04-18','2026-04-16',0.00,0,'returned',1,2,NULL),
(35,45,82,'2025-12-08','2025-12-22','2025-12-20',0.00,0,'returned',1,1,NULL),
(36,11,142,'2025-08-17','2025-08-31','2025-08-26',0.00,0,'returned',1,2,NULL),
(37,51,22,'2026-02-02','2026-02-16','2026-02-16',0.00,0,'returned',2,1,NULL),
(38,28,109,'2026-01-12','2026-01-26','2026-02-16',105.00,0,'returned',2,2,NULL),
(39,49,55,'2026-04-28','2026-05-05','2026-05-16',55.00,0,'returned',2,2,NULL),
(40,5,127,'2026-03-19','2026-04-09','2026-04-04',0.00,0,'returned',2,2,NULL),
(41,51,30,'2025-08-10','2025-08-17','2025-08-12',0.00,0,'returned',1,2,NULL),
(42,27,145,'2025-10-18','2025-11-01','2025-10-28',0.00,0,'returned',2,1,NULL),
(43,9,21,'2025-08-21','2025-08-28','2025-08-28',0.00,0,'returned',2,2,NULL),
(44,51,112,'2026-01-08','2026-01-29','2026-01-28',0.00,0,'returned',2,2,NULL),
(45,8,9,'2026-01-10','2026-01-24','2026-03-03',190.00,1,'returned',1,2,NULL),
(46,33,43,'2026-01-07','2026-01-14','2026-01-11',0.00,0,'returned',1,1,NULL),
(47,40,70,'2026-01-03','2026-01-24','2026-01-27',15.00,0,'returned',2,1,NULL),
(48,23,63,'2026-04-17','2026-04-24','2026-04-21',0.00,0,'returned',1,1,NULL),
(49,2,102,'2025-01-14','2025-02-04','2025-01-31',0.00,0,'returned',2,2,NULL),
(50,61,52,'2025-08-13','2025-09-03','2025-09-03',0.00,0,'returned',2,1,NULL),
(51,23,75,'2026-01-30','2026-02-13','2026-03-28',215.00,1,'returned',1,2,NULL),
(52,5,94,'2025-05-01','2025-05-15','2025-06-29',225.00,1,'returned',2,1,NULL),
(53,38,141,'2026-02-26','2026-03-12','2026-03-09',0.00,0,'returned',1,1,NULL),
(54,42,55,'2026-02-08','2026-02-22','2026-02-18',0.00,0,'returned',2,2,NULL),
(55,10,150,'2026-04-16','2026-04-30','2026-05-07',35.00,1,'returned',1,2,NULL),
(56,58,87,'2025-11-09','2025-11-23','2025-11-23',0.00,0,'returned',1,2,NULL),
(57,3,48,'2025-09-12','2025-09-26','2025-09-26',0.00,0,'returned',2,1,NULL),
(58,35,43,'2025-07-23','2025-08-06','2025-08-19',65.00,0,'returned',2,2,NULL),
(59,31,39,'2026-02-01','2026-02-22','2026-02-18',0.00,0,'returned',1,1,NULL),
(60,58,7,'2025-12-27','2026-01-10','2026-01-05',0.00,0,'returned',1,2,NULL),
(61,5,21,'2026-01-08','2026-01-29','2026-01-27',0.00,0,'returned',1,1,NULL),
(62,57,132,'2025-04-18','2025-05-02','2025-05-01',0.00,0,'returned',2,1,NULL),
(63,28,10,'2026-03-25','2026-04-08','2026-05-20',210.00,1,'returned',2,1,NULL),
(64,8,40,'2025-07-09','2025-07-23','2025-08-23',155.00,1,'returned',2,1,NULL),
(65,60,4,'2026-03-28','2026-04-11','2026-04-11',0.00,0,'returned',2,1,NULL),
(66,53,32,'2026-04-26','2026-05-10','2026-05-09',0.00,0,'returned',2,1,NULL),
(67,6,136,'2025-11-09','2025-11-16','2025-11-15',0.00,0,'returned',1,1,NULL),
(68,18,1,'2026-02-11','2026-03-04','2026-03-04',0.00,0,'returned',1,2,NULL),
(69,4,71,'2025-12-16','2026-01-06','2026-01-04',0.00,0,'returned',2,1,NULL),
(70,41,148,'2026-03-16','2026-03-23','2026-03-18',0.00,0,'returned',2,1,NULL),
(71,50,90,'2025-08-14','2025-08-28','2025-08-25',0.00,0,'returned',2,1,NULL),
(72,57,99,'2025-02-07','2025-02-21','2025-02-17',0.00,0,'returned',1,2,NULL),
(73,2,27,'2025-08-03','2025-08-10','2025-08-07',0.00,0,'returned',2,2,NULL),
(74,14,110,'2026-04-05','2026-04-19','2026-04-23',20.00,1,'returned',2,2,NULL),
(75,7,48,'2025-05-26','2025-06-09','2025-07-04',125.00,1,'returned',2,1,NULL),
(76,33,68,'2025-04-24','2025-05-15','2025-05-10',0.00,0,'returned',2,1,NULL),
(77,30,150,'2026-04-08','2026-04-22','2026-04-17',0.00,0,'returned',2,2,NULL),
(78,20,83,'2026-01-16','2026-01-30','2026-01-25',0.00,0,'returned',2,2,NULL),
(79,17,148,'2025-03-29','2025-04-05','2025-05-01',130.00,0,'returned',2,1,NULL),
(80,65,19,'2025-11-04','2025-11-18','2025-11-13',0.00,0,'returned',1,2,NULL),
(81,27,143,'2026-05-30','2026-06-13','2026-07-07',120.00,1,'returned',2,2,NULL),
(82,52,78,'2025-12-07','2025-12-21','2025-12-18',0.00,0,'returned',1,1,NULL),
(83,2,23,'2025-12-12','2026-01-02','2025-12-30',0.00,0,'returned',2,1,NULL),
(84,74,40,'2025-05-02','2025-05-16','2025-05-12',0.00,0,'returned',1,2,NULL),
(85,9,103,'2024-12-21','2025-01-04','2025-01-09',25.00,1,'returned',2,2,NULL),
(86,58,103,'2025-04-21','2025-05-05','2025-06-07',165.00,0,'returned',1,1,NULL),
(87,70,116,'2026-03-21','2026-04-04','2026-04-03',0.00,0,'returned',2,2,NULL),
(88,55,73,'2025-11-03','2025-11-10','2025-11-08',0.00,0,'returned',2,2,NULL),
(89,53,122,'2026-05-11','2026-05-25','2026-05-23',0.00,0,'returned',2,2,NULL),
(90,7,123,'2025-11-29','2025-12-20','2025-12-16',0.00,0,'returned',2,1,NULL),
(91,57,70,'2026-02-28','2026-03-14','2026-03-14',0.00,0,'returned',1,2,NULL),
(92,64,70,'2026-03-06','2026-03-13','2026-03-13',0.00,0,'returned',2,1,NULL),
(93,40,87,'2026-05-04','2026-05-18','2026-05-17',0.00,0,'returned',1,1,NULL),
(94,43,103,'2025-11-06','2025-11-27','2025-11-22',0.00,0,'returned',1,1,NULL),
(95,64,114,'2026-03-12','2026-03-26','2026-04-22',135.00,1,'returned',1,2,NULL),
(96,59,73,'2025-10-20','2025-11-03','2025-11-03',0.00,0,'returned',2,2,NULL),
(97,31,100,'2026-04-15','2026-04-29','2026-04-25',0.00,0,'returned',2,1,NULL),
(98,21,103,'2025-09-04','2025-09-18','2025-09-27',45.00,0,'returned',2,1,NULL),
(99,22,62,'2026-03-12','2026-03-26','2026-03-21',0.00,0,'returned',2,2,NULL),
(100,58,55,'2025-03-09','2025-03-23','2025-04-29',185.00,1,'returned',2,1,NULL),
(101,52,68,'2025-12-13','2025-12-27','2026-01-28',160.00,1,'returned',1,1,NULL),
(102,64,70,'2025-03-04','2025-03-18','2025-03-13',0.00,0,'returned',1,2,NULL),
(103,32,132,'2025-10-14','2025-10-28','2025-10-23',0.00,0,'returned',1,2,NULL),
(104,7,36,'2026-02-07','2026-02-21','2026-02-19',0.00,0,'returned',1,1,NULL),
(105,27,40,'2026-01-30','2026-02-13','2026-03-03',90.00,1,'returned',1,1,NULL),
(106,68,53,'2025-07-31','2025-08-14','2025-08-11',0.00,0,'returned',1,1,NULL),
(107,39,53,'2026-05-26','2026-06-02','2026-05-30',0.00,0,'returned',2,2,NULL),
(108,8,133,'2026-04-20','2026-05-11','2026-05-09',0.00,0,'returned',2,2,NULL),
(109,33,70,'2025-12-23','2026-01-13','2026-01-08',0.00,0,'returned',2,2,NULL),
(110,45,148,'2025-11-15','2025-11-22','2025-11-19',0.00,0,'returned',1,1,NULL),
(111,37,22,'2025-10-26','2025-11-16','2025-12-11',125.00,1,'returned',1,1,NULL),
(112,2,143,'2026-04-29','2026-05-06','2026-05-04',0.00,0,'returned',1,2,NULL),
(113,47,54,'2025-08-12','2025-08-26','2025-08-30',20.00,1,'returned',1,1,NULL),
(114,36,150,'2025-12-28','2026-01-11','2026-01-07',0.00,0,'returned',2,2,NULL),
(115,35,98,'2025-06-12','2025-06-26','2025-06-22',0.00,0,'returned',1,2,NULL),
(116,36,31,'2025-02-22','2025-03-08','2025-03-22',70.00,0,'returned',2,2,NULL),
(117,32,75,'2025-04-13','2025-04-27','2025-04-26',0.00,0,'returned',2,2,NULL),
(118,57,144,'2025-07-25','2025-08-08','2025-08-08',0.00,0,'returned',1,2,NULL),
(119,61,94,'2025-08-28','2025-09-11','2025-09-10',0.00,0,'returned',2,2,NULL),
(120,8,87,'2025-11-14','2025-11-28','2025-11-27',0.00,0,'returned',1,1,NULL),
(121,3,54,'2025-09-13','2025-09-20','2025-09-29',45.00,1,'returned',1,1,NULL),
(122,29,140,'2025-06-04','2025-06-18','2025-07-07',95.00,1,'returned',2,2,NULL),
(123,42,136,'2026-05-06','2026-05-27','2026-05-27',0.00,0,'returned',1,1,NULL),
(124,29,125,'2025-04-14','2025-04-21','2025-05-17',130.00,1,'returned',2,1,NULL),
(125,63,145,'2025-04-22','2025-04-29','2025-04-28',0.00,0,'returned',1,2,NULL),
(126,17,149,'2025-12-02','2025-12-16','2025-12-25',45.00,0,'returned',2,2,NULL),
(127,10,14,'2026-04-13','2026-04-27','2026-04-27',0.00,0,'returned',1,1,NULL),
(128,50,116,'2025-11-22','2025-12-06','2025-12-06',0.00,0,'returned',2,2,NULL),
(129,33,10,'2025-10-07','2025-10-21','2025-11-21',155.00,0,'returned',2,1,NULL),
(130,1,51,'2026-01-08','2026-01-22','2026-02-11',100.00,1,'returned',1,2,NULL),
(131,43,100,'2026-05-16','2026-05-23','2026-05-19',0.00,0,'returned',2,2,NULL),
(132,47,92,'2025-04-06','2025-04-20','2025-04-16',0.00,0,'returned',1,2,NULL),
(133,8,109,'2025-11-05','2025-11-19','2025-12-20',155.00,1,'returned',1,1,NULL),
(134,46,82,'2025-08-05','2025-08-26','2025-08-26',0.00,0,'returned',2,1,NULL),
(135,61,14,'2025-07-10','2025-07-31','2025-07-30',0.00,0,'returned',1,1,NULL),
(136,23,71,'2026-04-27','2026-05-11','2026-06-12',160.00,0,'returned',1,2,NULL),
(137,56,59,'2025-12-14','2025-12-28','2025-12-27',0.00,0,'returned',2,2,NULL),
(138,50,53,'2025-07-18','2025-08-01','2025-07-27',0.00,0,'returned',2,2,NULL),
(139,49,73,'2026-05-17','2026-05-24','2026-06-24',155.00,0,'returned',1,2,NULL),
(140,29,114,'2025-08-18','2025-09-01','2025-08-30',0.00,0,'returned',2,2,NULL),
(141,28,99,'2025-10-11','2025-11-01','2025-10-29',0.00,0,'returned',1,1,NULL),
(142,72,52,'2026-04-24','2026-05-08','2026-05-10',10.00,1,'returned',2,2,NULL),
(143,45,73,'2025-12-06','2025-12-20','2025-12-17',0.00,0,'returned',1,2,NULL),
(144,10,131,'2025-08-18','2025-08-25','2025-09-21',135.00,1,'returned',1,1,NULL),
(145,11,11,'2026-05-29','2026-06-19','2026-06-23',20.00,1,'returned',1,1,NULL),
(146,29,31,'2026-03-28','2026-04-04','2026-04-01',0.00,0,'returned',1,2,NULL),
(147,36,114,'2025-07-17','2025-07-31','2025-07-27',0.00,0,'returned',1,2,NULL),
(148,20,8,'2025-03-28','2025-04-11','2025-04-09',0.00,0,'returned',2,1,NULL),
(149,68,141,'2025-10-06','2025-10-27','2025-10-25',0.00,0,'returned',2,1,NULL),
(150,20,23,'2025-12-04','2025-12-18','2026-01-07',100.00,1,'returned',1,2,NULL),
(151,61,76,'2025-03-02','2025-03-23','2025-03-21',0.00,0,'returned',1,2,NULL),
(152,11,93,'2025-04-26','2025-05-10','2025-05-10',0.00,0,'returned',1,1,NULL),
(153,16,97,'2025-11-07','2025-11-14','2025-11-13',0.00,0,'returned',1,2,NULL),
(154,11,136,'2026-02-28','2026-03-07','2026-03-03',0.00,0,'returned',1,2,NULL),
(155,61,100,'2025-09-20','2025-10-04','2025-11-09',180.00,1,'returned',2,2,NULL),
(156,28,72,'2026-02-09','2026-02-23','2026-02-21',0.00,0,'returned',2,1,NULL),
(157,55,104,'2025-08-20','2025-09-03','2025-09-27',120.00,0,'returned',2,2,NULL),
(158,3,129,'2025-08-31','2025-09-07','2025-09-06',0.00,0,'returned',2,2,NULL),
(159,8,45,'2026-02-02','2026-02-16','2026-02-16',0.00,0,'returned',2,2,NULL),
(160,52,66,'2025-09-10','2025-09-24','2025-09-24',0.00,0,'returned',2,1,NULL),
(161,8,73,'2026-04-07','2026-04-28','2026-05-02',20.00,1,'returned',1,1,NULL),
(162,64,95,'2025-08-18','2025-09-01','2025-09-01',0.00,0,'returned',1,1,NULL),
(163,49,2,'2025-12-17','2025-12-31','2025-12-31',0.00,0,'returned',2,2,NULL),
(164,1,72,'2026-01-21','2026-01-28','2026-01-25',0.00,0,'returned',2,1,NULL),
(165,33,100,'2026-01-14','2026-01-28','2026-01-23',0.00,0,'returned',1,1,NULL),
(166,10,71,'2025-07-19','2025-08-02','2025-08-08',30.00,0,'returned',2,2,NULL),
(167,31,32,'2025-09-23','2025-10-07','2025-10-13',30.00,0,'returned',1,1,NULL),
(168,29,50,'2025-12-28','2026-01-04','2026-01-10',30.00,0,'returned',2,2,NULL),
(169,42,46,'2025-02-14','2025-02-21','2025-02-24',15.00,0,'returned',1,1,NULL),
(170,60,100,'2025-11-22','2025-12-06','2025-12-01',0.00,0,'returned',2,1,NULL),
(171,9,127,'2026-06-10','2026-06-24','2026-06-24',0.00,0,'returned',2,1,NULL),
(172,20,76,'2025-11-22','2025-12-06','2026-01-10',175.00,1,'returned',2,2,NULL),
(173,51,19,'2025-01-21','2025-01-28','2025-01-25',0.00,0,'returned',1,1,NULL),
(174,30,125,'2026-02-15','2026-03-08','2026-04-03',130.00,1,'returned',2,1,NULL),
(175,41,116,'2026-01-07','2026-01-21','2026-01-19',0.00,0,'returned',2,1,NULL),
(176,45,94,'2026-05-07','2026-05-28','2026-05-24',0.00,0,'returned',1,1,NULL),
(177,16,50,'2025-08-07','2025-08-21','2025-09-11',105.00,0,'returned',2,1,NULL),
(178,5,142,'2026-01-09','2026-01-23','2026-01-18',0.00,0,'returned',1,2,NULL),
(179,31,74,'2026-01-23','2026-01-30','2026-01-29',0.00,0,'returned',1,2,NULL),
(180,58,3,'2026-01-21','2026-01-28','2026-03-05',180.00,1,'returned',1,1,NULL),
(181,46,22,'2026-03-11','2026-03-25','2026-03-20',0.00,0,'returned',1,2,NULL),
(182,17,41,'2025-08-08','2025-08-22','2025-08-18',0.00,0,'returned',2,1,NULL),
(183,31,19,'2026-06-19','2026-07-03','2026-07-02',0.00,0,'returned',2,2,NULL),
(184,31,56,'2025-07-13','2025-08-03','2025-07-31',0.00,0,'returned',1,2,NULL),
(185,22,146,'2025-02-28','2025-03-14','2025-04-24',205.00,1,'returned',2,1,NULL),
(186,23,39,'2025-08-06','2025-08-20','2025-08-19',0.00,0,'returned',1,1,NULL),
(187,46,73,'2025-03-23','2025-04-06','2025-04-20',70.00,0,'returned',2,2,NULL),
(188,57,9,'2025-06-27','2025-07-11','2025-07-20',45.00,0,'returned',2,1,NULL),
(189,14,21,'2026-01-17','2026-01-31','2026-01-30',0.00,0,'returned',2,2,NULL),
(190,35,137,'2025-06-10','2025-06-24','2025-06-21',0.00,0,'returned',1,1,NULL),
(191,53,94,'2026-02-10','2026-03-03','2026-03-03',0.00,0,'returned',2,2,NULL),
(192,67,56,'2026-06-15','2026-06-29','2026-06-29',0.00,0,'returned',1,2,NULL),
(193,27,62,'2025-10-02','2025-10-23','2025-10-18',0.00,0,'returned',2,1,NULL),
(194,19,137,'2026-05-07','2026-05-21','2026-05-18',0.00,0,'returned',2,1,NULL),
(195,34,47,'2026-05-03','2026-05-17','2026-05-14',0.00,0,'returned',1,1,NULL),
(196,2,46,'2026-04-29','2026-05-13','2026-05-29',80.00,0,'returned',1,1,NULL),
(197,23,56,'2026-01-03','2026-01-17','2026-01-13',0.00,0,'returned',2,2,NULL),
(198,2,87,'2026-04-03','2026-04-24','2026-04-19',0.00,0,'returned',1,1,NULL),
(199,17,101,'2025-07-31','2025-08-21','2025-08-20',0.00,0,'returned',1,2,NULL),
(200,23,61,'2026-03-13','2026-03-27','2026-03-27',0.00,0,'returned',2,2,NULL),
(201,40,82,'2026-02-13','2026-02-27','2026-02-27',0.00,0,'returned',2,1,NULL),
(202,45,44,'2026-03-21','2026-03-28','2026-03-28',0.00,0,'returned',1,2,NULL),
(203,29,19,'2026-01-31','2026-02-14','2026-02-13',0.00,0,'returned',1,1,NULL),
(204,32,19,'2026-02-24','2026-03-10','2026-03-07',0.00,0,'returned',1,2,NULL),
(205,8,120,'2025-03-08','2025-03-29','2025-04-25',135.00,1,'returned',2,2,NULL),
(206,49,57,'2026-04-12','2026-05-03','2026-04-29',0.00,0,'returned',2,1,NULL),
(207,17,73,'2026-04-12','2026-04-26','2026-04-24',0.00,0,'returned',1,1,NULL),
(208,16,73,'2025-01-14','2025-02-04','2025-02-07',15.00,0,'returned',2,1,NULL),
(209,71,12,'2025-07-09','2025-07-23','2025-07-18',0.00,0,'returned',2,2,NULL),
(210,26,120,'2026-01-11','2026-01-18','2026-02-03',80.00,1,'returned',1,2,NULL),
(211,58,86,'2026-01-15','2026-02-05','2026-02-01',0.00,0,'returned',1,1,NULL),
(212,36,72,'2025-11-09','2025-11-23','2025-11-23',0.00,0,'returned',2,2,NULL),
(213,36,144,'2025-12-13','2025-12-20','2025-12-18',0.00,0,'returned',1,2,NULL),
(214,58,17,'2025-06-13','2025-06-27','2025-06-24',0.00,0,'returned',1,2,NULL),
(215,32,79,'2026-03-11','2026-03-25','2026-03-20',0.00,0,'returned',1,2,NULL),
(216,33,38,'2025-04-11','2025-04-25','2025-04-23',0.00,0,'returned',2,1,NULL),
(217,58,127,'2026-05-04','2026-05-18','2026-05-18',0.00,0,'returned',2,1,NULL),
(218,54,53,'2025-03-01','2025-03-15','2025-03-12',0.00,0,'returned',2,2,NULL),
(219,35,18,'2025-06-23','2025-07-07','2025-07-11',20.00,0,'returned',1,1,NULL),
(220,41,125,'2026-06-10','2026-06-24','2026-06-19',0.00,0,'returned',2,1,NULL),
(221,74,136,'2025-06-01','2025-06-15','2025-06-12',0.00,0,'returned',1,2,NULL),
(222,14,49,'2025-05-13','2025-05-27','2025-05-27',0.00,0,'returned',2,1,NULL),
(223,30,10,'2026-05-04','2026-05-18','2026-05-14',0.00,0,'returned',1,2,NULL),
(224,1,100,'2025-07-17','2025-07-31','2025-08-31',155.00,1,'returned',1,1,NULL),
(225,28,106,'2026-05-01','2026-05-15','2026-05-12',0.00,0,'returned',1,2,NULL),
(226,53,110,'2026-04-22','2026-05-06','2026-05-05',0.00,0,'returned',1,1,NULL),
(227,31,104,'2025-10-26','2025-11-09','2025-12-19',200.00,0,'returned',2,1,NULL),
(228,5,11,'2025-08-25','2025-09-15','2025-10-08',115.00,0,'returned',2,2,NULL),
(229,54,33,'2025-10-19','2025-11-02','2025-11-01',0.00,0,'returned',2,1,NULL),
(230,57,94,'2026-02-28','2026-03-21','2026-03-17',0.00,0,'returned',2,2,NULL),
(231,42,116,'2025-08-01','2025-08-15','2025-08-10',0.00,0,'returned',1,2,NULL),
(232,42,9,'2025-05-26','2025-06-02','2025-06-23',105.00,1,'returned',1,2,NULL),
(233,58,77,'2026-02-07','2026-02-21','2026-02-26',25.00,1,'returned',1,1,NULL),
(234,1,29,'2025-04-26','2025-05-10','2025-05-10',0.00,0,'returned',2,2,NULL),
(235,49,10,'2025-12-05','2025-12-26','2025-12-21',0.00,0,'returned',2,1,NULL),
(236,33,27,'2025-07-23','2025-08-13','2025-08-12',0.00,0,'returned',1,2,NULL),
(237,49,106,'2025-06-28','2025-07-05','2025-07-03',0.00,0,'returned',1,2,NULL),
(238,40,8,'2025-10-09','2025-10-23','2025-10-23',0.00,0,'returned',1,1,NULL),
(239,9,144,'2025-12-10','2025-12-24','2025-12-20',0.00,0,'returned',2,1,NULL),
(240,53,5,'2025-07-24','2025-08-07','2025-08-04',0.00,0,'returned',1,2,NULL),
(241,31,48,'2025-12-19','2026-01-09','2026-01-05',0.00,0,'returned',2,1,NULL),
(242,60,97,'2026-04-27','2026-05-18','2026-05-13',0.00,0,'returned',1,1,NULL),
(243,32,51,'2026-04-17','2026-04-24','2026-04-24',0.00,0,'returned',2,1,NULL),
(244,23,54,'2025-09-11','2025-09-25','2025-11-01',185.00,1,'returned',2,1,NULL),
(245,33,135,'2026-04-08','2026-04-29','2026-05-25',130.00,1,'returned',1,2,NULL),
(246,58,114,'2026-02-25','2026-03-04','2026-02-27',0.00,0,'returned',2,1,NULL),
(247,19,116,'2025-09-01','2025-09-15','2025-09-14',0.00,0,'returned',2,1,NULL),
(248,50,73,'2025-07-31','2025-08-14','2025-08-12',0.00,0,'returned',1,1,NULL),
(249,35,91,'2025-09-25','2025-10-02','2025-10-03',5.00,0,'returned',2,2,NULL),
(250,6,72,'2026-03-21','2026-04-04','2026-04-14',50.00,1,'returned',2,1,NULL),
(251,3,31,'2025-06-28','2025-07-12','2025-08-05',120.00,1,'returned',2,1,NULL),
(252,37,70,'2025-10-22','2025-11-05','2025-11-04',0.00,0,'returned',1,2,NULL),
(253,44,18,'2026-03-04','2026-03-18','2026-04-13',130.00,1,'returned',2,2,NULL),
(254,31,31,'2025-04-03','2025-04-17','2025-05-25',190.00,1,'returned',1,1,NULL),
(255,6,59,'2026-02-24','2026-03-03','2026-02-27',0.00,0,'returned',2,2,NULL),
(256,31,127,'2026-05-05','2026-05-19','2026-07-03',225.00,0,'returned',1,1,NULL),
(257,57,45,'2026-05-05','2026-05-19','2026-06-14',130.00,0,'returned',1,2,NULL),
(258,15,149,'2026-05-31','2026-06-14','2026-07-20',180.00,0,'returned',1,1,NULL),
(259,31,118,'2026-04-20','2026-04-27','2026-04-23',0.00,0,'returned',1,1,NULL),
(260,57,49,'2025-10-25','2025-11-01','2025-10-29',0.00,0,'returned',1,1,NULL),
(261,74,26,'2025-10-18','2025-11-01','2025-10-29',0.00,0,'returned',1,1,NULL),
(262,63,7,'2025-04-24','2025-05-08','2025-06-03',130.00,1,'returned',2,1,NULL),
(263,28,56,'2026-02-11','2026-02-25','2026-02-23',0.00,0,'returned',1,1,NULL),
(264,40,87,'2025-10-17','2025-10-31','2025-10-30',0.00,0,'returned',2,1,NULL),
(265,5,51,'2026-01-19','2026-02-09','2026-02-08',0.00,0,'returned',1,2,NULL),
(266,53,48,'2025-12-01','2025-12-15','2025-12-14',0.00,0,'returned',2,2,NULL),
(267,16,4,'2025-11-09','2025-11-16','2025-12-04',90.00,0,'returned',1,2,NULL),
(268,35,113,'2024-12-03','2024-12-17','2024-12-17',0.00,0,'returned',1,2,NULL),
(269,35,116,'2025-09-03','2025-09-17','2025-09-15',0.00,0,'returned',2,1,NULL),
(270,9,82,'2025-07-24','2025-08-07','2025-08-09',10.00,1,'returned',2,1,NULL),
(271,36,24,'2025-01-22','2025-02-05','2025-02-01',0.00,0,'returned',2,1,NULL),
(272,5,31,'2026-03-27','2026-04-17','2026-04-14',0.00,0,'returned',1,1,NULL),
(273,24,22,'2025-07-27','2025-08-10','2025-08-06',0.00,0,'returned',1,1,NULL),
(274,57,129,'2025-03-13','2025-03-27','2025-05-09',215.00,1,'returned',2,1,NULL),
(275,24,44,'2025-02-17','2025-03-03','2025-04-04',160.00,1,'returned',2,1,NULL),
(276,49,76,'2025-05-26','2025-06-16','2025-07-01',75.00,0,'returned',1,2,NULL),
(277,20,100,'2026-04-24','2026-05-01','2026-06-07',185.00,0,'returned',2,1,NULL),
(278,9,44,'2025-07-23','2025-08-13','2025-08-12',0.00,0,'returned',1,2,NULL),
(279,8,109,'2026-03-21','2026-04-04','2026-03-30',0.00,0,'returned',2,2,NULL),
(280,1,28,'2025-09-25','2025-10-09','2025-10-04',0.00,0,'returned',1,1,NULL),
(281,28,106,'2025-02-28','2025-03-14','2025-03-12',0.00,0,'returned',2,2,NULL),
(282,6,64,'2025-06-15','2025-06-29','2025-06-24',0.00,0,'returned',1,2,NULL),
(283,2,36,'2026-05-01','2026-05-15','2026-05-13',0.00,0,'returned',1,1,NULL),
(284,35,135,'2026-05-04','2026-05-25','2026-06-25',155.00,1,'returned',1,2,NULL),
(285,63,21,'2025-05-25','2025-06-08','2025-06-05',0.00,0,'returned',1,1,NULL),
(286,29,74,'2025-04-23','2025-05-14','2025-05-11',0.00,0,'returned',2,1,NULL),
(287,5,52,'2025-11-29','2025-12-13','2025-12-10',0.00,0,'returned',1,2,NULL),
(288,5,122,'2025-10-28','2025-11-11','2025-11-06',0.00,0,'returned',1,1,NULL),
(289,42,148,'2025-12-29','2026-01-05','2026-01-03',0.00,0,'returned',2,2,NULL),
(290,60,36,'2025-10-20','2025-11-03','2025-11-01',0.00,0,'returned',2,1,NULL),
(291,31,36,'2026-01-02','2026-01-16','2026-02-22',185.00,1,'returned',1,1,NULL),
(292,51,95,'2026-05-07','2026-05-21','2026-06-17',135.00,1,'returned',1,1,NULL),
(293,57,120,'2026-01-19','2026-02-09','2026-03-12',155.00,1,'returned',1,2,NULL),
(294,20,53,'2025-06-22','2025-06-29','2025-06-28',0.00,0,'returned',1,1,NULL),
(295,64,59,'2025-03-28','2025-04-11','2025-04-24',65.00,1,'returned',1,1,NULL),
(296,30,149,'2026-01-13','2026-01-27','2026-02-13',85.00,0,'returned',2,1,NULL),
(297,5,75,'2025-11-28','2025-12-12','2025-12-07',0.00,0,'returned',2,1,NULL),
(298,29,20,'2025-11-13','2025-11-20','2025-12-27',185.00,0,'returned',1,2,NULL),
(299,58,132,'2025-06-04','2025-06-18','2025-06-16',0.00,0,'returned',2,1,NULL),
(300,9,54,'2025-10-31','2025-11-14','2025-11-11',0.00,0,'returned',1,1,NULL),
(301,51,137,'2025-05-19','2025-05-26','2025-05-23',0.00,0,'returned',2,2,NULL),
(302,57,128,'2025-09-29','2025-10-13','2025-10-13',0.00,0,'returned',2,2,NULL),
(303,16,54,'2025-10-18','2025-11-01','2025-10-30',0.00,0,'returned',2,2,NULL),
(304,57,70,'2026-04-14','2026-04-28','2026-05-24',130.00,1,'returned',1,1,NULL),
(305,9,131,'2026-04-02','2026-04-09','2026-04-07',0.00,0,'returned',1,2,NULL),
(306,49,37,'2025-07-13','2025-08-03','2025-07-29',0.00,0,'returned',1,1,NULL),
(307,27,82,'2026-04-09','2026-04-23','2026-04-20',0.00,0,'returned',2,1,NULL),
(308,57,36,'2025-07-08','2025-07-15','2025-07-13',0.00,0,'returned',1,1,NULL),
(309,58,115,'2026-03-28','2026-04-11','2026-04-11',0.00,0,'returned',1,2,NULL),
(310,42,70,'2025-06-14','2025-06-21','2025-06-17',0.00,0,'returned',1,1,NULL),
(311,12,85,'2025-04-04','2025-04-18','2025-04-16',0.00,0,'returned',2,2,NULL),
(312,14,62,'2025-10-03','2025-10-24','2025-10-19',0.00,0,'returned',1,2,NULL),
(313,36,82,'2026-03-07','2026-03-14','2026-03-11',0.00,0,'returned',2,2,NULL),
(314,58,36,'2025-09-16','2025-09-30','2025-09-29',0.00,0,'returned',1,1,NULL),
(315,55,118,'2025-11-08','2025-11-22','2025-11-24',10.00,1,'returned',2,2,NULL),
(316,15,55,'2026-01-30','2026-02-06','2026-02-05',0.00,0,'returned',1,2,NULL),
(317,50,31,'2025-12-05','2025-12-19','2026-01-31',215.00,0,'returned',2,2,NULL),
(318,57,125,'2025-06-05','2025-06-19','2025-06-17',0.00,0,'returned',1,2,NULL),
(319,50,75,'2025-05-05','2025-05-19','2025-06-03',75.00,0,'returned',2,1,NULL),
(320,50,42,'2025-08-04','2025-08-18','2025-08-17',0.00,0,'returned',2,2,NULL),
(321,58,63,'2025-06-13','2025-07-04','2025-07-03',0.00,0,'returned',1,2,NULL),
(322,59,68,'2025-06-12','2025-06-26','2025-06-24',0.00,0,'returned',1,1,NULL),
(323,8,26,'2026-01-22','2026-02-12','2026-03-14',150.00,1,'returned',1,2,NULL),
(324,58,23,'2026-05-09','2026-05-23','2026-05-19',0.00,0,'returned',2,1,NULL),
(325,1,37,'2025-08-20','2025-09-03','2025-08-30',0.00,0,'returned',2,1,NULL),
(326,7,56,'2026-01-15','2026-01-29','2026-02-23',125.00,0,'returned',1,1,NULL),
(327,35,106,'2025-03-26','2025-04-09','2025-05-13',170.00,0,'returned',1,1,NULL),
(328,45,90,'2026-03-18','2026-04-01','2026-03-27',0.00,0,'returned',2,2,NULL),
(329,9,122,'2026-03-02','2026-03-16','2026-03-15',0.00,0,'returned',2,2,NULL),
(330,59,150,'2026-02-15','2026-03-01','2026-02-25',0.00,0,'returned',1,2,NULL),
(331,1,31,'2025-01-30','2025-02-13','2025-03-23',190.00,1,'returned',1,1,NULL),
(332,27,93,'2026-05-27','2026-06-10','2026-07-20',200.00,1,'returned',1,1,NULL),
(333,43,94,'2026-06-07','2026-06-14','2026-06-12',0.00,0,'returned',1,2,NULL),
(334,32,21,'2025-09-24','2025-10-01','2025-10-01',0.00,0,'returned',1,2,NULL),
(335,40,101,'2026-01-19','2026-01-26','2026-01-25',0.00,0,'returned',1,2,NULL),
(336,6,13,'2026-04-02','2026-04-16','2026-05-20',170.00,0,'returned',1,2,NULL),
(337,49,41,'2026-05-26','2026-06-09','2026-07-24',225.00,0,'returned',2,2,NULL),
(338,12,3,'2026-05-06','2026-05-13','2026-06-25',215.00,0,'returned',2,1,NULL),
(339,64,115,'2026-05-11','2026-05-18','2026-06-29',210.00,0,'returned',1,2,NULL),
(340,71,41,'2026-01-02','2026-01-09','2026-01-12',15.00,1,'returned',2,2,NULL),
(341,55,44,'2025-09-02','2025-09-09','2025-09-12',15.00,1,'returned',1,1,NULL),
(342,44,22,'2026-02-09','2026-02-23','2026-03-13',90.00,1,'returned',1,2,NULL),
(343,56,23,'2026-01-25','2026-02-08','2026-02-06',0.00,0,'returned',2,2,NULL),
(344,42,117,'2026-04-28','2026-05-05','2026-05-16',55.00,1,'returned',1,2,NULL),
(345,60,65,'2025-11-21','2025-12-05','2025-12-03',0.00,0,'returned',2,1,NULL),
(346,58,132,'2025-09-08','2025-09-22','2025-09-20',0.00,0,'returned',1,2,NULL),
(347,31,9,'2025-10-14','2025-10-21','2025-12-04',220.00,0,'returned',1,2,NULL),
(348,34,100,'2025-10-31','2025-11-14','2025-11-30',80.00,0,'returned',2,2,NULL),
(349,44,92,'2026-04-18','2026-05-09','2026-06-18',200.00,0,'returned',1,1,NULL),
(350,42,21,'2025-06-26','2025-07-10','2025-07-15',25.00,1,'returned',2,2,NULL),
(351,13,148,'2026-05-21','2026-06-04','2026-06-02',0.00,0,'returned',2,1,NULL),
(352,5,57,'2025-11-19','2025-11-26','2025-12-25',145.00,1,'returned',2,1,NULL),
(353,69,109,'2026-06-08','2026-06-22','2026-06-21',0.00,0,'returned',1,1,NULL),
(354,54,145,'2025-10-22','2025-11-12','2025-11-12',0.00,0,'returned',2,2,NULL),
(355,27,8,'2026-03-26','2026-04-09','2026-04-08',0.00,0,'returned',2,2,NULL),
(356,49,14,'2025-08-21','2025-09-04','2025-09-01',0.00,0,'returned',2,2,NULL),
(357,49,6,'2026-04-13','2026-04-27','2026-05-24',135.00,0,'returned',1,2,NULL),
(358,40,24,'2025-04-18','2025-05-02','2025-04-28',0.00,0,'returned',2,1,NULL),
(359,52,6,'2025-10-24','2025-11-14','2025-11-12',0.00,0,'returned',2,1,NULL),
(360,67,2,'2025-09-03','2025-09-24','2025-11-01',190.00,1,'returned',2,1,NULL),
(361,48,22,'2025-07-19','2025-07-26','2025-07-25',0.00,0,'returned',2,2,NULL),
(362,29,85,'2025-09-26','2025-10-10','2025-10-07',0.00,0,'returned',2,2,NULL),
(363,55,19,'2025-11-07','2025-11-28','2025-11-28',0.00,0,'returned',2,1,NULL),
(364,11,89,'2026-03-04','2026-03-18','2026-03-27',45.00,1,'returned',1,2,NULL),
(365,49,112,'2025-11-24','2025-12-15','2025-12-15',0.00,0,'returned',2,2,NULL),
(366,58,55,'2026-06-13','2026-06-20','2026-06-16',0.00,0,'returned',1,1,NULL),
(367,10,110,'2026-04-14','2026-04-28','2026-05-08',50.00,0,'returned',1,2,NULL),
(368,11,73,'2026-02-09','2026-02-23','2026-02-23',0.00,0,'returned',1,2,NULL),
(369,12,116,'2025-07-29','2025-08-12','2025-08-16',20.00,0,'returned',2,2,NULL),
(370,29,116,'2025-09-29','2025-10-20','2025-10-20',0.00,0,'returned',2,1,NULL),
(371,40,116,'2025-06-10','2025-06-24','2025-08-05',210.00,1,'returned',2,1,NULL),
(372,53,146,'2026-03-03','2026-03-17','2026-03-22',25.00,1,'returned',1,1,NULL),
(373,50,16,'2026-05-26','2026-06-09','2026-06-05',0.00,0,'returned',1,2,NULL),
(374,1,62,'2025-04-10','2025-04-17','2025-04-14',0.00,0,'returned',1,2,NULL),
(375,32,77,'2026-02-09','2026-02-23','2026-02-19',0.00,0,'returned',1,1,NULL),
(376,29,72,'2026-05-05','2026-05-19','2026-07-01',215.00,0,'returned',2,2,NULL),
(377,27,30,'2025-08-25','2025-09-15','2025-09-14',0.00,0,'returned',1,1,NULL),
(378,44,58,'2025-05-13','2025-06-03','2025-06-19',80.00,0,'returned',1,2,NULL),
(379,28,117,'2026-04-28','2026-05-12','2026-05-09',0.00,0,'returned',1,2,NULL),
(380,33,70,'2025-12-24','2026-01-07','2026-01-20',65.00,1,'returned',2,1,NULL),
(381,64,22,'2025-03-18','2025-04-08','2025-04-08',0.00,0,'returned',1,1,NULL),
(382,45,114,'2025-06-14','2025-06-28','2025-07-12',70.00,1,'returned',2,1,NULL),
(383,51,21,'2026-01-04','2026-01-18','2026-01-13',0.00,0,'returned',1,1,NULL),
(384,54,75,'2025-11-19','2025-12-03','2025-12-30',135.00,1,'returned',2,2,NULL),
(385,41,56,'2026-06-09','2026-06-16','2026-06-16',0.00,0,'returned',1,1,NULL),
(386,49,9,'2025-04-20','2025-04-27','2025-04-27',0.00,0,'returned',2,1,NULL),
(387,17,138,'2026-02-01','2026-02-08','2026-02-07',0.00,0,'returned',1,1,NULL),
(388,51,117,'2025-06-25','2025-07-09','2025-07-19',50.00,0,'returned',2,2,NULL),
(389,66,2,'2025-06-07','2025-06-21','2025-06-16',0.00,0,'returned',2,1,NULL),
(390,20,110,'2025-05-14','2025-05-28','2025-05-28',0.00,0,'returned',1,1,NULL),
(391,10,87,'2026-03-16','2026-03-23','2026-03-22',0.00,0,'returned',1,2,NULL),
(392,42,9,'2025-10-06','2025-10-20','2025-10-20',0.00,0,'returned',2,2,NULL),
(393,27,96,'2026-03-22','2026-04-05','2026-04-01',0.00,0,'returned',2,2,NULL),
(394,31,87,'2026-02-27','2026-03-20','2026-03-19',0.00,0,'returned',2,2,NULL),
(395,66,22,'2026-02-25','2026-03-11','2026-04-22',210.00,1,'returned',2,2,NULL),
(396,57,19,'2025-09-05','2025-09-19','2025-09-16',0.00,0,'returned',2,2,NULL),
(397,35,22,'2025-11-05','2025-11-19','2025-11-28',45.00,0,'returned',1,2,NULL),
(398,50,90,'2025-09-08','2025-09-15','2025-10-26',205.00,0,'returned',1,2,NULL),
(399,53,28,'2026-05-28','2026-06-11','2026-06-10',0.00,0,'returned',2,1,NULL),
(400,27,31,'2025-08-14','2025-08-28','2025-08-27',0.00,0,'returned',1,2,NULL),
(401,27,2,'2026-03-21','2026-04-11','2026-05-14',165.00,1,'returned',1,2,NULL),
(402,8,77,'2025-11-22','2025-12-06','2026-01-06',155.00,1,'returned',2,1,NULL),
(403,12,66,'2026-05-16','2026-05-30','2026-05-30',0.00,0,'returned',1,2,NULL),
(404,28,136,'2025-06-01','2025-06-08','2025-06-29',105.00,1,'returned',1,2,NULL),
(405,57,36,'2025-12-01','2025-12-15','2025-12-13',0.00,0,'returned',2,1,NULL),
(406,33,50,'2025-05-10','2025-05-31','2025-05-28',0.00,0,'returned',2,2,NULL),
(407,59,2,'2025-06-01','2025-06-15','2025-06-10',0.00,0,'returned',2,1,NULL),
(408,8,21,'2025-11-07','2025-11-14','2025-12-11',135.00,0,'returned',2,1,NULL),
(409,32,64,'2026-03-30','2026-04-13','2026-04-11',0.00,0,'returned',1,1,NULL),
(410,3,77,'2026-04-14','2026-05-05','2026-05-04',0.00,0,'returned',1,1,NULL),
(411,9,137,'2025-12-13','2025-12-27','2025-12-26',0.00,0,'returned',1,2,NULL),
(412,64,30,'2025-11-05','2025-11-19','2025-11-30',55.00,1,'returned',1,2,NULL),
(413,38,116,'2025-07-15','2025-07-29','2025-07-28',0.00,0,'returned',2,1,NULL),
(414,50,46,'2026-01-06','2026-01-27','2026-01-25',0.00,0,'returned',2,1,NULL),
(415,6,27,'2025-06-18','2025-07-09','2025-07-19',50.00,1,'returned',1,1,NULL),
(416,32,87,'2026-05-26','2026-06-16','2026-06-11',0.00,0,'returned',1,2,NULL),
(417,43,135,'2025-12-03','2025-12-10','2026-01-23',220.00,0,'returned',2,2,NULL),
(418,27,6,'2025-12-07','2025-12-21','2026-01-21',155.00,0,'returned',2,2,NULL),
(419,37,108,'2025-08-20','2025-09-10','2025-09-06',0.00,0,'returned',2,2,NULL),
(420,53,136,'2026-05-08','2026-05-29','2026-06-25',135.00,1,'returned',2,1,NULL),
(421,1,109,'2026-06-18','2026-07-09','2026-07-04',0.00,0,'returned',2,1,NULL),
(422,47,44,'2026-02-08','2026-02-22','2026-02-21',0.00,0,'returned',2,2,NULL),
(423,58,56,'2026-02-07','2026-02-21','2026-03-19',130.00,1,'returned',1,2,NULL),
(424,35,75,'2026-04-08','2026-04-29','2026-04-26',0.00,0,'returned',2,2,NULL),
(425,53,53,'2026-04-21','2026-04-28','2026-05-27',145.00,1,'returned',1,1,NULL),
(426,12,53,'2026-02-16','2026-03-09','2026-03-09',0.00,0,'returned',1,1,NULL),
(427,28,91,'2025-07-25','2025-08-08','2025-08-07',0.00,0,'returned',2,1,NULL),
(428,4,30,'2026-05-09','2026-05-16','2026-06-11',130.00,0,'returned',2,1,NULL),
(429,64,121,'2025-10-21','2025-11-04','2025-11-04',0.00,0,'returned',2,1,NULL),
(430,2,82,'2025-12-13','2025-12-27','2025-12-27',0.00,0,'returned',1,2,NULL),
(431,12,1,'2026-04-15','2026-04-29','2026-05-22',115.00,1,'returned',2,2,NULL),
(432,37,70,'2025-09-03','2025-09-10','2025-10-16',180.00,1,'returned',2,2,NULL),
(433,26,120,'2026-03-25','2026-04-08','2026-04-06',0.00,0,'returned',1,2,NULL),
(434,9,70,'2025-11-25','2025-12-16','2025-12-11',0.00,0,'returned',2,2,NULL),
(435,48,146,'2025-11-24','2025-12-08','2026-01-07',150.00,1,'returned',2,1,NULL),
(436,32,35,'2026-02-01','2026-02-15','2026-03-02',75.00,0,'returned',2,2,NULL),
(437,65,70,'2026-06-15','2026-06-29','2026-06-24',0.00,0,'returned',2,2,NULL),
(438,5,140,'2025-12-28','2026-01-11','2026-01-10',0.00,0,'returned',2,1,NULL),
(439,64,99,'2025-05-08','2025-05-22','2025-06-07',80.00,0,'returned',1,2,NULL),
(440,11,27,'2026-03-17','2026-04-07','2026-04-02',0.00,0,'returned',1,1,NULL),
(441,45,94,'2025-11-02','2025-11-23','2025-12-24',155.00,1,'returned',2,2,NULL),
(442,32,149,'2025-05-19','2025-06-02','2025-06-01',0.00,0,'returned',2,2,NULL),
(443,12,79,'2026-05-19','2026-06-02','2026-06-01',0.00,0,'returned',1,2,NULL),
(444,28,100,'2026-04-10','2026-04-17','2026-05-17',150.00,1,'returned',2,1,NULL),
(445,1,28,'2025-11-16','2025-11-30','2025-11-27',0.00,0,'returned',1,2,NULL),
(446,12,63,'2025-11-02','2025-11-16','2025-11-14',0.00,0,'returned',1,2,NULL),
(447,49,49,'2025-06-22','2025-07-06','2025-07-05',0.00,0,'returned',1,1,NULL),
(448,56,104,'2025-07-26','2025-08-16','2025-08-14',0.00,0,'returned',1,1,NULL),
(449,55,107,'2025-12-30','2026-01-06','2026-01-04',0.00,0,'returned',1,2,NULL),
(450,54,41,'2025-11-24','2025-12-15','2025-12-10',0.00,0,'returned',1,1,NULL),
(451,12,36,'2026-07-23','2026-08-13',NULL,0.00,0,'issued',2,NULL,NULL),
(452,15,47,'2026-07-16','2026-07-30',NULL,0.00,0,'issued',2,NULL,NULL),
(453,2,18,'2026-07-15','2026-07-29',NULL,0.00,0,'issued',1,NULL,NULL),
(454,69,39,'2026-07-19','2026-08-09',NULL,0.00,0,'issued',2,NULL,NULL),
(455,59,48,'2026-07-20','2026-08-10',NULL,0.00,0,'issued',1,NULL,NULL),
(456,58,93,'2026-07-19','2026-08-09',NULL,0.00,0,'issued',2,NULL,NULL),
(457,58,8,'2026-07-22','2026-08-05',NULL,0.00,0,'issued',1,NULL,NULL),
(458,21,94,'2026-07-20','2026-08-10',NULL,0.00,0,'issued',2,NULL,NULL),
(459,59,116,'2026-07-19','2026-08-09',NULL,0.00,0,'issued',2,NULL,NULL),
(460,9,127,'2026-07-22','2026-08-05',NULL,0.00,0,'issued',2,NULL,NULL),
(461,63,100,'2026-07-23','2026-08-06',NULL,0.00,0,'issued',1,NULL,NULL),
(462,28,13,'2026-07-17','2026-07-26',NULL,0.00,0,'issued',2,NULL,NULL),
(463,34,150,'2026-07-23','2026-08-06',NULL,0.00,0,'issued',1,NULL,NULL),
(464,5,137,'2026-07-18','2026-08-01',NULL,0.00,0,'issued',1,NULL,NULL),
(465,13,39,'2026-07-22','2026-08-05',NULL,0.00,0,'issued',1,NULL,NULL),
(466,2,94,'2026-07-19','2026-08-09',NULL,0.00,0,'issued',2,NULL,NULL),
(467,68,73,'2026-07-20','2026-08-10',NULL,0.00,0,'issued',1,NULL,NULL),
(468,68,100,'2026-07-22','2026-08-12',NULL,0.00,0,'issued',2,NULL,NULL),
(469,34,93,'2026-07-20','2026-08-03',NULL,0.00,0,'issued',2,NULL,NULL),
(470,35,118,'2026-07-17','2026-07-31',NULL,0.00,0,'issued',2,NULL,NULL),
(471,29,21,'2026-07-24','2026-07-31',NULL,0.00,0,'issued',1,NULL,NULL),
(472,25,63,'2026-07-24','2026-08-14',NULL,0.00,0,'issued',2,NULL,NULL),
(473,20,114,'2026-07-20','2026-08-03',NULL,0.00,0,'issued',1,NULL,NULL),
(474,35,26,'2026-07-16','2026-08-06',NULL,0.00,0,'issued',2,NULL,NULL),
(475,14,103,'2026-07-18','2026-08-08',NULL,0.00,0,'issued',1,NULL,NULL),
(476,15,55,'2026-07-21','2026-08-04',NULL,0.00,0,'issued',2,NULL,NULL),
(477,42,72,'2026-07-20','2026-08-10',NULL,0.00,0,'issued',1,NULL,NULL),
(478,58,25,'2026-07-20','2026-07-27',NULL,0.00,0,'issued',2,NULL,NULL),
(479,40,37,'2026-07-15','2026-08-05',NULL,0.00,0,'issued',1,NULL,NULL),
(480,22,21,'2026-07-16','2026-07-27',NULL,0.00,0,'issued',1,NULL,NULL),
(481,17,19,'2026-07-17','2026-07-27',NULL,0.00,0,'issued',1,NULL,NULL),
(482,8,68,'2026-07-19','2026-08-09',NULL,0.00,0,'issued',2,NULL,NULL),
(483,54,69,'2026-07-19','2026-08-09',NULL,0.00,0,'issued',1,NULL,NULL),
(484,23,125,'2026-07-22','2026-07-29',NULL,0.00,0,'issued',2,NULL,NULL),
(485,53,8,'2026-07-17','2026-07-31',NULL,0.00,0,'issued',1,NULL,NULL),
(486,60,35,'2026-07-05','2026-07-12',NULL,0.00,0,'overdue',1,NULL,NULL),
(487,68,103,'2026-06-28','2026-07-12',NULL,0.00,0,'overdue',1,NULL,NULL),
(488,50,5,'2026-06-19','2026-07-10',NULL,0.00,0,'overdue',1,NULL,NULL),
(489,34,148,'2026-06-25','2026-07-09',NULL,0.00,0,'overdue',2,NULL,NULL),
(490,63,21,'2026-06-24','2026-07-01',NULL,0.00,0,'overdue',1,NULL,NULL),
(491,14,91,'2026-07-04','2026-07-18',NULL,0.00,0,'overdue',1,NULL,NULL),
(492,58,31,'2026-07-14','2026-07-21',NULL,0.00,0,'overdue',2,NULL,NULL),
(493,23,22,'2026-06-25','2026-07-16',NULL,0.00,0,'overdue',1,NULL,NULL),
(494,28,34,'2026-07-02','2026-07-23',NULL,0.00,0,'overdue',2,NULL,NULL),
(495,47,114,'2026-07-10','2026-07-17',NULL,0.00,0,'overdue',2,NULL,NULL),
(496,5,88,'2026-06-09','2026-06-30',NULL,0.00,0,'overdue',1,NULL,NULL),
(497,4,93,'2026-06-11','2026-07-02',NULL,0.00,0,'overdue',1,NULL,NULL),
(498,7,32,'2026-06-16','2026-07-07',NULL,0.00,0,'overdue',2,NULL,NULL),
(499,55,59,'2026-07-11','2026-07-18',NULL,0.00,0,'overdue',2,NULL,NULL),
(500,27,19,'2026-07-09','2026-07-23',NULL,0.00,0,'overdue',2,NULL,NULL);
/*!40000 ALTER TABLE `book_issues` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`library_admin`@`localhost`*/ /*!50003 TRIGGER trg_before_issue_insert
BEFORE INSERT ON book_issues
FOR EACH ROW
BEGIN
    DECLARE v_available INT;
    SELECT available_copies INTO v_available FROM books WHERE book_id = NEW.book_id;

    IF v_available IS NULL THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Cannot issue: book does not exist.';
    ELSEIF v_available <= 0 THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Cannot issue: no copies available.';
    END IF;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`library_admin`@`localhost`*/ /*!50003 TRIGGER trg_after_issue_insert
AFTER INSERT ON book_issues
FOR EACH ROW
BEGIN
    UPDATE books
        SET available_copies = available_copies - 1
        WHERE book_id = NEW.book_id;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`library_admin`@`localhost`*/ /*!50003 TRIGGER trg_before_issue_update_flag_overdue
BEFORE UPDATE ON book_issues
FOR EACH ROW
BEGIN
    IF NEW.status = 'issued' AND NEW.return_date IS NULL AND NEW.due_date < CURDATE() THEN
        SET NEW.status = 'overdue';
    END IF;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`library_admin`@`localhost`*/ /*!50003 TRIGGER trg_after_return_update
AFTER UPDATE ON book_issues
FOR EACH ROW
BEGIN
    IF OLD.status <> 'returned' AND NEW.status = 'returned' THEN
        UPDATE books
            SET available_copies = available_copies + 1
            WHERE book_id = NEW.book_id;
    END IF;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `books`
--

DROP TABLE IF EXISTS `books`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `books` (
  `book_id` int(11) NOT NULL AUTO_INCREMENT,
  `isbn` varchar(20) NOT NULL,
  `title` varchar(200) NOT NULL,
  `category_id` int(11) NOT NULL,
  `publisher_id` int(11) NOT NULL,
  `edition` varchar(30) DEFAULT NULL,
  `publication_year` year(4) DEFAULT NULL,
  `total_copies` int(11) NOT NULL DEFAULT 1,
  `available_copies` int(11) NOT NULL DEFAULT 1,
  `shelf_location` varchar(30) DEFAULT NULL,
  `price` decimal(8,2) NOT NULL DEFAULT 0.00,
  `status` enum('active','discontinued') NOT NULL DEFAULT 'active',
  `added_on` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`book_id`),
  UNIQUE KEY `uk_books_isbn` (`isbn`),
  KEY `idx_books_title` (`title`),
  KEY `idx_books_category` (`category_id`),
  KEY `idx_books_publisher` (`publisher_id`),
  KEY `idx_books_status` (`status`),
  FULLTEXT KEY `ft_books_title_search` (`title`),
  CONSTRAINT `fk_books_category` FOREIGN KEY (`category_id`) REFERENCES `categories` (`category_id`) ON UPDATE CASCADE,
  CONSTRAINT `fk_books_publisher` FOREIGN KEY (`publisher_id`) REFERENCES `publishers` (`publisher_id`) ON UPDATE CASCADE,
  CONSTRAINT `chk_books_copies` CHECK (`available_copies` >= 0 and `available_copies` <= `total_copies`),
  CONSTRAINT `chk_books_total` CHECK (`total_copies` >= 0),
  CONSTRAINT `chk_books_price` CHECK (`price` >= 0)
) ENGINE=InnoDB AUTO_INCREMENT=76 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `books`
--

LOCK TABLES `books` WRITE;
/*!40000 ALTER TABLE `books` DISABLE KEYS */;
INSERT INTO `books` VALUES
(1,'9781000099737','Introduction to Algorithms',1,4,'3rd',2009,7,7,'CS-01',899.00,'active','2026-07-25 01:10:17','2026-07-25 01:10:19'),
(2,'9781000199468','Clean Code',1,1,'1st',2008,8,6,'CS-02',650.00,'active','2026-07-25 01:10:17','2026-07-25 01:10:19'),
(3,'9781000299199','Clean Architecture',1,1,'1st',2017,6,6,'CS-03',699.00,'active','2026-07-25 01:10:17','2026-07-25 01:10:19'),
(4,'9781000398922','The C++ Programming Language',1,11,'4th',2013,5,4,'CS-04',850.00,'active','2026-07-25 01:10:17','2026-07-25 01:10:19'),
(5,'9781000498653','Java: The Complete Reference',1,4,'11th',2018,9,7,'CS-05',695.00,'active','2026-07-25 01:10:17','2026-07-25 01:10:19'),
(6,'9781000598384','C++: The Complete Reference',1,4,'4th',2002,6,6,'CS-06',599.00,'active','2026-07-25 01:10:17','2026-07-25 01:10:19'),
(7,'9781000698114','C: The Complete Reference',1,4,'4th',2000,7,6,'CS-07',549.00,'active','2026-07-25 01:10:17','2026-07-25 01:10:19'),
(8,'9781000797848','Let Us C',1,5,'17th',2021,10,9,'CS-08',375.00,'active','2026-07-25 01:10:17','2026-07-25 01:10:19'),
(9,'9781000897579','Let Us C++',1,5,'5th',2020,7,6,'CS-09',399.00,'active','2026-07-25 01:10:17','2026-07-25 01:10:19'),
(10,'9781000997309','Data Structures Through C',1,5,'1st',2019,6,6,'CS-10',425.00,'active','2026-07-25 01:10:17','2026-07-25 01:10:19'),
(11,'9781001097039','Pointers in C',1,5,'3rd',2015,5,5,'CS-11',350.00,'active','2026-07-25 01:10:17','2026-07-25 01:10:19'),
(12,'9781001196763','Python Crash Course',1,12,'2nd',2019,9,8,'CS-12',599.00,'active','2026-07-25 01:10:17','2026-07-25 01:10:19'),
(13,'9781001296494','Linear Algebra and Its Applications',2,15,'5th',2016,5,4,'MA-01',610.00,'active','2026-07-25 01:10:17','2026-07-25 01:10:19'),
(14,'9781001396224','Introduction to Linear Algebra',2,15,'5th',2016,4,2,'MA-02',590.00,'active','2026-07-25 01:10:17','2026-07-25 01:10:19'),
(15,'9781001495958','Calculus',2,15,'3rd',2017,5,3,'MA-03',550.00,'active','2026-07-25 01:10:17','2026-07-25 01:10:19'),
(16,'9781001595689','Differential Equations and Linear Algebra',2,15,'1st',2014,4,4,'MA-04',575.00,'active','2026-07-25 01:10:17','2026-07-25 01:10:18'),
(17,'9781001695419','Higher Engineering Mathematics',2,5,'44th',2020,8,7,'MA-05',550.00,'active','2026-07-25 01:10:17','2026-07-25 01:10:19'),
(18,'9781001795140','Numerical Methods in Engineering and Science',2,5,'10th',2018,4,4,'MA-06',480.00,'active','2026-07-25 01:10:17','2026-07-25 01:10:18'),
(19,'9781001894874','A First Course in Probability',2,1,'9th',2013,4,4,'MA-07',690.00,'active','2026-07-25 01:10:17','2026-07-25 01:10:18'),
(20,'9781001994604','A Brief History of Time',3,3,'1st',1988,6,5,'PH-01',399.00,'active','2026-07-25 01:10:17','2026-07-25 01:10:19'),
(21,'9781002094334','The Universe in a Nutshell',3,3,'1st',2001,4,3,'PH-02',425.00,'active','2026-07-25 01:10:17','2026-07-25 01:10:19'),
(22,'9781002194065','Concepts of Modern Physics',3,4,'6th',2009,5,4,'PH-03',615.00,'active','2026-07-25 01:10:17','2026-07-25 01:10:19'),
(23,'9781002293799','Concepts of Physics Part 1',3,6,'1st',2017,7,5,'PH-04',350.00,'active','2026-07-25 01:10:17','2026-07-25 01:10:19'),
(24,'9781002393529','Concepts of Physics Part 2',3,6,'1st',2017,6,6,'PH-05',350.00,'active','2026-07-25 01:10:17','2026-07-25 01:10:18'),
(25,'9781002493250','Quantum Physics for Beginners',3,6,'1st',2015,3,2,'PH-06',399.00,'active','2026-07-25 01:10:17','2026-07-25 01:10:19'),
(26,'9781002592984','Quantum Mechanics: Concepts and Applications',3,6,'2nd',2019,3,3,'PH-07',450.00,'active','2026-07-25 01:10:17','2026-07-25 01:10:19'),
(27,'9781002692714','Murder on the Orient Express',4,8,'1st',1934,8,7,'LI-01',299.00,'active','2026-07-25 01:10:17','2026-07-25 01:10:19'),
(28,'9781002792445','And Then There Were None',4,8,'1st',1939,9,7,'LI-02',299.00,'active','2026-07-25 01:10:17','2026-07-25 01:10:19'),
(29,'9781002892176','The Murder of Roger Ackroyd',4,8,'1st',1926,6,5,'LI-03',275.00,'active','2026-07-25 01:10:17','2026-07-25 01:10:19'),
(30,'9781002991909','Death on the Nile',4,8,'1st',1937,6,6,'LI-04',299.00,'active','2026-07-25 01:10:17','2026-07-25 01:10:18'),
(31,'9781003091639','1984',4,3,'1st',1949,10,10,'LI-05',299.00,'active','2026-07-25 01:10:17','2026-07-25 01:10:19'),
(32,'9781003191360','Animal Farm',4,3,'1st',1945,9,9,'LI-06',225.00,'active','2026-07-25 01:10:17','2026-07-25 01:10:19'),
(33,'9781003291091','Malgudi Days',4,3,'1st',1943,7,7,'LI-07',250.00,'active','2026-07-25 01:10:17','2026-07-25 01:10:19'),
(34,'9781003390824','Swami and Friends',4,3,'1st',1935,4,1,'LI-08',250.00,'active','2026-07-25 01:10:17','2026-07-25 01:10:19'),
(35,'9781003490555','Five Point Someone',4,3,'1st',2004,9,7,'LI-09',199.00,'active','2026-07-25 01:10:17','2026-07-25 01:10:19'),
(36,'9781003590286','2 States',4,3,'1st',2009,8,8,'LI-10',199.00,'active','2026-07-25 01:10:17','2026-07-25 01:10:18'),
(37,'9781003690016','Steve Jobs',5,3,'1st',2011,6,6,'BI-01',599.00,'active','2026-07-25 01:10:17','2026-07-25 01:10:19'),
(38,'9781003789741','Einstein: His Life and Universe',5,14,'1st',2007,4,4,'BI-02',550.00,'active','2026-07-25 01:10:17','2026-07-25 01:10:19'),
(39,'9781003889472','The Innovators',5,14,'1st',2014,3,3,'BI-03',525.00,'active','2026-07-25 01:10:17','2026-07-25 01:10:18'),
(40,'9781003989202','Wings of Fire',5,8,'1st',1999,8,7,'BI-04',275.00,'active','2026-07-25 01:10:17','2026-07-25 01:10:19'),
(41,'9781004088935','Ignited Minds',5,3,'1st',2002,5,5,'BI-05',250.00,'active','2026-07-25 01:10:17','2026-07-25 01:10:19'),
(42,'9781004188666','Sapiens: A Brief History of Humankind',6,3,'1st',2015,8,7,'HI-01',499.00,'active','2026-07-25 01:10:17','2026-07-25 01:10:19'),
(43,'9781004288397','Homo Deus',6,3,'1st',2016,5,5,'HI-02',499.00,'active','2026-07-25 01:10:17','2026-07-25 01:10:19'),
(44,'9781004388127','21 Lessons for the 21st Century',6,3,'1st',2018,4,4,'HI-03',499.00,'active','2026-07-25 01:10:17','2026-07-25 01:10:19'),
(45,'9781004487851','India After Gandhi',6,8,'2nd',2017,5,5,'HI-04',699.00,'active','2026-07-25 01:10:17','2026-07-25 01:10:19'),
(46,'9781004587582','Gandhi Before India',6,3,'1st',2013,3,3,'HI-05',599.00,'active','2026-07-25 01:10:17','2026-07-25 01:10:18'),
(47,'9781004687312','Makers of Modern India',6,7,'1st',2010,3,2,'HI-06',650.00,'active','2026-07-25 01:10:17','2026-07-25 01:10:19'),
(48,'9781004787043','Patriots and Partisans',6,3,'1st',2012,3,3,'HI-07',499.00,'active','2026-07-25 01:10:17','2026-07-25 01:10:19'),
(49,'9781004886777','Think and Grow Rich',7,5,'1st',1937,8,8,'BE-01',199.00,'active','2026-07-25 01:10:17','2026-07-25 01:10:19'),
(50,'9781004986507','Rich Dad Poor Dad',7,5,'1st',1997,9,8,'BE-02',299.00,'active','2026-07-25 01:10:17','2026-07-25 01:10:19'),
(51,'9781005086237','Cashflow Quadrant',7,5,'1st',1998,4,4,'BE-03',325.00,'active','2026-07-25 01:10:17','2026-07-25 01:10:19'),
(52,'9781005185961','Rich Dad\'s Guide to Investing',7,5,'1st',2000,3,3,'BE-04',350.00,'active','2026-07-25 01:10:17','2026-07-25 01:10:18'),
(53,'9781005285692','Outliers',7,14,'1st',2008,6,5,'BE-05',399.00,'active','2026-07-25 01:10:17','2026-07-25 01:10:19'),
(54,'9781005385422','The Tipping Point',7,14,'1st',2000,5,4,'BE-06',375.00,'active','2026-07-25 01:10:17','2026-07-25 01:10:19'),
(55,'9781005485153','Blink',7,14,'1st',2005,4,3,'BE-07',375.00,'active','2026-07-25 01:10:17','2026-07-25 01:10:19'),
(56,'9781005584887','David and Goliath',7,14,'1st',2013,3,3,'BE-08',399.00,'active','2026-07-25 01:10:17','2026-07-25 01:10:19'),
(57,'9781005684617','Atomic Habits',8,3,'1st',2018,10,10,'SH-01',449.00,'active','2026-07-25 01:10:17','2026-07-25 01:10:19'),
(58,'9781005784348','The Alchemist',8,8,'25th',2014,9,5,'SH-02',299.00,'active','2026-07-25 01:10:17','2026-07-25 01:10:19'),
(59,'9781005884079','Veronika Decides to Die',8,8,'1st',1998,4,2,'SH-03',299.00,'active','2026-07-25 01:10:17','2026-07-25 01:10:19'),
(60,'9781005983802','How to Win Friends and Influence People',8,14,'1st',1936,7,6,'SH-04',299.00,'active','2026-07-25 01:10:17','2026-07-25 01:10:19'),
(61,'9781006083532','How to Stop Worrying and Start Living',8,14,'1st',1948,4,4,'SH-05',299.00,'active','2026-07-25 01:10:17','2026-07-25 01:10:18'),
(62,'9781006183263','How to Enjoy Your Life and Your Job',8,14,'1st',1970,3,3,'SH-06',275.00,'active','2026-07-25 01:10:17','2026-07-25 01:10:17'),
(63,'9781006282997','Electronic Devices and Circuit Theory',9,1,'11th',2015,5,3,'EL-01',625.00,'active','2026-07-25 01:10:17','2026-07-25 01:10:19'),
(64,'9781006382727','Digital Fundamentals',9,1,'11th',2014,5,5,'EL-02',599.00,'active','2026-07-25 01:10:17','2026-07-25 01:10:19'),
(65,'9781006482458','Principles of Electric Circuits',9,1,'9th',2009,3,3,'EL-03',575.00,'active','2026-07-25 01:10:17','2026-07-25 01:10:19'),
(66,'9781006582189','Electric Circuits Fundamentals',9,1,'8th',2010,3,3,'EL-04',550.00,'active','2026-07-25 01:10:17','2026-07-25 01:10:19'),
(67,'9781006681912','Digital Logic and Computer Design',9,1,'1st',1979,6,6,'EL-05',499.00,'active','2026-07-25 01:10:17','2026-07-25 01:10:18'),
(68,'9781006781643','Computer System Architecture',9,1,'3rd',1992,4,1,'EL-06',525.00,'active','2026-07-25 01:10:17','2026-07-25 01:10:19'),
(69,'9781006881374','Digital Design',9,1,'6th',2017,4,3,'EL-07',599.00,'active','2026-07-25 01:10:17','2026-07-25 01:10:19'),
(70,'9781006981104','The Republic',10,6,'Oxford World\'s Classics',1998,5,5,'PL-01',350.00,'active','2026-07-25 01:10:17','2026-07-25 01:10:18'),
(71,'9781007080837','Symposium',10,6,'Oxford World\'s Classics',1994,3,3,'PL-02',299.00,'active','2026-07-25 01:10:17','2026-07-25 01:10:18'),
(72,'9781007180568','Apology',10,6,'Oxford World\'s Classics',1993,3,3,'PL-03',249.00,'active','2026-07-25 01:10:17','2026-07-25 01:10:18'),
(73,'9781007280299','Phaedo',10,6,'Oxford World\'s Classics',1993,2,2,'PL-04',275.00,'active','2026-07-25 01:10:17','2026-07-25 01:10:17'),
(74,'9781007380029','Crito',10,6,'Oxford World\'s Classics',1997,2,2,'PL-05',225.00,'active','2026-07-25 01:10:17','2026-07-25 01:10:18'),
(75,'9781007479754','Timaeus',10,6,'Oxford World\'s Classics',2008,2,2,'PL-06',299.00,'active','2026-07-25 01:10:17','2026-07-25 01:10:17');
/*!40000 ALTER TABLE `books` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`library_admin`@`localhost`*/ /*!50003 TRIGGER trg_audit_books_update
AFTER UPDATE ON books
FOR EACH ROW
BEGIN
    INSERT INTO audit_log (table_name, action, record_id, details)
    VALUES ('books', 'UPDATE', NEW.book_id,
        CONCAT('title=', NEW.title, ' | total_copies:', OLD.total_copies, '->', NEW.total_copies,
               ' | available_copies:', OLD.available_copies, '->', NEW.available_copies));
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`library_admin`@`localhost`*/ /*!50003 TRIGGER trg_audit_books_delete
BEFORE DELETE ON books
FOR EACH ROW
BEGIN
    INSERT INTO audit_log (table_name, action, record_id, details)
    VALUES ('books', 'DELETE', OLD.book_id, CONCAT('title=', OLD.title, ' | isbn=', OLD.isbn));
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `categories`
--

DROP TABLE IF EXISTS `categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `categories` (
  `category_id` int(11) NOT NULL AUTO_INCREMENT,
  `category_name` varchar(80) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`category_id`),
  UNIQUE KEY `uk_category_name` (`category_name`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categories`
--

LOCK TABLES `categories` WRITE;
/*!40000 ALTER TABLE `categories` DISABLE KEYS */;
INSERT INTO `categories` VALUES
(1,'Computer Science','Programming, algorithms, systems and data'),
(2,'Mathematics','Pure and applied mathematics'),
(3,'Physics','Classical and modern physics'),
(4,'Literature','Fiction and literary classics'),
(5,'Biography','Life stories of notable people'),
(6,'History','World and regional history'),
(7,'Business & Economics','Management, finance and economics'),
(8,'Self-Help','Personal development and productivity'),
(9,'Electronics','Circuits, embedded systems and hardware'),
(10,'Philosophy','Philosophical works and thought');
/*!40000 ALTER TABLE `categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fine_payments`
--

DROP TABLE IF EXISTS `fine_payments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `fine_payments` (
  `payment_id` int(11) NOT NULL AUTO_INCREMENT,
  `issue_id` int(11) NOT NULL,
  `amount_paid` decimal(8,2) NOT NULL,
  `payment_date` datetime NOT NULL DEFAULT current_timestamp(),
  `collected_by` int(11) DEFAULT NULL,
  PRIMARY KEY (`payment_id`),
  KEY `fk_payment_admin` (`collected_by`),
  KEY `idx_payments_issue` (`issue_id`),
  CONSTRAINT `fk_payment_admin` FOREIGN KEY (`collected_by`) REFERENCES `admins` (`admin_id`) ON DELETE SET NULL,
  CONSTRAINT `fk_payment_issue` FOREIGN KEY (`issue_id`) REFERENCES `book_issues` (`issue_id`) ON DELETE CASCADE,
  CONSTRAINT `chk_payment_amount` CHECK (`amount_paid` > 0)
) ENGINE=InnoDB AUTO_INCREMENT=161 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fine_payments`
--

LOCK TABLES `fine_payments` WRITE;
/*!40000 ALTER TABLE `fine_payments` DISABLE KEYS */;
INSERT INTO `fine_payments` VALUES
(1,1,160.00,'2026-07-25 01:10:19',1),
(2,5,95.00,'2026-07-25 01:10:19',1),
(3,20,140.00,'2026-07-25 01:10:19',2),
(4,22,170.00,'2026-07-25 01:10:19',2),
(5,23,210.00,'2026-07-25 01:10:19',2),
(6,25,155.00,'2026-07-25 01:10:19',1),
(7,31,70.00,'2026-07-25 01:10:19',2),
(8,32,185.00,'2026-07-25 01:10:19',1),
(9,45,190.00,'2026-07-25 01:10:19',2),
(10,51,215.00,'2026-07-25 01:10:19',2),
(11,52,225.00,'2026-07-25 01:10:19',1),
(12,55,35.00,'2026-07-25 01:10:19',2),
(13,63,210.00,'2026-07-25 01:10:19',1),
(14,64,155.00,'2026-07-25 01:10:19',1),
(15,74,20.00,'2026-07-25 01:10:19',2),
(16,75,125.00,'2026-07-25 01:10:19',1),
(17,81,120.00,'2026-07-25 01:10:19',2),
(18,85,25.00,'2026-07-25 01:10:19',2),
(19,95,135.00,'2026-07-25 01:10:19',2),
(20,100,185.00,'2026-07-25 01:10:19',1),
(21,101,160.00,'2026-07-25 01:10:19',1),
(22,105,90.00,'2026-07-25 01:10:19',1),
(23,111,125.00,'2026-07-25 01:10:19',1),
(24,113,20.00,'2026-07-25 01:10:19',1),
(25,121,45.00,'2026-07-25 01:10:19',1),
(26,122,95.00,'2026-07-25 01:10:19',2),
(27,124,130.00,'2026-07-25 01:10:19',1),
(28,130,100.00,'2026-07-25 01:10:19',2),
(29,133,155.00,'2026-07-25 01:10:19',1),
(30,142,10.00,'2026-07-25 01:10:19',2),
(31,144,135.00,'2026-07-25 01:10:19',1),
(32,145,20.00,'2026-07-25 01:10:19',1),
(33,150,100.00,'2026-07-25 01:10:19',2),
(34,155,180.00,'2026-07-25 01:10:19',2),
(35,161,20.00,'2026-07-25 01:10:19',1),
(36,172,175.00,'2026-07-25 01:10:19',2),
(37,174,130.00,'2026-07-25 01:10:19',1),
(38,180,180.00,'2026-07-25 01:10:19',1),
(39,185,205.00,'2026-07-25 01:10:19',1),
(40,205,135.00,'2026-07-25 01:10:19',2),
(41,210,80.00,'2026-07-25 01:10:19',2),
(42,224,155.00,'2026-07-25 01:10:19',1),
(43,232,105.00,'2026-07-25 01:10:19',2),
(44,233,25.00,'2026-07-25 01:10:19',1),
(45,244,185.00,'2026-07-25 01:10:19',1),
(46,245,130.00,'2026-07-25 01:10:19',2),
(47,250,50.00,'2026-07-25 01:10:19',1),
(48,251,120.00,'2026-07-25 01:10:19',1),
(49,253,130.00,'2026-07-25 01:10:19',2),
(50,254,190.00,'2026-07-25 01:10:19',1),
(51,262,130.00,'2026-07-25 01:10:19',1),
(52,270,10.00,'2026-07-25 01:10:19',1),
(53,274,215.00,'2026-07-25 01:10:19',1),
(54,275,160.00,'2026-07-25 01:10:19',1),
(55,284,155.00,'2026-07-25 01:10:19',2),
(56,291,185.00,'2026-07-25 01:10:19',1),
(57,292,135.00,'2026-07-25 01:10:19',1),
(58,293,155.00,'2026-07-25 01:10:19',2),
(59,295,65.00,'2026-07-25 01:10:19',1),
(60,304,130.00,'2026-07-25 01:10:19',1),
(61,315,10.00,'2026-07-25 01:10:19',2),
(62,323,150.00,'2026-07-25 01:10:19',2),
(63,331,190.00,'2026-07-25 01:10:19',1),
(64,332,200.00,'2026-07-25 01:10:19',1),
(65,340,15.00,'2026-07-25 01:10:19',2),
(66,341,15.00,'2026-07-25 01:10:19',1),
(67,342,90.00,'2026-07-25 01:10:19',2),
(68,344,55.00,'2026-07-25 01:10:19',2),
(69,350,25.00,'2026-07-25 01:10:19',2),
(70,352,145.00,'2026-07-25 01:10:19',1),
(71,360,190.00,'2026-07-25 01:10:19',1),
(72,364,45.00,'2026-07-25 01:10:19',2),
(73,371,210.00,'2026-07-25 01:10:19',1),
(74,372,25.00,'2026-07-25 01:10:19',1),
(75,380,65.00,'2026-07-25 01:10:19',1),
(76,382,70.00,'2026-07-25 01:10:19',1),
(77,384,135.00,'2026-07-25 01:10:19',2),
(78,395,210.00,'2026-07-25 01:10:19',2),
(79,401,165.00,'2026-07-25 01:10:19',2),
(80,402,155.00,'2026-07-25 01:10:19',1),
(81,404,105.00,'2026-07-25 01:10:19',2),
(82,412,55.00,'2026-07-25 01:10:19',2),
(83,415,50.00,'2026-07-25 01:10:19',1),
(84,420,135.00,'2026-07-25 01:10:19',1),
(85,423,130.00,'2026-07-25 01:10:19',2),
(86,425,145.00,'2026-07-25 01:10:19',1),
(87,431,115.00,'2026-07-25 01:10:19',2),
(88,432,180.00,'2026-07-25 01:10:19',2),
(89,435,150.00,'2026-07-25 01:10:19',1),
(90,441,155.00,'2026-07-25 01:10:19',2),
(91,444,150.00,'2026-07-25 01:10:19',1),
(128,6,88.00,'2026-07-25 01:10:19',2),
(129,26,72.00,'2026-07-25 01:10:19',2),
(130,27,8.00,'2026-07-25 01:10:19',2),
(131,47,6.00,'2026-07-25 01:10:19',1),
(132,86,66.00,'2026-07-25 01:10:19',1),
(133,116,28.00,'2026-07-25 01:10:19',2),
(134,126,18.00,'2026-07-25 01:10:19',2),
(135,136,64.00,'2026-07-25 01:10:19',2),
(136,157,48.00,'2026-07-25 01:10:19',2),
(137,166,12.00,'2026-07-25 01:10:19',2),
(138,167,12.00,'2026-07-25 01:10:19',1),
(139,177,42.00,'2026-07-25 01:10:19',1),
(140,187,28.00,'2026-07-25 01:10:19',2),
(141,196,32.00,'2026-07-25 01:10:19',1),
(142,227,80.00,'2026-07-25 01:10:19',1),
(143,256,90.00,'2026-07-25 01:10:19',1),
(144,257,52.00,'2026-07-25 01:10:19',2),
(145,267,36.00,'2026-07-25 01:10:19',2),
(146,276,30.00,'2026-07-25 01:10:19',2),
(147,277,74.00,'2026-07-25 01:10:19',1),
(148,296,34.00,'2026-07-25 01:10:19',1),
(149,317,86.00,'2026-07-25 01:10:19',2),
(150,326,50.00,'2026-07-25 01:10:19',1),
(151,327,68.00,'2026-07-25 01:10:19',1),
(152,336,68.00,'2026-07-25 01:10:19',2),
(153,337,90.00,'2026-07-25 01:10:19',2),
(154,347,88.00,'2026-07-25 01:10:19',2),
(155,357,54.00,'2026-07-25 01:10:19',2),
(156,367,20.00,'2026-07-25 01:10:19',2),
(157,376,86.00,'2026-07-25 01:10:19',2),
(158,397,18.00,'2026-07-25 01:10:19',2),
(159,417,88.00,'2026-07-25 01:10:19',2),
(160,436,30.00,'2026-07-25 01:10:19',2);
/*!40000 ALTER TABLE `fine_payments` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`library_admin`@`localhost`*/ /*!50003 TRIGGER trg_audit_fine_payment
AFTER INSERT ON fine_payments
FOR EACH ROW
BEGIN
    INSERT INTO audit_log (table_name, action, record_id, details)
    VALUES ('fine_payments', 'INSERT', NEW.payment_id,
        CONCAT('issue_id=', NEW.issue_id, ' | amount=', NEW.amount_paid));
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `publishers`
--

DROP TABLE IF EXISTS `publishers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `publishers` (
  `publisher_id` int(11) NOT NULL AUTO_INCREMENT,
  `publisher_name` varchar(120) NOT NULL,
  `address` varchar(255) DEFAULT NULL,
  `contact_email` varchar(120) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`publisher_id`),
  UNIQUE KEY `uk_publisher_name` (`publisher_name`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `publishers`
--

LOCK TABLES `publishers` WRITE;
/*!40000 ALTER TABLE `publishers` DISABLE KEYS */;
INSERT INTO `publishers` VALUES
(1,'Pearson Education','Noida, India','contact@pearson.example','0120-4567890'),
(2,'O\'Reilly Media','Sebastopol, CA, USA','orders@oreilly.example','+1-707-8271000'),
(3,'Penguin Random House','New Delhi, India','info@penguin.example','011-42345678'),
(4,'McGraw Hill','New York, USA','support@mheducation.example','+1-212-9048000'),
(5,'Wiley India','New Delhi, India','wileyindia@wiley.example','011-43635444'),
(6,'Oxford University Press','Oxford, UK','enquiry@oup.example','+44-1865-556767'),
(7,'Cambridge University Press','Cambridge, UK','info@cambridge.example','+44-1223-358331'),
(8,'HarperCollins','Noida, India','contact@harpercollins.example','0120-4044800'),
(9,'Springer','Berlin, Germany','service@springer.example','+49-30-8270'),
(10,'Manning Publications','Shelter Island, USA','orders@manning.example','+1-877-6266263'),
(11,'Addison-Wesley Professional','Boston, USA','aw.orders@pearson.example','+1-617-8483000'),
(12,'No Starch Press','San Francisco, USA','info@nostarch.example','+1-415-2237800'),
(13,'Bloomsbury Publishing','London, UK','contact@bloomsbury.example','+44-20-74586300'),
(14,'Macmillan Publishers','London, UK','info@macmillan.example','+44-20-78336900'),
(15,'Cengage Learning','Boston, USA','support@cengage.example','+1-800-3549706');
/*!40000 ALTER TABLE `publishers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `settings`
--

DROP TABLE IF EXISTS `settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `settings` (
  `setting_key` varchar(50) NOT NULL,
  `setting_value` varchar(255) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`setting_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `settings`
--

LOCK TABLES `settings` WRITE;
/*!40000 ALTER TABLE `settings` DISABLE KEYS */;
INSERT INTO `settings` VALUES
('default_issue_days','14','Default loan period in days','2026-07-25 01:10:17'),
('fine_per_day','5.00','Late fine charged per day, in INR','2026-07-25 01:10:17'),
('max_books_per_student','3','Maximum books a student may hold at once','2026-07-25 01:10:17'),
('max_fine_per_book','500.00','Ceiling on fine for a single issue','2026-07-25 01:10:17');
/*!40000 ALTER TABLE `settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `students`
--

DROP TABLE IF EXISTS `students`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `students` (
  `student_id` int(11) NOT NULL AUTO_INCREMENT,
  `roll_number` varchar(30) NOT NULL,
  `full_name` varchar(100) NOT NULL,
  `email` varchar(120) NOT NULL,
  `phone` varchar(15) NOT NULL,
  `department` varchar(80) DEFAULT NULL,
  `semester` tinyint(4) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `membership_date` date NOT NULL DEFAULT curdate(),
  `status` enum('active','inactive','blocked') NOT NULL DEFAULT 'active',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`student_id`),
  UNIQUE KEY `uk_students_roll` (`roll_number`),
  UNIQUE KEY `uk_students_email` (`email`),
  UNIQUE KEY `uk_students_phone` (`phone`),
  KEY `idx_students_name` (`full_name`),
  KEY `idx_students_dept` (`department`),
  KEY `idx_students_status` (`status`),
  CONSTRAINT `chk_students_semester` CHECK (`semester` between 1 and 12)
) ENGINE=InnoDB AUTO_INCREMENT=151 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `students`
--

LOCK TABLES `students` WRITE;
/*!40000 ALTER TABLE `students` DISABLE KEYS */;
INSERT INTO `students` VALUES
(1,'BBD-CS-202301','Tanvi Sharma','tanvi.sharma0@student.bbd.example','9810000000','Computer Science',1,NULL,'2026-02-21','active','2026-07-25 01:10:17'),
(2,'BBD-ME-202201','Arjun Sharma','arjun.sharma1@student.bbd.example','9810000001','Mechanical',8,NULL,'2023-08-31','active','2026-07-25 01:10:17'),
(3,'BBD-CV-202401','Rohan Sharma','rohan.sharma2@student.bbd.example','9810000002','Civil',1,NULL,'2023-08-20','active','2026-07-25 01:10:17'),
(4,'BBD-CS-202302','Samar Sharma','samar.sharma3@student.bbd.example','9810000003','Computer Science',2,NULL,'2025-03-01','active','2026-07-25 01:10:17'),
(5,'BBD-IT-202501','Radhika Sharma','radhika.sharma4@student.bbd.example','9810000004','Information Technology',4,NULL,'2026-04-05','active','2026-07-25 01:10:17'),
(6,'BBD-EC-202401','Kabir Sharma','kabir.sharma5@student.bbd.example','9810000005','Electronics',6,NULL,'2025-01-07','active','2026-07-25 01:10:17'),
(7,'BBD-CS-202501','Pooja Sharma','pooja.sharma6@student.bbd.example','9810000006','Computer Science',4,NULL,'2024-12-29','active','2026-07-25 01:10:17'),
(8,'BBD-IT-202502','Krishna Sharma','krishna.sharma7@student.bbd.example','9810000007','Information Technology',5,NULL,'2023-12-02','active','2026-07-25 01:10:17'),
(9,'BBD-IT-202503','Aditya Sharma','aditya.sharma8@student.bbd.example','9810000008','Information Technology',2,NULL,'2026-06-06','active','2026-07-25 01:10:17'),
(10,'BBD-IT-202504','Varun Sharma','varun.sharma9@student.bbd.example','9810000009','Information Technology',2,NULL,'2026-01-26','blocked','2026-07-25 01:10:17'),
(11,'BBD-EC-202402','Atharv Sharma','atharv.sharma10@student.bbd.example','9810000010','Electronics',3,NULL,'2024-07-11','blocked','2026-07-25 01:10:17'),
(12,'BBD-CV-202501','Siddharth Sharma','siddharth.sharma11@student.bbd.example','9810000011','Civil',6,NULL,'2024-11-19','blocked','2026-07-25 01:10:17'),
(13,'BBD-CS-202502','Bhavya Sharma','bhavya.sharma12@student.bbd.example','9810000012','Computer Science',5,NULL,'2026-06-09','active','2026-07-25 01:10:17'),
(14,'BBD-EC-202403','Naina Sharma','naina.sharma13@student.bbd.example','9810000013','Electronics',2,NULL,'2025-09-23','active','2026-07-25 01:10:17'),
(15,'BBD-CS-202503','Pihu Sharma','pihu.sharma14@student.bbd.example','9810000014','Computer Science',3,NULL,'2024-12-15','active','2026-07-25 01:10:17'),
(16,'BBD-CS-202303','Veer Sharma','veer.sharma15@student.bbd.example','9810000015','Computer Science',6,NULL,'2025-05-05','active','2026-07-25 01:10:17'),
(17,'BBD-EC-202501','Aarav Sharma','aarav.sharma16@student.bbd.example','9810000016','Electronics',8,NULL,'2025-01-27','active','2026-07-25 01:10:17'),
(18,'BBD-CV-202502','Dev Sharma','dev.sharma17@student.bbd.example','9810000017','Civil',2,NULL,'2024-02-09','active','2026-07-25 01:10:17'),
(19,'BBD-ME-202202','Rahul Sharma','rahul.sharma18@student.bbd.example','9810000018','Mechanical',6,NULL,'2025-10-01','active','2026-07-25 01:10:17'),
(20,'BBD-EC-202301','Darsh Sharma','darsh.sharma19@student.bbd.example','9810000019','Electronics',8,NULL,'2024-02-01','active','2026-07-25 01:10:17'),
(21,'BBD-EC-202201','Gaurav Sharma','gaurav.sharma20@student.bbd.example','9810000020','Electronics',3,NULL,'2026-04-13','active','2026-07-25 01:10:17'),
(22,'BBD-ME-202401','Simran Sharma','simran.sharma21@student.bbd.example','9810000021','Mechanical',3,NULL,'2024-01-27','active','2026-07-25 01:10:17'),
(23,'BBD-CS-202304','Sanya Sharma','sanya.sharma22@student.bbd.example','9810000022','Computer Science',1,NULL,'2024-06-23','inactive','2026-07-25 01:10:17'),
(24,'BBD-CS-202305','Ananya Sharma','ananya.sharma23@student.bbd.example','9810000023','Computer Science',2,NULL,'2024-07-01','inactive','2026-07-25 01:10:17'),
(25,'BBD-ME-202501','Om Sharma','om.sharma24@student.bbd.example','9810000024','Mechanical',7,NULL,'2025-08-13','active','2026-07-25 01:10:17'),
(26,'BBD-CV-202301','Rajesh Sharma','rajesh.sharma25@student.bbd.example','9810000025','Civil',3,NULL,'2025-06-28','active','2026-07-25 01:10:17'),
(27,'BBD-CV-202201','Nisha Sharma','nisha.sharma26@student.bbd.example','9810000026','Civil',6,NULL,'2024-03-04','active','2026-07-25 01:10:17'),
(28,'BBD-ME-202502','Aditi Sharma','aditi.sharma27@student.bbd.example','9810000027','Mechanical',4,NULL,'2024-12-26','active','2026-07-25 01:10:17'),
(29,'BBD-CS-202504','Swati Sharma','swati.sharma28@student.bbd.example','9810000028','Computer Science',7,NULL,'2026-04-07','active','2026-07-25 01:10:17'),
(30,'BBD-ME-202301','Harsh Sharma','harsh.sharma29@student.bbd.example','9810000029','Mechanical',8,NULL,'2024-07-09','active','2026-07-25 01:10:17'),
(31,'BBD-IT-202505','Mahika Sharma','mahika.sharma30@student.bbd.example','9810000030','Information Technology',4,NULL,'2025-03-26','active','2026-07-25 01:10:17'),
(32,'BBD-CS-202306','Vivaan Sharma','vivaan.sharma31@student.bbd.example','9810000031','Computer Science',6,NULL,'2024-12-02','active','2026-07-25 01:10:17'),
(33,'BBD-ME-202503','Saanvi Sharma','saanvi.sharma32@student.bbd.example','9810000032','Mechanical',5,NULL,'2024-07-06','blocked','2026-07-25 01:10:17'),
(34,'BBD-EC-202404','Vikram Sharma','vikram.sharma33@student.bbd.example','9810000033','Electronics',6,NULL,'2026-04-30','active','2026-07-25 01:10:17'),
(35,'BBD-CS-202505','Kian Sharma','kian.sharma34@student.bbd.example','9810000034','Computer Science',3,NULL,'2024-12-29','active','2026-07-25 01:10:17'),
(36,'BBD-CS-202401','Aisha Sharma','aisha.sharma35@student.bbd.example','9810000035','Computer Science',6,NULL,'2024-09-21','active','2026-07-25 01:10:17'),
(37,'BBD-IT-202506','Meera Sharma','meera.sharma36@student.bbd.example','9810000036','Information Technology',2,NULL,'2024-04-28','active','2026-07-25 01:10:17'),
(38,'BBD-CV-202302','Shreya Sharma','shreya.sharma37@student.bbd.example','9810000037','Civil',1,NULL,'2024-01-14','active','2026-07-25 01:10:17'),
(39,'BBD-CS-202506','Riya Sharma','riya.sharma38@student.bbd.example','9810000038','Computer Science',4,NULL,'2024-06-10','active','2026-07-25 01:10:17'),
(40,'BBD-IT-202507','Manav Sharma','manav.sharma39@student.bbd.example','9810000039','Information Technology',6,NULL,'2024-09-21','active','2026-07-25 01:10:17'),
(41,'BBD-EC-202202','Kunal Sharma','kunal.sharma40@student.bbd.example','9810000040','Electronics',5,NULL,'2023-08-22','active','2026-07-25 01:10:17'),
(42,'BBD-IT-202401','Nandini Sharma','nandini.sharma41@student.bbd.example','9810000041','Information Technology',7,NULL,'2024-10-28','active','2026-07-25 01:10:17'),
(43,'BBD-EC-202302','Nikhil Sharma','nikhil.sharma42@student.bbd.example','9810000042','Electronics',7,NULL,'2025-07-04','active','2026-07-25 01:10:17'),
(44,'BBD-EC-202303','Kiara Sharma','kiara.sharma43@student.bbd.example','9810000043','Electronics',1,NULL,'2024-10-11','active','2026-07-25 01:10:17'),
(45,'BBD-CS-202402','Sanjay Sharma','sanjay.sharma44@student.bbd.example','9810000044','Computer Science',6,NULL,'2023-11-16','active','2026-07-25 01:10:17'),
(46,'BBD-IT-202508','Aryan Sharma','aryan.sharma45@student.bbd.example','9810000045','Information Technology',8,NULL,'2025-07-13','active','2026-07-25 01:10:17'),
(47,'BBD-EC-202304','Tara Sharma','tara.sharma46@student.bbd.example','9810000046','Electronics',6,NULL,'2025-12-16','active','2026-07-25 01:10:17'),
(48,'BBD-ME-202504','Ayaan Sharma','ayaan.sharma47@student.bbd.example','9810000047','Mechanical',5,NULL,'2025-03-22','active','2026-07-25 01:10:17'),
(49,'BBD-ME-202203','Navya Sharma','navya.sharma48@student.bbd.example','9810000048','Mechanical',1,NULL,'2025-02-09','active','2026-07-25 01:10:17'),
(50,'BBD-CV-202402','Vihaan Sharma','vihaan.sharma49@student.bbd.example','9810000049','Civil',2,NULL,'2023-12-06','blocked','2026-07-25 01:10:17'),
(51,'BBD-IT-202402','Nitin Sharma','nitin.sharma50@student.bbd.example','9810000050','Information Technology',4,NULL,'2024-04-30','active','2026-07-25 01:10:17'),
(52,'BBD-IT-202301','Neha Sharma','neha.sharma51@student.bbd.example','9810000051','Information Technology',1,NULL,'2025-11-19','inactive','2026-07-25 01:10:17'),
(53,'BBD-ME-202302','Diya Sharma','diya.sharma52@student.bbd.example','9810000052','Mechanical',8,NULL,'2026-03-15','active','2026-07-25 01:10:17'),
(54,'BBD-EC-202502','Yash Sharma','yash.sharma53@student.bbd.example','9810000053','Electronics',2,NULL,'2023-12-04','active','2026-07-25 01:10:17'),
(55,'BBD-CS-202403','Rajat Sharma','rajat.sharma54@student.bbd.example','9810000054','Computer Science',6,NULL,'2024-01-01','active','2026-07-25 01:10:17'),
(56,'BBD-EC-202503','Anvi Sharma','anvi.sharma55@student.bbd.example','9810000055','Electronics',7,NULL,'2023-12-25','inactive','2026-07-25 01:10:17'),
(57,'BBD-CV-202503','Ritu Sharma','ritu.sharma56@student.bbd.example','9810000056','Civil',8,NULL,'2023-12-17','active','2026-07-25 01:10:17'),
(58,'BBD-CS-202307','Advik Sharma','advik.sharma57@student.bbd.example','9810000057','Computer Science',5,NULL,'2023-07-24','active','2026-07-25 01:10:17'),
(59,'BBD-IT-202302','Ira Sharma','ira.sharma58@student.bbd.example','9810000058','Information Technology',8,NULL,'2026-01-18','active','2026-07-25 01:10:17'),
(60,'BBD-EC-202305','Sara Sharma','sara.sharma59@student.bbd.example','9810000059','Electronics',6,NULL,'2024-09-09','active','2026-07-25 01:10:17'),
(61,'BBD-CV-202202','Pari Sharma','pari.sharma60@student.bbd.example','9810000060','Civil',3,NULL,'2025-03-09','active','2026-07-25 01:10:17'),
(62,'BBD-IT-202303','Rudra Sharma','rudra.sharma61@student.bbd.example','9810000061','Information Technology',4,NULL,'2026-02-14','active','2026-07-25 01:10:17'),
(63,'BBD-IT-202304','Karan Sharma','karan.sharma62@student.bbd.example','9810000062','Information Technology',8,NULL,'2024-02-25','active','2026-07-25 01:10:17'),
(64,'BBD-CS-202507','Ranveer Sharma','ranveer.sharma63@student.bbd.example','9810000063','Computer Science',7,NULL,'2026-05-16','active','2026-07-25 01:10:17'),
(65,'BBD-ME-202505','Zara Sharma','zara.sharma64@student.bbd.example','9810000064','Mechanical',7,NULL,'2023-10-23','active','2026-07-25 01:10:17'),
(66,'BBD-CS-202404','Ishaan Sharma','ishaan.sharma65@student.bbd.example','9810000065','Computer Science',7,NULL,'2024-02-18','active','2026-07-25 01:10:17'),
(67,'BBD-EC-202504','Avni Sharma','avni.sharma66@student.bbd.example','9810000066','Electronics',4,NULL,'2023-09-30','inactive','2026-07-25 01:10:17'),
(68,'BBD-CS-202405','Kavya Sharma','kavya.sharma67@student.bbd.example','9810000067','Computer Science',1,NULL,'2024-04-20','active','2026-07-25 01:10:17'),
(69,'BBD-IT-202509','Divya Sharma','divya.sharma68@student.bbd.example','9810000068','Information Technology',7,NULL,'2025-07-22','active','2026-07-25 01:10:17'),
(70,'BBD-ME-202506','Dhruv Sharma','dhruv.sharma69@student.bbd.example','9810000069','Mechanical',1,NULL,'2024-04-10','active','2026-07-25 01:10:17'),
(71,'BBD-EC-202505','Aarush Sharma','aarush.sharma70@student.bbd.example','9810000070','Electronics',2,NULL,'2024-01-30','active','2026-07-25 01:10:17'),
(72,'BBD-CS-202406','Pallavi Sharma','pallavi.sharma71@student.bbd.example','9810000071','Computer Science',1,NULL,'2025-01-09','active','2026-07-25 01:10:17'),
(73,'BBD-IT-202305','Anika Sharma','anika.sharma72@student.bbd.example','9810000072','Information Technology',6,NULL,'2024-08-03','active','2026-07-25 01:10:17'),
(74,'BBD-ME-202402','Myra Sharma','myra.sharma73@student.bbd.example','9810000073','Mechanical',7,NULL,'2025-01-25','active','2026-07-25 01:10:17'),
(75,'BBD-ME-202403','Priya Sharma','priya.sharma74@student.bbd.example','9810000074','Mechanical',1,NULL,'2024-07-09','active','2026-07-25 01:10:17'),
(76,'BBD-CS-202201','Reyansh Sharma','reyansh.sharma75@student.bbd.example','9810000075','Computer Science',1,NULL,'2026-04-23','active','2026-07-25 01:10:17'),
(77,'BBD-CV-202303','Akash Sharma','akash.sharma76@student.bbd.example','9810000076','Civil',1,NULL,'2025-08-17','inactive','2026-07-25 01:10:17'),
(78,'BBD-CS-202407','Isha Sharma','isha.sharma77@student.bbd.example','9810000077','Computer Science',2,NULL,'2025-04-05','active','2026-07-25 01:10:17'),
(79,'BBD-IT-202306','Shaurya Sharma','shaurya.sharma78@student.bbd.example','9810000078','Information Technology',6,NULL,'2025-07-17','active','2026-07-25 01:10:17'),
(80,'BBD-EC-202506','Tanvi Gupta','tanvi.gupta79@student.bbd.example','9810000079','Electronics',2,NULL,'2025-07-25','active','2026-07-25 01:10:17'),
(81,'BBD-CV-202203','Arjun Gupta','arjun.gupta80@student.bbd.example','9810000080','Civil',1,NULL,'2024-09-25','active','2026-07-25 01:10:17'),
(82,'BBD-EC-202507','Rohan Gupta','rohan.gupta81@student.bbd.example','9810000081','Electronics',7,NULL,'2024-04-04','active','2026-07-25 01:10:17'),
(83,'BBD-CV-202304','Samar Gupta','samar.gupta82@student.bbd.example','9810000082','Civil',4,NULL,'2025-11-29','inactive','2026-07-25 01:10:17'),
(84,'BBD-EC-202306','Radhika Gupta','radhika.gupta83@student.bbd.example','9810000083','Electronics',2,NULL,'2026-04-02','active','2026-07-25 01:10:17'),
(85,'BBD-IT-202403','Kabir Gupta','kabir.gupta84@student.bbd.example','9810000084','Information Technology',6,NULL,'2026-02-04','active','2026-07-25 01:10:17'),
(86,'BBD-IT-202307','Pooja Gupta','pooja.gupta85@student.bbd.example','9810000085','Information Technology',7,NULL,'2023-09-26','active','2026-07-25 01:10:17'),
(87,'BBD-CS-202508','Krishna Gupta','krishna.gupta86@student.bbd.example','9810000086','Computer Science',8,NULL,'2025-08-16','active','2026-07-25 01:10:17'),
(88,'BBD-IT-202510','Aditya Gupta','aditya.gupta87@student.bbd.example','9810000087','Information Technology',5,NULL,'2023-10-09','active','2026-07-25 01:10:17'),
(89,'BBD-IT-202511','Varun Gupta','varun.gupta88@student.bbd.example','9810000088','Information Technology',5,NULL,'2024-09-03','active','2026-07-25 01:10:17'),
(90,'BBD-ME-202507','Atharv Gupta','atharv.gupta89@student.bbd.example','9810000089','Mechanical',2,NULL,'2024-12-01','active','2026-07-25 01:10:17'),
(91,'BBD-CV-202305','Siddharth Gupta','siddharth.gupta90@student.bbd.example','9810000090','Civil',8,NULL,'2024-05-10','active','2026-07-25 01:10:17'),
(92,'BBD-IT-202404','Bhavya Gupta','bhavya.gupta91@student.bbd.example','9810000091','Information Technology',6,NULL,'2025-06-18','inactive','2026-07-25 01:10:17'),
(93,'BBD-IT-202405','Naina Gupta','naina.gupta92@student.bbd.example','9810000092','Information Technology',5,NULL,'2024-07-28','active','2026-07-25 01:10:17'),
(94,'BBD-CS-202408','Pihu Gupta','pihu.gupta93@student.bbd.example','9810000093','Computer Science',5,NULL,'2026-06-05','active','2026-07-25 01:10:17'),
(95,'BBD-IT-202308','Veer Gupta','veer.gupta94@student.bbd.example','9810000094','Information Technology',4,NULL,'2024-03-15','active','2026-07-25 01:10:17'),
(96,'BBD-IT-202512','Aarav Gupta','aarav.gupta95@student.bbd.example','9810000095','Information Technology',8,NULL,'2023-09-24','active','2026-07-25 01:10:17'),
(97,'BBD-IT-202201','Dev Gupta','dev.gupta96@student.bbd.example','9810000096','Information Technology',5,NULL,'2025-03-29','active','2026-07-25 01:10:17'),
(98,'BBD-IT-202309','Rahul Gupta','rahul.gupta97@student.bbd.example','9810000097','Information Technology',6,NULL,'2023-10-30','active','2026-07-25 01:10:17'),
(99,'BBD-EC-202307','Darsh Gupta','darsh.gupta98@student.bbd.example','9810000098','Electronics',6,NULL,'2024-07-05','active','2026-07-25 01:10:17'),
(100,'BBD-EC-202308','Gaurav Gupta','gaurav.gupta99@student.bbd.example','9810000099','Electronics',5,NULL,'2025-03-10','active','2026-07-25 01:10:17'),
(101,'BBD-CS-202308','Simran Gupta','simran.gupta100@student.bbd.example','9810000100','Computer Science',2,NULL,'2025-06-11','active','2026-07-25 01:10:17'),
(102,'BBD-CS-202509','Sanya Gupta','sanya.gupta101@student.bbd.example','9810000101','Computer Science',5,NULL,'2024-11-23','blocked','2026-07-25 01:10:17'),
(103,'BBD-CV-202504','Ananya Gupta','ananya.gupta102@student.bbd.example','9810000102','Civil',5,NULL,'2025-03-17','active','2026-07-25 01:10:17'),
(104,'BBD-IT-202310','Om Gupta','om.gupta103@student.bbd.example','9810000103','Information Technology',3,NULL,'2024-12-11','active','2026-07-25 01:10:17'),
(105,'BBD-CS-202202','Rajesh Gupta','rajesh.gupta104@student.bbd.example','9810000104','Computer Science',5,NULL,'2025-10-10','active','2026-07-25 01:10:17'),
(106,'BBD-EC-202508','Nisha Gupta','nisha.gupta105@student.bbd.example','9810000105','Electronics',2,NULL,'2026-05-31','inactive','2026-07-25 01:10:17'),
(107,'BBD-EC-202405','Aditi Gupta','aditi.gupta106@student.bbd.example','9810000106','Electronics',8,NULL,'2024-07-28','active','2026-07-25 01:10:17'),
(108,'BBD-CS-202203','Swati Gupta','swati.gupta107@student.bbd.example','9810000107','Computer Science',8,NULL,'2025-11-04','active','2026-07-25 01:10:17'),
(109,'BBD-ME-202404','Harsh Gupta','harsh.gupta108@student.bbd.example','9810000108','Mechanical',2,NULL,'2026-03-08','blocked','2026-07-25 01:10:17'),
(110,'BBD-CS-202510','Mahika Gupta','mahika.gupta109@student.bbd.example','9810000109','Computer Science',5,NULL,'2026-01-02','active','2026-07-25 01:10:17'),
(111,'BBD-CV-202204','Vivaan Gupta','vivaan.gupta110@student.bbd.example','9810000110','Civil',7,NULL,'2025-03-20','active','2026-07-25 01:10:17'),
(112,'BBD-ME-202405','Saanvi Gupta','saanvi.gupta111@student.bbd.example','9810000111','Mechanical',8,NULL,'2024-10-25','active','2026-07-25 01:10:17'),
(113,'BBD-ME-202508','Vikram Gupta','vikram.gupta112@student.bbd.example','9810000112','Mechanical',5,NULL,'2026-02-22','active','2026-07-25 01:10:17'),
(114,'BBD-EC-202509','Kian Gupta','kian.gupta113@student.bbd.example','9810000113','Electronics',4,NULL,'2025-04-19','active','2026-07-25 01:10:17'),
(115,'BBD-CS-202204','Aisha Gupta','aisha.gupta114@student.bbd.example','9810000114','Computer Science',4,NULL,'2025-07-05','active','2026-07-25 01:10:17'),
(116,'BBD-EC-202309','Meera Gupta','meera.gupta115@student.bbd.example','9810000115','Electronics',7,NULL,'2023-12-16','active','2026-07-25 01:10:17'),
(117,'BBD-EC-202406','Shreya Gupta','shreya.gupta116@student.bbd.example','9810000116','Electronics',1,NULL,'2025-03-08','active','2026-07-25 01:10:17'),
(118,'BBD-CS-202309','Riya Gupta','riya.gupta117@student.bbd.example','9810000117','Computer Science',8,NULL,'2026-01-31','active','2026-07-25 01:10:17'),
(119,'BBD-EC-202510','Manav Gupta','manav.gupta118@student.bbd.example','9810000118','Electronics',4,NULL,'2024-02-06','active','2026-07-25 01:10:17'),
(120,'BBD-CS-202310','Kunal Gupta','kunal.gupta119@student.bbd.example','9810000119','Computer Science',3,NULL,'2024-12-28','active','2026-07-25 01:10:17'),
(121,'BBD-ME-202204','Nandini Gupta','nandini.gupta120@student.bbd.example','9810000120','Mechanical',3,NULL,'2024-10-04','active','2026-07-25 01:10:17'),
(122,'BBD-EC-202511','Nikhil Gupta','nikhil.gupta121@student.bbd.example','9810000121','Electronics',5,NULL,'2024-01-08','active','2026-07-25 01:10:17'),
(123,'BBD-CS-202511','Kiara Gupta','kiara.gupta122@student.bbd.example','9810000122','Computer Science',7,NULL,'2024-12-15','active','2026-07-25 01:10:17'),
(124,'BBD-IT-202406','Sanjay Gupta','sanjay.gupta123@student.bbd.example','9810000123','Information Technology',2,NULL,'2026-04-05','active','2026-07-25 01:10:17'),
(125,'BBD-CV-202505','Aryan Gupta','aryan.gupta124@student.bbd.example','9810000124','Civil',5,NULL,'2026-05-04','active','2026-07-25 01:10:17'),
(126,'BBD-CS-202512','Tara Gupta','tara.gupta125@student.bbd.example','9810000125','Computer Science',1,NULL,'2024-12-21','active','2026-07-25 01:10:17'),
(127,'BBD-EC-202512','Ayaan Gupta','ayaan.gupta126@student.bbd.example','9810000126','Electronics',3,NULL,'2023-11-05','active','2026-07-25 01:10:17'),
(128,'BBD-IT-202407','Navya Gupta','navya.gupta127@student.bbd.example','9810000127','Information Technology',5,NULL,'2025-06-19','active','2026-07-25 01:10:17'),
(129,'BBD-CV-202403','Vihaan Gupta','vihaan.gupta128@student.bbd.example','9810000128','Civil',8,NULL,'2025-12-21','inactive','2026-07-25 01:10:17'),
(130,'BBD-IT-202408','Nitin Gupta','nitin.gupta129@student.bbd.example','9810000129','Information Technology',6,NULL,'2025-11-23','active','2026-07-25 01:10:17'),
(131,'BBD-ME-202303','Neha Gupta','neha.gupta130@student.bbd.example','9810000130','Mechanical',8,NULL,'2024-11-12','active','2026-07-25 01:10:17'),
(132,'BBD-EC-202407','Diya Gupta','diya.gupta131@student.bbd.example','9810000131','Electronics',1,NULL,'2023-12-07','active','2026-07-25 01:10:17'),
(133,'BBD-CS-202311','Yash Gupta','yash.gupta132@student.bbd.example','9810000132','Computer Science',2,NULL,'2024-03-20','active','2026-07-25 01:10:17'),
(134,'BBD-ME-202509','Rajat Gupta','rajat.gupta133@student.bbd.example','9810000133','Mechanical',1,NULL,'2023-11-22','active','2026-07-25 01:10:17'),
(135,'BBD-IT-202311','Anvi Gupta','anvi.gupta134@student.bbd.example','9810000134','Information Technology',6,NULL,'2023-09-09','active','2026-07-25 01:10:17'),
(136,'BBD-EC-202513','Ritu Gupta','ritu.gupta135@student.bbd.example','9810000135','Electronics',4,NULL,'2024-12-26','active','2026-07-25 01:10:17'),
(137,'BBD-EC-202514','Advik Gupta','advik.gupta136@student.bbd.example','9810000136','Electronics',8,NULL,'2023-10-07','active','2026-07-25 01:10:17'),
(138,'BBD-CS-202513','Ira Gupta','ira.gupta137@student.bbd.example','9810000137','Computer Science',4,NULL,'2025-08-05','active','2026-07-25 01:10:17'),
(139,'BBD-IT-202202','Sara Gupta','sara.gupta138@student.bbd.example','9810000138','Information Technology',7,NULL,'2025-12-17','inactive','2026-07-25 01:10:17'),
(140,'BBD-CS-202514','Pari Gupta','pari.gupta139@student.bbd.example','9810000139','Computer Science',2,NULL,'2023-11-23','inactive','2026-07-25 01:10:17'),
(141,'BBD-CV-202404','Rudra Gupta','rudra.gupta140@student.bbd.example','9810000140','Civil',3,NULL,'2023-09-09','active','2026-07-25 01:10:17'),
(142,'BBD-CV-202306','Karan Gupta','karan.gupta141@student.bbd.example','9810000141','Civil',5,NULL,'2024-02-26','active','2026-07-25 01:10:17'),
(143,'BBD-ME-202510','Ranveer Gupta','ranveer.gupta142@student.bbd.example','9810000142','Mechanical',4,NULL,'2023-12-03','active','2026-07-25 01:10:17'),
(144,'BBD-EC-202408','Zara Gupta','zara.gupta143@student.bbd.example','9810000143','Electronics',3,NULL,'2026-02-03','active','2026-07-25 01:10:17'),
(145,'BBD-CS-202515','Ishaan Gupta','ishaan.gupta144@student.bbd.example','9810000144','Computer Science',7,NULL,'2024-07-29','blocked','2026-07-25 01:10:17'),
(146,'BBD-CV-202405','Avni Gupta','avni.gupta145@student.bbd.example','9810000145','Civil',1,NULL,'2024-11-23','active','2026-07-25 01:10:17'),
(147,'BBD-ME-202511','Kavya Gupta','kavya.gupta146@student.bbd.example','9810000146','Mechanical',8,NULL,'2025-08-25','active','2026-07-25 01:10:17'),
(148,'BBD-IT-202409','Divya Gupta','divya.gupta147@student.bbd.example','9810000147','Information Technology',6,NULL,'2024-05-14','active','2026-07-25 01:10:17'),
(149,'BBD-IT-202312','Dhruv Gupta','dhruv.gupta148@student.bbd.example','9810000148','Information Technology',4,NULL,'2025-02-21','active','2026-07-25 01:10:17'),
(150,'BBD-EC-202310','Aarush Gupta','aarush.gupta149@student.bbd.example','9810000149','Electronics',7,NULL,'2026-03-28','active','2026-07-25 01:10:17');
/*!40000 ALTER TABLE `students` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`library_admin`@`localhost`*/ /*!50003 TRIGGER trg_audit_students_update
AFTER UPDATE ON students
FOR EACH ROW
BEGIN
    INSERT INTO audit_log (table_name, action, record_id, details)
    VALUES ('students', 'UPDATE', NEW.student_id,
        CONCAT('status:', OLD.status, '->', NEW.status));
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`library_admin`@`localhost`*/ /*!50003 TRIGGER trg_audit_students_delete
BEFORE DELETE ON students
FOR EACH ROW
BEGIN
    INSERT INTO audit_log (table_name, action, record_id, details)
    VALUES ('students', 'DELETE', OLD.student_id, CONCAT('name=', OLD.full_name, ' | roll=', OLD.roll_number));
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Temporary table structure for view `vw_available_books`
--

DROP TABLE IF EXISTS `vw_available_books`;
/*!50001 DROP VIEW IF EXISTS `vw_available_books`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8mb4;
/*!50001 CREATE VIEW `vw_available_books` AS SELECT
 1 AS `book_id`,
  1 AS `isbn`,
  1 AS `title`,
  1 AS `category_id`,
  1 AS `category_name`,
  1 AS `publisher_id`,
  1 AS `publisher_name`,
  1 AS `edition`,
  1 AS `publication_year`,
  1 AS `total_copies`,
  1 AS `available_copies`,
  1 AS `copies_issued`,
  1 AS `shelf_location`,
  1 AS `price`,
  1 AS `status`,
  1 AS `authors` */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `vw_book_catalog`
--

DROP TABLE IF EXISTS `vw_book_catalog`;
/*!50001 DROP VIEW IF EXISTS `vw_book_catalog`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8mb4;
/*!50001 CREATE VIEW `vw_book_catalog` AS SELECT
 1 AS `book_id`,
  1 AS `isbn`,
  1 AS `title`,
  1 AS `category_id`,
  1 AS `category_name`,
  1 AS `publisher_id`,
  1 AS `publisher_name`,
  1 AS `edition`,
  1 AS `publication_year`,
  1 AS `total_copies`,
  1 AS `available_copies`,
  1 AS `copies_issued`,
  1 AS `shelf_location`,
  1 AS `price`,
  1 AS `status`,
  1 AS `authors` */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `vw_currently_issued`
--

DROP TABLE IF EXISTS `vw_currently_issued`;
/*!50001 DROP VIEW IF EXISTS `vw_currently_issued`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8mb4;
/*!50001 CREATE VIEW `vw_currently_issued` AS SELECT
 1 AS `issue_id`,
  1 AS `book_id`,
  1 AS `title`,
  1 AS `isbn`,
  1 AS `student_id`,
  1 AS `roll_number`,
  1 AS `student_name`,
  1 AS `issue_date`,
  1 AS `due_date`,
  1 AS `days_overdue`,
  1 AS `status` */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `vw_dashboard_stats`
--

DROP TABLE IF EXISTS `vw_dashboard_stats`;
/*!50001 DROP VIEW IF EXISTS `vw_dashboard_stats`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8mb4;
/*!50001 CREATE VIEW `vw_dashboard_stats` AS SELECT
 1 AS `total_books`,
  1 AS `available_books`,
  1 AS `issued_books`,
  1 AS `returned_books`,
  1 AS `total_students`,
  1 AS `late_returns`,
  1 AS `fine_collected`,
  1 AS `fine_pending` */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `vw_fine_report`
--

DROP TABLE IF EXISTS `vw_fine_report`;
/*!50001 DROP VIEW IF EXISTS `vw_fine_report`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8mb4;
/*!50001 CREATE VIEW `vw_fine_report` AS SELECT
 1 AS `issue_id`,
  1 AS `roll_number`,
  1 AS `student_name`,
  1 AS `title`,
  1 AS `due_date`,
  1 AS `return_date`,
  1 AS `fine_amount`,
  1 AS `amount_paid`,
  1 AS `balance_due`,
  1 AS `fine_paid` */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `vw_most_borrowed_books`
--

DROP TABLE IF EXISTS `vw_most_borrowed_books`;
/*!50001 DROP VIEW IF EXISTS `vw_most_borrowed_books`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8mb4;
/*!50001 CREATE VIEW `vw_most_borrowed_books` AS SELECT
 1 AS `book_id`,
  1 AS `title`,
  1 AS `isbn`,
  1 AS `category_name`,
  1 AS `times_borrowed`,
  1 AS `currently_out`,
  1 AS `avg_days_held` */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `vw_overdue_books`
--

DROP TABLE IF EXISTS `vw_overdue_books`;
/*!50001 DROP VIEW IF EXISTS `vw_overdue_books`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8mb4;
/*!50001 CREATE VIEW `vw_overdue_books` AS SELECT
 1 AS `issue_id`,
  1 AS `title`,
  1 AS `isbn`,
  1 AS `roll_number`,
  1 AS `student_name`,
  1 AS `phone`,
  1 AS `issue_date`,
  1 AS `due_date`,
  1 AS `days_overdue`,
  1 AS `estimated_fine` */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `vw_student_borrow_history`
--

DROP TABLE IF EXISTS `vw_student_borrow_history`;
/*!50001 DROP VIEW IF EXISTS `vw_student_borrow_history`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8mb4;
/*!50001 CREATE VIEW `vw_student_borrow_history` AS SELECT
 1 AS `student_id`,
  1 AS `roll_number`,
  1 AS `student_name`,
  1 AS `issue_id`,
  1 AS `title`,
  1 AS `isbn`,
  1 AS `issue_date`,
  1 AS `due_date`,
  1 AS `return_date`,
  1 AS `status`,
  1 AS `fine_amount`,
  1 AS `fine_paid` */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `vw_student_summary`
--

DROP TABLE IF EXISTS `vw_student_summary`;
/*!50001 DROP VIEW IF EXISTS `vw_student_summary`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8mb4;
/*!50001 CREATE VIEW `vw_student_summary` AS SELECT
 1 AS `student_id`,
  1 AS `roll_number`,
  1 AS `full_name`,
  1 AS `department`,
  1 AS `status`,
  1 AS `total_books_borrowed`,
  1 AS `books_currently_held`,
  1 AS `overdue_count`,
  1 AS `total_fine_charged`,
  1 AS `total_fine_paid` */;
SET character_set_client = @saved_cs_client;

--
-- Dumping events for database 'library_management_system'
--

--
-- Dumping routines for database 'library_management_system'
--
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
/*!50003 DROP FUNCTION IF EXISTS `fn_active_issue_count` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
DELIMITER ;;
CREATE DEFINER=`library_admin`@`localhost` FUNCTION `fn_active_issue_count`(p_student_id INT) RETURNS int(11)
    READS SQL DATA
BEGIN
    DECLARE v_count INT DEFAULT 0;
    SELECT COUNT(*) INTO v_count
        FROM book_issues
        WHERE student_id = p_student_id AND status IN ('issued','overdue');
    RETURN v_count;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
/*!50003 DROP FUNCTION IF EXISTS `fn_calculate_fine` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
DELIMITER ;;
CREATE DEFINER=`library_admin`@`localhost` FUNCTION `fn_calculate_fine`(p_due_date DATE,
    p_return_date DATE
) RETURNS decimal(8,2)
    READS SQL DATA
    DETERMINISTIC
BEGIN
    DECLARE v_days_late INT DEFAULT 0;
    DECLARE v_fine_per_day DECIMAL(8,2) DEFAULT 5.00;
    DECLARE v_max_fine DECIMAL(8,2) DEFAULT 500.00;
    DECLARE v_fine DECIMAL(8,2) DEFAULT 0.00;

    IF p_return_date IS NULL OR p_due_date IS NULL THEN
        RETURN 0.00;
    END IF;

    SET v_days_late = DATEDIFF(p_return_date, p_due_date);

    SELECT CAST(setting_value AS DECIMAL(8,2)) INTO v_fine_per_day
        FROM settings WHERE setting_key = 'fine_per_day' LIMIT 1;
    SELECT CAST(setting_value AS DECIMAL(8,2)) INTO v_max_fine
        FROM settings WHERE setting_key = 'max_fine_per_book' LIMIT 1;

    IF v_days_late <= 0 THEN
        RETURN 0.00;
    END IF;

    SET v_fine = v_days_late * v_fine_per_day;

    IF v_fine > v_max_fine THEN
        SET v_fine = v_max_fine;
    END IF;

    RETURN v_fine;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
/*!50003 DROP FUNCTION IF EXISTS `fn_is_book_available` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
DELIMITER ;;
CREATE DEFINER=`library_admin`@`localhost` FUNCTION `fn_is_book_available`(p_book_id INT) RETURNS tinyint(1)
    READS SQL DATA
BEGIN
    DECLARE v_available INT DEFAULT 0;
    SELECT available_copies INTO v_available FROM books WHERE book_id = p_book_id;
    RETURN IFNULL(v_available, 0) > 0;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_issue_book` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
DELIMITER ;;
CREATE DEFINER=`library_admin`@`localhost` PROCEDURE `sp_issue_book`(
    IN  p_book_id       INT,
    IN  p_student_id    INT,
    IN  p_issue_days    INT,          
    IN  p_admin_id      INT,
    OUT p_issue_id      INT,
    OUT p_message       VARCHAR(255)
)
proc_body: BEGIN
    DECLARE v_available   INT DEFAULT 0;
    DECLARE v_student_status VARCHAR(20);
    DECLARE v_active_loans INT DEFAULT 0;
    DECLARE v_max_books    INT DEFAULT 3;

    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        ROLLBACK;
        SET p_issue_id = NULL;
        GET DIAGNOSTICS CONDITION 1 p_message = MESSAGE_TEXT;
    END;

    START TRANSACTION;

    SELECT available_copies INTO v_available
        FROM books WHERE book_id = p_book_id FOR UPDATE;

    IF v_available IS NULL THEN
        SET p_message = 'Book not found.';
        SET p_issue_id = NULL;
        ROLLBACK;
        LEAVE proc_body;
    END IF;

    IF v_available <= 0 THEN
        SET p_message = 'No copies available for this book.';
        SET p_issue_id = NULL;
        ROLLBACK;
        LEAVE proc_body;
    END IF;

    SELECT status INTO v_student_status FROM students WHERE student_id = p_student_id;

    IF v_student_status IS NULL THEN
        SET p_message = 'Student not found.';
        SET p_issue_id = NULL;
        ROLLBACK;
        LEAVE proc_body;
    ELSEIF v_student_status <> 'active' THEN
        SET p_message = CONCAT('Student membership is ', v_student_status, '.');
        SET p_issue_id = NULL;
        ROLLBACK;
        LEAVE proc_body;
    END IF;

    SELECT CAST(setting_value AS UNSIGNED) INTO v_max_books
        FROM settings WHERE setting_key = 'max_books_per_student' LIMIT 1;

    SET v_active_loans = fn_active_issue_count(p_student_id);

    IF v_active_loans >= v_max_books THEN
        SET p_message = CONCAT('Student already holds the maximum of ', v_max_books, ' books.');
        SET p_issue_id = NULL;
        ROLLBACK;
        LEAVE proc_body;
    END IF;

    INSERT INTO book_issues (book_id, student_id, issue_date, due_date, issued_by, status)
    VALUES (p_book_id, p_student_id, CURDATE(), DATE_ADD(CURDATE(), INTERVAL p_issue_days DAY), p_admin_id, 'issued');

    SET p_issue_id = LAST_INSERT_ID();
    SET p_message = 'Book issued successfully.';

    COMMIT;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_pay_fine` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
DELIMITER ;;
CREATE DEFINER=`library_admin`@`localhost` PROCEDURE `sp_pay_fine`(
    IN  p_issue_id    INT,
    IN  p_amount      DECIMAL(8,2),
    IN  p_admin_id    INT,
    OUT p_message     VARCHAR(255)
)
proc_body: BEGIN
    DECLARE v_fine_amount DECIMAL(8,2);
    DECLARE v_already_paid DECIMAL(8,2);
    DECLARE v_balance DECIMAL(8,2);

    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        ROLLBACK;
        GET DIAGNOSTICS CONDITION 1 p_message = MESSAGE_TEXT;
    END;

    START TRANSACTION;

    SELECT fine_amount INTO v_fine_amount FROM book_issues WHERE issue_id = p_issue_id FOR UPDATE;

    IF v_fine_amount IS NULL THEN
        SET p_message = 'Issue record not found.';
        ROLLBACK;
        LEAVE proc_body;
    END IF;

    SELECT COALESCE(SUM(amount_paid), 0) INTO v_already_paid
        FROM fine_payments WHERE issue_id = p_issue_id;

    SET v_balance = v_fine_amount - v_already_paid;

    IF p_amount <= 0 THEN
        SET p_message = 'Payment amount must be positive.';
        ROLLBACK;
        LEAVE proc_body;
    ELSEIF p_amount > v_balance THEN
        SET p_message = CONCAT('Payment exceeds outstanding balance of Rs. ', v_balance);
        ROLLBACK;
        LEAVE proc_body;
    END IF;

    INSERT INTO fine_payments (issue_id, amount_paid, collected_by)
        VALUES (p_issue_id, p_amount, p_admin_id);

    IF (v_already_paid + p_amount) >= v_fine_amount THEN
        UPDATE book_issues SET fine_paid = 1 WHERE issue_id = p_issue_id;
    END IF;

    SET p_message = 'Payment recorded successfully.';
    COMMIT;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_return_book` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
DELIMITER ;;
CREATE DEFINER=`library_admin`@`localhost` PROCEDURE `sp_return_book`(
    IN  p_issue_id      INT,
    IN  p_admin_id      INT,
    OUT p_fine_amount   DECIMAL(8,2),
    OUT p_message       VARCHAR(255)
)
proc_body: BEGIN
    DECLARE v_due_date DATE;
    DECLARE v_status   VARCHAR(20);
    DECLARE v_fine      DECIMAL(8,2) DEFAULT 0.00;

    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        ROLLBACK;
        SET p_fine_amount = NULL;
        GET DIAGNOSTICS CONDITION 1 p_message = MESSAGE_TEXT;
    END;

    START TRANSACTION;

    SELECT due_date, status INTO v_due_date, v_status
        FROM book_issues WHERE issue_id = p_issue_id FOR UPDATE;

    IF v_due_date IS NULL THEN
        SET p_message = 'Issue record not found.';
        SET p_fine_amount = NULL;
        ROLLBACK;
        LEAVE proc_body;
    END IF;

    IF v_status = 'returned' THEN
        SET p_message = 'This book has already been returned.';
        SET p_fine_amount = NULL;
        ROLLBACK;
        LEAVE proc_body;
    END IF;

    SET v_fine = fn_calculate_fine(v_due_date, CURDATE());

    UPDATE book_issues
        SET return_date = CURDATE(),
            fine_amount = v_fine,
            fine_paid   = IF(v_fine = 0, 1, 0),
            status      = 'returned',
            returned_to = p_admin_id
        WHERE issue_id = p_issue_id;

    SET p_fine_amount = v_fine;
    SET p_message = IF(v_fine > 0,
        CONCAT('Book returned. Late fine of Rs. ', v_fine, ' applied.'),
        'Book returned on time. No fine.');

    COMMIT;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_search_books` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
DELIMITER ;;
CREATE DEFINER=`library_admin`@`localhost` PROCEDURE `sp_search_books`(
    IN p_keyword      VARCHAR(200),
    IN p_category_id  INT,
    IN p_sort_column  VARCHAR(30),   
    IN p_sort_dir     VARCHAR(4),    
    IN p_limit        INT,
    IN p_offset       INT
)
BEGIN
    DECLARE v_sort_column VARCHAR(30) DEFAULT 'title';
    DECLARE v_sort_dir    VARCHAR(4)  DEFAULT 'ASC';

    IF p_sort_column IN ('title','price','publication_year','available_copies') THEN
        SET v_sort_column = p_sort_column;
    END IF;
    IF UPPER(p_sort_dir) = 'DESC' THEN
        SET v_sort_dir = 'DESC';
    ELSE
        SET v_sort_dir = 'ASC';
    END IF;

    SET @kw       = CONCAT('%', IFNULL(p_keyword, ''), '%');
    SET @cat_id   = p_category_id;
    SET @lim      = IFNULL(p_limit, 10);
    SET @off      = IFNULL(p_offset, 0);

    SET @sql = CONCAT(
        'SELECT SQL_CALC_FOUND_ROWS book_id, isbn, title, category_name, publisher_name, ',
        'authors, total_copies, available_copies, price, status ',
        'FROM vw_book_catalog ',
        'WHERE (title LIKE ? OR isbn LIKE ? OR authors LIKE ?) ',
        'AND (? IS NULL OR category_id = ?) ',
        'ORDER BY ', v_sort_column, ' ', v_sort_dir, ' ',
        'LIMIT ? OFFSET ?'
    );

    PREPARE stmt FROM @sql;
    SET @cat_id_check = @cat_id;
    EXECUTE stmt USING @kw, @kw, @kw, @cat_id_check, @cat_id, @lim, @off;
    DEALLOCATE PREPARE stmt;

    SELECT FOUND_ROWS() AS total_matching_rows;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Final view structure for view `vw_available_books`
--

/*!50001 DROP VIEW IF EXISTS `vw_available_books`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = latin1 */;
/*!50001 SET character_set_results     = latin1 */;
/*!50001 SET collation_connection      = latin1_swedish_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`library_admin`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `vw_available_books` AS select `vw_book_catalog`.`book_id` AS `book_id`,`vw_book_catalog`.`isbn` AS `isbn`,`vw_book_catalog`.`title` AS `title`,`vw_book_catalog`.`category_id` AS `category_id`,`vw_book_catalog`.`category_name` AS `category_name`,`vw_book_catalog`.`publisher_id` AS `publisher_id`,`vw_book_catalog`.`publisher_name` AS `publisher_name`,`vw_book_catalog`.`edition` AS `edition`,`vw_book_catalog`.`publication_year` AS `publication_year`,`vw_book_catalog`.`total_copies` AS `total_copies`,`vw_book_catalog`.`available_copies` AS `available_copies`,`vw_book_catalog`.`copies_issued` AS `copies_issued`,`vw_book_catalog`.`shelf_location` AS `shelf_location`,`vw_book_catalog`.`price` AS `price`,`vw_book_catalog`.`status` AS `status`,`vw_book_catalog`.`authors` AS `authors` from `vw_book_catalog` where `vw_book_catalog`.`available_copies` > 0 and `vw_book_catalog`.`status` = 'active' */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `vw_book_catalog`
--

/*!50001 DROP VIEW IF EXISTS `vw_book_catalog`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = latin1 */;
/*!50001 SET character_set_results     = latin1 */;
/*!50001 SET collation_connection      = latin1_swedish_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`library_admin`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `vw_book_catalog` AS select `b`.`book_id` AS `book_id`,`b`.`isbn` AS `isbn`,`b`.`title` AS `title`,`c`.`category_id` AS `category_id`,`c`.`category_name` AS `category_name`,`p`.`publisher_id` AS `publisher_id`,`p`.`publisher_name` AS `publisher_name`,`b`.`edition` AS `edition`,`b`.`publication_year` AS `publication_year`,`b`.`total_copies` AS `total_copies`,`b`.`available_copies` AS `available_copies`,`b`.`total_copies` - `b`.`available_copies` AS `copies_issued`,`b`.`shelf_location` AS `shelf_location`,`b`.`price` AS `price`,`b`.`status` AS `status`,(select group_concat(`a`.`author_name` order by `a`.`author_name` ASC separator ', ') from (`book_authors` `ba` join `authors` `a` on(`a`.`author_id` = `ba`.`author_id`)) where `ba`.`book_id` = `b`.`book_id`) AS `authors` from ((`books` `b` join `categories` `c` on(`c`.`category_id` = `b`.`category_id`)) join `publishers` `p` on(`p`.`publisher_id` = `b`.`publisher_id`)) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `vw_currently_issued`
--

/*!50001 DROP VIEW IF EXISTS `vw_currently_issued`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = latin1 */;
/*!50001 SET character_set_results     = latin1 */;
/*!50001 SET collation_connection      = latin1_swedish_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`library_admin`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `vw_currently_issued` AS select `bi`.`issue_id` AS `issue_id`,`b`.`book_id` AS `book_id`,`b`.`title` AS `title`,`b`.`isbn` AS `isbn`,`s`.`student_id` AS `student_id`,`s`.`roll_number` AS `roll_number`,`s`.`full_name` AS `student_name`,`bi`.`issue_date` AS `issue_date`,`bi`.`due_date` AS `due_date`,to_days(curdate()) - to_days(`bi`.`due_date`) AS `days_overdue`,`bi`.`status` AS `status` from ((`book_issues` `bi` join `books` `b` on(`b`.`book_id` = `bi`.`book_id`)) join `students` `s` on(`s`.`student_id` = `bi`.`student_id`)) where `bi`.`status` in ('issued','overdue') */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `vw_dashboard_stats`
--

/*!50001 DROP VIEW IF EXISTS `vw_dashboard_stats`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = latin1 */;
/*!50001 SET character_set_results     = latin1 */;
/*!50001 SET collation_connection      = latin1_swedish_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`library_admin`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `vw_dashboard_stats` AS select (select count(0) from `books`) AS `total_books`,(select coalesce(sum(`books`.`available_copies`),0) from `books`) AS `available_books`,(select coalesce(sum(`books`.`total_copies` - `books`.`available_copies`),0) from `books`) AS `issued_books`,(select count(0) from `book_issues` where `book_issues`.`status` = 'returned') AS `returned_books`,(select count(0) from `students` where `students`.`status` = 'active') AS `total_students`,(select count(0) from `book_issues` where `book_issues`.`status` in ('issued','overdue') and `book_issues`.`due_date` < curdate()) AS `late_returns`,(select coalesce(sum(`book_issues`.`fine_amount`),0) from `book_issues` where `book_issues`.`fine_paid` = 1) AS `fine_collected`,(select coalesce(sum(`book_issues`.`fine_amount`),0) from `book_issues` where `book_issues`.`fine_paid` = 0) AS `fine_pending` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `vw_fine_report`
--

/*!50001 DROP VIEW IF EXISTS `vw_fine_report`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = latin1 */;
/*!50001 SET character_set_results     = latin1 */;
/*!50001 SET collation_connection      = latin1_swedish_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`library_admin`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `vw_fine_report` AS select `bi`.`issue_id` AS `issue_id`,`s`.`roll_number` AS `roll_number`,`s`.`full_name` AS `student_name`,`b`.`title` AS `title`,`bi`.`due_date` AS `due_date`,`bi`.`return_date` AS `return_date`,`bi`.`fine_amount` AS `fine_amount`,coalesce((select sum(`fp`.`amount_paid`) from `fine_payments` `fp` where `fp`.`issue_id` = `bi`.`issue_id`),0) AS `amount_paid`,`bi`.`fine_amount` - coalesce((select sum(`fp`.`amount_paid`) from `fine_payments` `fp` where `fp`.`issue_id` = `bi`.`issue_id`),0) AS `balance_due`,`bi`.`fine_paid` AS `fine_paid` from ((`book_issues` `bi` join `students` `s` on(`s`.`student_id` = `bi`.`student_id`)) join `books` `b` on(`b`.`book_id` = `bi`.`book_id`)) where `bi`.`fine_amount` > 0 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `vw_most_borrowed_books`
--

/*!50001 DROP VIEW IF EXISTS `vw_most_borrowed_books`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = latin1 */;
/*!50001 SET character_set_results     = latin1 */;
/*!50001 SET collation_connection      = latin1_swedish_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`library_admin`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `vw_most_borrowed_books` AS select `b`.`book_id` AS `book_id`,`b`.`title` AS `title`,`b`.`isbn` AS `isbn`,`c`.`category_name` AS `category_name`,count(`bi`.`issue_id`) AS `times_borrowed`,sum(`bi`.`status` = 'issued') AS `currently_out`,round(avg(to_days(coalesce(`bi`.`return_date`,curdate())) - to_days(`bi`.`issue_date`)),1) AS `avg_days_held` from ((`books` `b` join `categories` `c` on(`c`.`category_id` = `b`.`category_id`)) left join `book_issues` `bi` on(`bi`.`book_id` = `b`.`book_id`)) group by `b`.`book_id`,`b`.`title`,`b`.`isbn`,`c`.`category_name` having count(`bi`.`issue_id`) > 0 order by count(`bi`.`issue_id`) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `vw_overdue_books`
--

/*!50001 DROP VIEW IF EXISTS `vw_overdue_books`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = latin1 */;
/*!50001 SET character_set_results     = latin1 */;
/*!50001 SET collation_connection      = latin1_swedish_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`library_admin`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `vw_overdue_books` AS select `bi`.`issue_id` AS `issue_id`,`b`.`title` AS `title`,`b`.`isbn` AS `isbn`,`s`.`roll_number` AS `roll_number`,`s`.`full_name` AS `student_name`,`s`.`phone` AS `phone`,`bi`.`issue_date` AS `issue_date`,`bi`.`due_date` AS `due_date`,to_days(curdate()) - to_days(`bi`.`due_date`) AS `days_overdue`,`fn_calculate_fine`(`bi`.`due_date`,curdate()) AS `estimated_fine` from ((`book_issues` `bi` join `books` `b` on(`b`.`book_id` = `bi`.`book_id`)) join `students` `s` on(`s`.`student_id` = `bi`.`student_id`)) where `bi`.`status` in ('issued','overdue') and `bi`.`due_date` < curdate() */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `vw_student_borrow_history`
--

/*!50001 DROP VIEW IF EXISTS `vw_student_borrow_history`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = latin1 */;
/*!50001 SET character_set_results     = latin1 */;
/*!50001 SET collation_connection      = latin1_swedish_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`library_admin`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `vw_student_borrow_history` AS select `s`.`student_id` AS `student_id`,`s`.`roll_number` AS `roll_number`,`s`.`full_name` AS `student_name`,`bi`.`issue_id` AS `issue_id`,`b`.`title` AS `title`,`b`.`isbn` AS `isbn`,`bi`.`issue_date` AS `issue_date`,`bi`.`due_date` AS `due_date`,`bi`.`return_date` AS `return_date`,`bi`.`status` AS `status`,`bi`.`fine_amount` AS `fine_amount`,`bi`.`fine_paid` AS `fine_paid` from ((`students` `s` join `book_issues` `bi` on(`bi`.`student_id` = `s`.`student_id`)) join `books` `b` on(`b`.`book_id` = `bi`.`book_id`)) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `vw_student_summary`
--

/*!50001 DROP VIEW IF EXISTS `vw_student_summary`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = latin1 */;
/*!50001 SET character_set_results     = latin1 */;
/*!50001 SET collation_connection      = latin1_swedish_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`library_admin`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `vw_student_summary` AS select `s`.`student_id` AS `student_id`,`s`.`roll_number` AS `roll_number`,`s`.`full_name` AS `full_name`,`s`.`department` AS `department`,`s`.`status` AS `status`,count(`bi`.`issue_id`) AS `total_books_borrowed`,sum(`bi`.`status` in ('issued','overdue')) AS `books_currently_held`,sum(`bi`.`status` = 'overdue' or `bi`.`status` = 'issued' and `bi`.`due_date` < curdate()) AS `overdue_count`,coalesce(sum(`bi`.`fine_amount`),0) AS `total_fine_charged`,coalesce(sum(case when `bi`.`fine_paid` = 1 then `bi`.`fine_amount` else 0 end),0) AS `total_fine_paid` from (`students` `s` left join `book_issues` `bi` on(`bi`.`student_id` = `s`.`student_id`)) group by `s`.`student_id`,`s`.`roll_number`,`s`.`full_name`,`s`.`department`,`s`.`status` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-07-25  1:10:33
